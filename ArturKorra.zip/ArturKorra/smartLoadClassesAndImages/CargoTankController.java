package it.easymarine.ebr.smartload.views;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.Force;
import javax.measure.quantity.Length;
import javax.measure.quantity.Mass;
import javax.measure.quantity.Temperature;
import javax.measure.quantity.Volume;

import org.controlsfx.control.NotificationPane;
import org.controlsfx.control.spreadsheet.GridBase;
import org.controlsfx.control.spreadsheet.SpreadsheetCell;
import org.controlsfx.control.spreadsheet.SpreadsheetCellType;
import org.controlsfx.control.spreadsheet.SpreadsheetView;
import org.eclipse.fx.core.log.Logger;
import org.eclipse.fx.core.log.LoggerCreator;

import it.easymarine.ebr.commons.utils.CustomSpreadsheetView;
import it.easymarine.ebr.commons.utils.HeterogeneousBidirectionalBinder;
import it.easymarine.ebr.commons.utils.JavaFXUtils;
import it.easymarine.ebr.smartload.CustomSpreadsheetCellQuantityType;
import it.easymarine.ebr.smartload.CustomSpreadsheetCellQuantityWithRangeType;
import it.easymarine.ebr.smartload.core.services.ShearBendingService;
import it.easymarine.ebr.smartload.core.services.ShipTanksService;
import it.easymarine.ebr.smartload.core.services.TempDensityService;
import it.easymarine.ebr.smartload.domain.CargoLibrary;
import it.easymarine.ebr.smartload.domain.CargoType;
import it.easymarine.ebr.smartload.domain.Tank;
import it.easymarine.ebr.smartload.domain.TankLoading;
import it.easymarine.ebr.smartload.domain.TankSavedData;
import it.easymarine.ebr.smartload.domain.TempDensTableType;
import it.easymarine.ebr.smartload.domain.units.FreeSurfaceMoment;
import it.easymarine.ebr.smartload.domain.units.SmartLoadUnits;
import it.easymarine.ebr.smartload.preferences.SmartloadPreferencePage;
import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import si.uom.quantity.Density;
import si.uom.quantity.Torque;
import systems.uom.ucum.UCUM;
import tech.units.indriya.ComparableQuantity;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.unit.Units;

public class CargoTankController implements Initializable {
	public static final Unit<Dimensionless> PERCENT_UNIT = Units.PERCENT;
	public static final Unit<Dimensionless> FACTOR_UNIT = SmartLoadUnits.FACTOR;
	public static final Unit<Mass> MASS_UNIT_LT = SmartLoadUnits.LONG_TON;

	public static final String ACTUALLY_NOT_EDITABLE_STYLE_CLASS = "actually-not-editable";

	private static final Logger logger = LoggerCreator.createLogger(CargoTankController.class);

	@Inject
	private SmartloadPreferencePage smartloadPreferencePage;
	@Inject
	private ShipTanksService shipTanksService;
	@Inject
	private TempDensityService tempDensityService;
	@Inject
	private ShearBendingService shearBendingService;
	@Inject
	private SmartloadViewController smartloadViewController;

	@FXML
	private VBox mainVBox;
	@FXML
	private BorderPane borderPane;
	@FXML
	private Pane customSpreadsheetHolderPane;

	private SpreadsheetView cargoTankSpreadsheetView;
	private List<Tank> cargoTankList;
	private NotificationPane notificationPane;
	private AtomicBoolean disableTemperatureCellListener = new AtomicBoolean(false);
	private AtomicBoolean disableDensityCellListener = new AtomicBoolean(false);
	private Property<Quantity<Torque>> cargoTanksLongitudinalMomentOfForceProperty = new SimpleObjectProperty<Quantity<Torque>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON_FORCE_METRE));
	private Property<Quantity<Torque>> cargoTanksVerticalMomentOfForceProperty = new SimpleObjectProperty<Quantity<Torque>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON_FORCE_METRE));
	private Property<Quantity<Torque>> cargoTanksTransverseMomentOfForceProperty = new SimpleObjectProperty<Quantity<Torque>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON_FORCE_METRE));
	private Property<Quantity<FreeSurfaceMoment>> cargoTanksFreeSurfaceMomentProperty = new SimpleObjectProperty<Quantity<FreeSurfaceMoment>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON_METRE));
	protected Property<Quantity<Mass>> cargoTanksMassProperty = new SimpleObjectProperty<Quantity<Mass>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON));
	private Property<Quantity<Mass>> cargoCurudeOilTanksMassProperty = new SimpleObjectProperty<Quantity<Mass>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON));
	private Property<Quantity<Mass>> cargoProductsTanksMassProperty = new SimpleObjectProperty<Quantity<Mass>>(Quantities.getQuantity(0, SmartLoadUnits.METRIC_TON));
	private Property<Quantity<Volume>> cargoCurudeOilTanksVolumeProperty = new SimpleObjectProperty<Quantity<Volume>>(Quantities.getQuantity(0, Units.CUBIC_METRE));
	private Property<Quantity<Volume>> cargoProductsTanksVolumeProperty = new SimpleObjectProperty<Quantity<Volume>>(Quantities.getQuantity(0, Units.CUBIC_METRE));
	private Map<Double, Quantity<Force>> deadWeightMap = new TreeMap<Double, Quantity<Force>>();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		notificationPane = new NotificationPane();
		notificationPane.setShowFromTop(true);
		notificationPane.getStyleClass().add(NotificationPane.STYLE_CLASS_DARK);
		VBox vBox = new VBox();
		notificationPane.showingProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (newValue) {
					vBox.setMinHeight(50);
				} else {
					vBox.setMinHeight(0);
				}
			}
		});
		notificationPane.setContent(vBox);
		customSpreadsheetHolderPane.getChildren().add(notificationPane);

		cargoTankSpreadsheetView = new CustomSpreadsheetView();
		cargoTankList = smartloadViewController.getCargoAndSlopTanks();
		initSpreadsheet(cargoTankList);
		initSpreadsheetListeners(cargoTankList);

		borderPane.setRight(smartloadViewController.getCalculationsVBox());
	}

	private void initSpreadsheet(List<Tank> cargoTankList) {
		cargoTankSpreadsheetView.getStyleClass().add("smartload");
		VBox.setVgrow(cargoTankSpreadsheetView, Priority.ALWAYS);
		cargoTankSpreadsheetView.setShowColumnHeader(false);
		cargoTankSpreadsheetView.setShowRowHeader(false);
		customSpreadsheetHolderPane.getChildren().add(cargoTankSpreadsheetView);

		cargoTankSpreadsheetView.getSelectionModel().setSelectionMode(true ? SelectionMode.MULTIPLE : SelectionMode.SINGLE);
		cargoTankSpreadsheetView.getGrid().setDisplaySelection(true);

		EventHandler<Event> editableEventHandler = new EventHandler<Event>() {
			@Override
			public void handle(Event event) {
				if (((SpreadsheetCell) event.getTarget()).isEditable())
					((SpreadsheetCell) event.getTarget()).getStyleClass().remove(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
				else
					((SpreadsheetCell) event.getTarget()).getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			}
		};
		GridBase grid = new GridBase(0, 0);
		ObservableList<ObservableList<SpreadsheetCell>> rows = FXCollections.observableArrayList();
		int rowIndex = 0;
		rows.add(getHeader(grid, rowIndex++));
		for (Tank tank : cargoTankList) {
			final ObservableList<SpreadsheetCell> tankRow = FXCollections.observableArrayList();

			SpreadsheetCell cargoTypeGradeCell = SpreadsheetCellType.STRING.createCell(rowIndex, 0, 1, 1, "");
			SpreadsheetCell tankNameCell = SpreadsheetCellType.STRING.createCell(rowIndex, 1, 1, 1, tank.getName());

			SpreadsheetCell ullageCell = new CustomSpreadsheetCellQuantityWithRangeType<Length>(smartloadPreferencePage.getLengthUnit(), Quantities.getQuantity(0, Units.METRE).to(smartloadPreferencePage.getLengthUnit().get()),
					shipTanksService.interpolateUllageFromVolume(tank, Quantities.getQuantity(0.0, Units.CUBIC_METRE)).to(smartloadPreferencePage.getLengthUnit().get()), notificationPane).createCell(rowIndex, 2, 1, 1,
							Quantities.getQuantity(0.0, Units.METRE).to(smartloadPreferencePage.getLengthUnit().get()));
			ullageCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
			smartloadPreferencePage.getLengthUnit().addListener(change -> {
				((CustomSpreadsheetCellQuantityWithRangeType<Length>) ullageCell.getCellType()).setLowerRangeValue(Quantities.getQuantity(0, Units.METRE).to(smartloadPreferencePage.getLengthUnit().get()));
				((CustomSpreadsheetCellQuantityWithRangeType<Length>) ullageCell.getCellType())
						.setUpperRangeValue(shipTanksService.interpolateUllageFromVolume(tank, Quantities.getQuantity(0.0, Units.CUBIC_METRE)).to(smartloadPreferencePage.getLengthUnit().get()));
			});

			SpreadsheetCell maxVolumeCell = new CustomSpreadsheetCellQuantityType<Volume>(smartloadPreferencePage.getVolumeUnit()).createCell(rowIndex, 3, 1, 1, tank.getVolume().to(smartloadPreferencePage.getVolumeUnit().get()));
			maxVolumeCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());

			SpreadsheetCell volumePercentCell = new CustomSpreadsheetCellQuantityWithRangeType<Dimensionless>(new SimpleObjectProperty(PERCENT_UNIT), Quantities.getQuantity(0, Units.PERCENT), Quantities.getQuantity(100, Units.PERCENT),
					notificationPane).createCell(rowIndex, 4, 1, 1, Quantities.getQuantity(0.0, Units.PERCENT));
			volumePercentCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());

			SpreadsheetCell tempCell = new CustomSpreadsheetCellQuantityWithRangeType<Temperature>(smartloadPreferencePage.getTemperatureUnit(),
					Quantities.getQuantity(-50, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()), Quantities.getQuantity(150, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()), notificationPane)
							.createCell(rowIndex, 5, 1, 1, Quantities.getQuantity(0.0, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()));
			tempCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
			smartloadPreferencePage.getTemperatureUnit().addListener(change -> {
				((CustomSpreadsheetCellQuantityWithRangeType<Temperature>) tempCell.getCellType()).setLowerRangeValue(Quantities.getQuantity(-50, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()));
				((CustomSpreadsheetCellQuantityWithRangeType<Temperature>) tempCell.getCellType()).setUpperRangeValue(Quantities.getQuantity(150, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()));
			});

			SpreadsheetCell densityCell = new CustomSpreadsheetCellQuantityWithRangeType<Density>(smartloadPreferencePage.getDensityUnit(),
					Quantities.getQuantity(0.4, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE).to(smartloadPreferencePage.getDensityUnit().get()),
					Quantities.getQuantity(1.1, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE).to(smartloadPreferencePage.getDensityUnit().get()), notificationPane).createCell(rowIndex, 6, 1, 1,
							Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE));
			densityCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
			smartloadPreferencePage.getDensityUnit().addListener(change -> {
				((CustomSpreadsheetCellQuantityWithRangeType<Density>) densityCell.getCellType()).setLowerRangeValue(Quantities.getQuantity(0.4, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE).to(smartloadPreferencePage.getDensityUnit().get()));
				((CustomSpreadsheetCellQuantityWithRangeType<Density>) densityCell.getCellType()).setUpperRangeValue(Quantities.getQuantity(1.1, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE).to(smartloadPreferencePage.getDensityUnit().get()));
			});
			SpreadsheetCell volumeCell = new CustomSpreadsheetCellQuantityWithRangeType<Volume>(smartloadPreferencePage.getVolumeUnit(), Quantities.getQuantity(0, Units.CUBIC_METRE).to(smartloadPreferencePage.getVolumeUnit().get()),
					tank.getVolume().to(smartloadPreferencePage.getVolumeUnit().get()), notificationPane).createCell(rowIndex, 7, 1, 1, Quantities.getQuantity(0.0, Units.CUBIC_METRE).to(smartloadPreferencePage.getVolumeUnit().get()));
			volumeCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
			smartloadPreferencePage.getVolumeUnit().addListener(change -> {
				((CustomSpreadsheetCellQuantityWithRangeType<Volume>) volumeCell.getCellType()).setLowerRangeValue(Quantities.getQuantity(0, Units.CUBIC_METRE).to(smartloadPreferencePage.getVolumeUnit().get()));
				((CustomSpreadsheetCellQuantityWithRangeType<Volume>) volumeCell.getCellType()).setUpperRangeValue(tank.getVolume().to(smartloadPreferencePage.getVolumeUnit().get()));
			});

			SpreadsheetCell weightCell = new CustomSpreadsheetCellQuantityWithRangeType<Mass>(smartloadPreferencePage.getMassUnit(), Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON).to(smartloadPreferencePage.getMassUnit().get()),
					SmartloadView.getMaxMassRange(densityCell, maxVolumeCell, smartloadPreferencePage.getMassUnit().get()), notificationPane).createCell(rowIndex, 8, 1, 1,
							Quantities.getQuantity(0.0, smartloadPreferencePage.getMassUnit().get()));
			weightCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
			smartloadPreferencePage.getMassUnit().addListener(change -> {
				((CustomSpreadsheetCellQuantityWithRangeType<Mass>) weightCell.getCellType()).setLowerRangeValue(Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON).to(smartloadPreferencePage.getMassUnit().get()));
				((CustomSpreadsheetCellQuantityWithRangeType<Mass>) weightCell.getCellType()).setUpperRangeValue(SmartloadView.getMaxMassRange(densityCell, maxVolumeCell, smartloadPreferencePage.getMassUnit().get()));
			});

			SpreadsheetCell vcfCell = new CustomSpreadsheetCellQuantityType<Dimensionless>(new SimpleObjectProperty(FACTOR_UNIT)).createCell(rowIndex, 9, 1, 1, Quantities.getQuantity(0.0, SmartLoadUnits.FACTOR));
			vcfCell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());

			Label typeTextLabel = new Label(CargoType.PRODUCTS.getName());
			typeTextLabel.setUserData(CargoType.PRODUCTS);
			typeTextLabel.getStyleClass().add("logbookOtherLabel");
			HBox cargoHBox = new HBox();
			cargoHBox.getChildren().add(typeTextLabel);
			cargoHBox.getStyleClass().addAll("smartLoadCargoHbox");
			cargoHBox.setAlignment(Pos.CENTER);

			cargoHBox.setOnMousePressed(e -> {
				SimpleObjectProperty<Object> cargoType = smartloadViewController.selectCargoTypeDetails(typeTextLabel.getUserData() != null ? (CargoType) typeTextLabel.getUserData() : null,
						cargoHBox.getUserData() != null ? (CargoLibrary) cargoHBox.getUserData() : null);
				if (cargoType.getValue() != null && cargoType.getValue() instanceof CargoLibrary) {
					typeTextLabel.setText(((CargoLibrary) cargoType.getValue()).getName());
					cargoHBox.setStyle("-fx-border-color:" + Color.web(((CargoLibrary) cargoType.getValue()).getColor() != null ? ((CargoLibrary) cargoType.getValue()).getColor() : "ffffff00").toString().replaceAll("0x", "#") + ";");
					densityCell.setItem(((CargoLibrary) cargoType.getValue()).getDensity());
					disableTemperatureCellListener.set(true);
					tempCell.setItem(((CargoLibrary) cargoType.getValue()).getTemperature());
					disableTemperatureCellListener.set(false);
					cargoHBox.setUserData(cargoType.getValue());
					typeTextLabel.setUserData(null);
					volumePercentCell.setItem(Quantities.getQuantity(0.0, Units.PERCENT));
					smartloadViewController.getStowagePlanController().reloadCargoType();;
				} else if (cargoType.getValue() != null && cargoType.getValue() instanceof CargoType) {
					typeTextLabel.setText(((CargoType) cargoType.getValue()).getName());
					cargoHBox.setStyle("-fx-border-color:transparent");
					cargoHBox.setUserData(null);
					if (typeTextLabel.getUserData()==null||!typeTextLabel.getUserData().equals(cargoType.getValue())) {
					typeTextLabel.setUserData((CargoType) cargoType.getValue());	
					densityCell.setItem(Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE));
					smartloadViewController.getStowagePlanController().reloadCargoType();
					}
				}
			    
			});
			
			cargoTypeGradeCell.setGraphic(cargoHBox);
			cargoTypeGradeCell.getStyleClass().add("spreadsheetCellBody");
			cargoTypeGradeCell.setEditable(false);

			tankRow.add(0, cargoTypeGradeCell);

			tankNameCell.getStyleClass().add("spreadsheetCellBody");
			tankNameCell.setEditable(false);
			tankRow.add(1, tankNameCell);

			ullageCell.setEditable(false);
			ullageCell.getStyleClass().add("spreadsheetCellBody");
			ullageCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			ullageCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(2, ullageCell);

			maxVolumeCell.setEditable(false);
			maxVolumeCell.getStyleClass().add("spreadsheetCellBody");
			maxVolumeCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			maxVolumeCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(3, maxVolumeCell);

			volumePercentCell.setEditable(false);
			volumePercentCell.getStyleClass().add("spreadsheetCellBody");
			volumePercentCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			volumePercentCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(4, volumePercentCell);

			tempCell.setEditable(false);
			tempCell.getStyleClass().add("spreadsheetCellBody");
			tempCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			tempCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(5, tempCell);

			densityCell.getStyleClass().add("spreadsheetCellBody");
			densityCell.itemProperty().addListener(new ChangeListener<Object>() {

				@Override
				public void changed(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
					if (disableDensityCellListener.get() == false) {
						if (((ComparableQuantity<Density>) newValue).isEquivalentTo(Quantities.getQuantity(0.0, SmartLoadUnits.KILOGRAM_PER_CUBIC_METRE).to(smartloadPreferencePage.getDensityUnit().get()))) {
							cargoHBox.setStyle("-fx-border-color:transparent");
							cargoHBox.setUserData(null);
							volumePercentCell.setItem(Quantities.getQuantity(0.0, Units.PERCENT));
							disableTemperatureCellListener.set(true);
							tempCell.setItem(Quantities.getQuantity(0.0, Units.CELSIUS));
							disableTemperatureCellListener.set(true);
							ullageCell.setEditable(false);
							volumePercentCell.setEditable(false);
							tempCell.setEditable(false);
							volumeCell.setEditable(false);
							weightCell.setEditable(false);
							ullageCell.setItem(shipTanksService.interpolateUllageFromVolume(tank, (Quantity<Volume>) volumeCell.getItem()));
							((CustomSpreadsheetCellQuantityWithRangeType<Mass>) weightCell.getCellType()).setUpperRangeValue(SmartloadView.getMaxMassRange(densityCell, maxVolumeCell, smartloadPreferencePage.getMassUnit().get()));

						} else if (cargoHBox.getUserData() != null && !((ComparableQuantity<Density>) newValue).isEquivalentTo(((CargoLibrary) cargoHBox.getUserData()).getDensity().to(smartloadPreferencePage.getDensityUnit().get()))) {
							cargoHBox.setStyle("-fx-border-color:transparent");
							cargoHBox.setUserData(null);
							disableTemperatureCellListener.set(true);
							tempCell.setItem(Quantities.getQuantity(15.0, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()));
							disableTemperatureCellListener.set(false);
							ullageCell.setEditable(true);
							volumePercentCell.setEditable(true);
							tempCell.setEditable(true);
							volumeCell.setEditable(true);
							weightCell.setEditable(true);
							ullageCell.setItem(shipTanksService.interpolateUllageFromVolume(tank, (Quantity<Volume>) volumeCell.getItem()));
							((CustomSpreadsheetCellQuantityWithRangeType<Mass>) weightCell.getCellType()).setUpperRangeValue(SmartloadView.getMaxMassRange(densityCell, maxVolumeCell, smartloadPreferencePage.getMassUnit().get()));

						} else {
							ullageCell.setEditable(true);
							volumePercentCell.setEditable(true);
							tempCell.setEditable(true);
							volumeCell.setEditable(true);
							weightCell.setEditable(true);
							if (((ComparableQuantity<Temperature>) tempCell.getItem()).isEquivalentTo(Quantities.getQuantity(0.0, smartloadPreferencePage.getTemperatureUnit().get()))) {
								disableTemperatureCellListener.set(true);
								tempCell.setItem(Quantities.getQuantity(15.0, Units.CELSIUS).to(smartloadPreferencePage.getTemperatureUnit().get()));
								disableTemperatureCellListener.set(false);
							}
							ullageCell.setItem(shipTanksService.interpolateUllageFromVolume(tank, (Quantity<Volume>) volumeCell.getItem()));
							((CustomSpreadsheetCellQuantityWithRangeType<Mass>) weightCell.getCellType()).setUpperRangeValue(SmartloadView.getMaxMassRange(densityCell, maxVolumeCell, smartloadPreferencePage.getMassUnit().get()));

						}
					}
				}
			});
			tankRow.add(6, densityCell);

			volumeCell.setEditable(false);
			volumeCell.getStyleClass().add("spreadsheetCellBody");
			volumeCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			volumeCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(7, volumeCell);

			weightCell.setEditable(false);
			weightCell.getStyleClass().add("spreadsheetCellBody");
			weightCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			weightCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(8, weightCell);

			vcfCell.setEditable(false);
			vcfCell.getStyleClass().add("spreadsheetCellBody");
			vcfCell.getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			vcfCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, editableEventHandler);
			tankRow.add(9, vcfCell);
			rows.add(tankRow);
			rowIndex++;
		}
		rows.add(getFooter(grid, rowIndex++));
		grid.setRows(rows);
		cargoTankSpreadsheetView.setGrid(grid);
		grid.setRowHeightCallback(new GridBase.MapBasedRowHeightFactory(generateRowHeight(rows.size())));
		((Pane) cargoTankSpreadsheetView.getParent()).widthProperty().addListener((obs, oldval, newval) -> {
			cargoTankSpreadsheetView.getColumns().forEach(col -> col.setPrefWidth(newval.doubleValue() / 10 - 2));
		});

		cargoTankSpreadsheetView.getContextMenu().getItems().remove(2);
	}

	private void initSpreadsheetListeners(List<Tank> cargoTankList) {

		smartloadPreferencePage.getLengthUnit().addListener(change -> {
			JavaFXUtils.refreshCellText(cargoTankSpreadsheetView);
		});
		smartloadPreferencePage.getMassUnit().addListener(change -> {
			JavaFXUtils.refreshCellText(cargoTankSpreadsheetView);
		});
		smartloadPreferencePage.getVolumeUnit().addListener(change -> {
			JavaFXUtils.refreshCellText(cargoTankSpreadsheetView);
		});
		smartloadPreferencePage.getTemperatureUnit().addListener(change -> {
			JavaFXUtils.refreshCellText(cargoTankSpreadsheetView);
		});
		smartloadPreferencePage.getAreaMomentOfInertiaUnit().addListener(change -> {
			JavaFXUtils.refreshCellText(cargoTankSpreadsheetView);
		});
		smartloadPreferencePage.getDensityUnit().addListener(change -> {
			JavaFXUtils.refreshCellText(cargoTankSpreadsheetView);
		});

		cargoTankSpreadsheetView.getSelectionModel().getSelectedCells().addListener(new ListChangeListener<TablePosition>() {
			@Override
			public void onChanged(Change<? extends TablePosition> c) {
				List<TablePosition> selectedTablePositions = cargoTankSpreadsheetView.getSelectionModel().getSelectedCells();
				Map<Object, List<TablePosition>> selectionsPerRow = selectedTablePositions.stream().collect(Collectors.groupingBy(TablePosition::getRow));
				if (selectionsPerRow.keySet().size() == 1) {
					int rowIndex = (Integer) selectionsPerRow.keySet().iterator().next();
					int columnIndex = 1;
					SpreadsheetCell cell = cargoTankSpreadsheetView.getGrid().getRows().get(cargoTankSpreadsheetView.getModelRow(rowIndex)).get(cargoTankSpreadsheetView.getModelColumn(columnIndex));
					String tankName = (String) cell.getItem();
					smartloadViewController.selectTankSVGFromTableRow(tankName);
				} else {
					smartloadViewController.selectTankSVGFromTableRow(null);
				}
			}
		});

		for (ObservableList<SpreadsheetCell> row : cargoTankSpreadsheetView.getGrid().getRows()) {
			int rowIndex = cargoTankSpreadsheetView.getGrid().getRows().indexOf(row);
			if (rowIndex != 0 && rowIndex != cargoTankSpreadsheetView.getGrid().getRows().size() - 1) {
				Tank tank = cargoTankList.get(rowIndex - 1);
				SpreadsheetCell cargoLibraryCell = row.get(0);
				SpreadsheetCell ullageCell = row.get(2);
				SpreadsheetCell volPercentCell = row.get(4);
				SpreadsheetCell temperatureCell = row.get(5);
				SpreadsheetCell densityCell = row.get(6);
				SpreadsheetCell volCell = row.get(7);
				SpreadsheetCell weightCell = row.get(8);

				volCell.addEventHandler(SpreadsheetCell.EDITABLE_EVENT_TYPE, new EventHandler<Event>() {
					private HeterogeneousBidirectionalBinder volumeVolumePercentageBinder;
					private HeterogeneousBidirectionalBinder volumeUllageBinder;
					private HeterogeneousBidirectionalBinder volumeMassBinder;

					@Override
					public void handle(Event event) {
						if (((SpreadsheetCell) event.getTarget()).isEditable()) {
							volumeVolumePercentageBinder = bindBidirectionalVolumeVolumePercentage(tank.getVolume(), volCell, volPercentCell);
							volumeUllageBinder = bindBidirectionalVolumeUllage(tank, volCell, ullageCell);
							volumeMassBinder = bindBidirectionalVolumeMass(densityCell, volCell, weightCell);
						} else {
							if (volumeVolumePercentageBinder != null)
								volumeVolumePercentageBinder.unbind();
							if (volumeUllageBinder != null)
								volumeUllageBinder.unbind();
							if (volumeMassBinder != null)
								volumeMassBinder.unbind();
						}
						AtomicBoolean disableDensityCellListener = new AtomicBoolean(false);
						densityCell.itemProperty().addListener(new ChangeListener<Object>() {
							@Override
							public void changed(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
								if (!disableDensityCellListener.get())
									volumeMassBinder.changed(volumeMassBinder.getProperty1(), null, volumeMassBinder.getProperty1().getValue());
							}
						});

						temperatureCell.itemProperty().addListener(new ChangeListener<Object>() {
							@Override
							public void changed(ObservableValue<? extends Object> observable, Object oldValue, Object newValue) {
								if (!disableTemperatureCellListener.get()) {
								TempDensTableType tempDensTableType = null;
								// default
								if (((Quantity<Density>) densityCell.getItem()).getValue().doubleValue() > 0) {
									try {
										tempDensTableType = smartloadViewController.getTempDensTableTypes().stream().filter(p -> p.getName().equals("API Table 54A")).findFirst().get();
									} catch (NoSuchElementException e) {
										logger.error("Cant find TempDensTableType API Table 54A", e);
									}
									CargoLibrary cargoRow = cargoLibraryCell.getGraphic().getUserData() != null ? (CargoLibrary) cargoLibraryCell.getGraphic().getUserData() : null;
									if (cargoRow != null && cargoRow.getApiTable() != null) {
										TempDensTableType apiTableName = cargoRow.getApiTable();
										Optional<TempDensTableType> matchingObject = smartloadViewController.getTempDensTableTypes().stream().filter(p -> p.getName().equals(apiTableName.getName())).findFirst();
										tempDensTableType = matchingObject.get();
									}
									;
									Quantity<Density> newDensity = (Quantity<Density>) tempDensityService.interpolateDensityFromTemperature(tempDensTableType, (Quantity<Temperature>) oldValue, (Quantity<Density>) densityCell.getItem(),
											(Quantity<Temperature>) newValue);
									Quantity<Volume> newVol = (Quantity<Volume>) ((Quantity<Volume>) weightCell.getItem()).divide(newDensity);
									if (((ComparableQuantity<Volume>) newVol.to(smartloadPreferencePage.getVolumeUnit().get())).isLessThanOrEqualTo(tank.getVolume().to(smartloadPreferencePage.getVolumeUnit().get()))) {
										    disableDensityCellListener.set(true);
											densityCell.setItem(newDensity);
											volumeMassBinder.changed(volumeMassBinder.getProperty2(), null, volumeMassBinder.getProperty2().getValue());
											disableDensityCellListener.set(false);
										
									} else {
										CustomSpreadsheetCellQuantityWithRangeType<Volume> volType = ((CustomSpreadsheetCellQuantityWithRangeType<Volume>) volCell.getCellType());
										volType.getNotificationPane().show("Valid value range: " + volType.getLowerRangeValue() + " - " + volType.getUpperRangeValue() + " Trying to update volume from temperature to "
												+ newVol.to(smartloadPreferencePage.getVolumeUnit().get()));
									}
								} else if (((Quantity<Density>) densityCell.getItem()).getValue().doubleValue() == 0) {
									volPercentCell.setItem(Quantities.getQuantity(0.0, Units.PERCENT));
								}
							}
						  }
						});
					}
				});

				volPercentCell.itemProperty().addListener(new ChangeListener<Object>() {
					@Override
					public void changed(ObservableValue observable, Object oldValue, Object newValue) {
						CargoLibrary cargoRow = cargoLibraryCell.getGraphic().getUserData() != null ? (CargoLibrary) cargoLibraryCell.getGraphic().getUserData() : null;
						if (newValue.toString().contains("%")) {
							smartloadViewController.getGradientFillTop(cargoRow, tank, newValue.toString());
							smartloadViewController.getGradientFillSide(cargoRow, tank, newValue.toString());
						} else {
							Quantity<Dimensionless> perc = ((Quantity<Dimensionless>) newValue).to(Units.PERCENT);
							smartloadViewController.getGradientFillTop(cargoRow, tank, perc.toString());
							smartloadViewController.getGradientFillSide(cargoRow, tank, perc.toString());
						}
					}
				});
				// Calculate total Listener//
				volCell.itemProperty().addListener(new ChangeListener<Object>() {
					@Override
					public void changed(ObservableValue observable, Object oldValue, Object newValue) {
						ObservableList<ObservableList<SpreadsheetCell>> allRow = cargoTankSpreadsheetView.getGrid().getRows();
						ObservableList<SpreadsheetCell> totalRow = cargoTankSpreadsheetView.getGrid().getRows().get(cargoTankList.size() + 1);
						SpreadsheetCell totalVolCell = totalRow.get(7);
						Quantity<Volume> totalVol = Quantities.getQuantity(0.0, smartloadPreferencePage.getVolumeUnit().get());
						Quantity<Volume> totalCrudeOilVolume = Quantities.getQuantity(0.0, smartloadPreferencePage.getVolumeUnit().get());
						Quantity<Volume> totalProductOilVolume = Quantities.getQuantity(0.0, smartloadPreferencePage.getVolumeUnit().get());
						for (ObservableList<SpreadsheetCell> row : allRow) {
							SpreadsheetCell cargoTypeCell=row.get(0);
							if (allRow.indexOf(row) > 0 && allRow.indexOf(row) < cargoTankList.size() + 1) {
								totalVol = (Quantity<Volume>) totalVol.add((Quantity<Volume>) row.get(7).getItem());
								
								CargoLibrary cargoLibRow = cargoTypeCell.getGraphic().getUserData() != null ? (CargoLibrary) cargoTypeCell.getGraphic().getUserData() : null;
								CargoType cargoTypeRow = (CargoType) ((HBox) cargoTypeCell.getGraphic()).getChildren().get(0).getUserData();
								if ((cargoLibRow != null && cargoLibRow.getCargoType().equals(CargoType.CRUDE_OIL))){
									totalCrudeOilVolume = (Quantity<Volume>) totalCrudeOilVolume.add((Quantity<Volume>) row.get(7).getItem());
								}
								if ((cargoTypeRow != null && cargoTypeRow.equals(CargoType.CRUDE_OIL))) {
									totalCrudeOilVolume = (Quantity<Volume>) totalCrudeOilVolume.add((Quantity<Volume>) row.get(7).getItem());
								}
								if ((cargoLibRow != null && cargoLibRow.getCargoType().equals(CargoType.PRODUCTS))) {
									totalProductOilVolume = (Quantity<Volume>) totalProductOilVolume.add((Quantity<Volume>) row.get(7).getItem());
								}
								if ((cargoTypeRow != null && cargoTypeRow.equals(CargoType.PRODUCTS))) {
									totalProductOilVolume = (Quantity<Volume>) totalProductOilVolume.add((Quantity<Volume>) row.get(7).getItem());
								}
							}

						}
						cargoCurudeOilTanksVolumeProperty.setValue(totalCrudeOilVolume);
						cargoProductsTanksVolumeProperty.setValue(totalProductOilVolume);
						totalVolCell.setEditable(true);
						totalVolCell.setItem(totalVol);
						totalVolCell.setEditable(false);
					}
				});
				weightCell.itemProperty().addListener(new ChangeListener<Object>() {

					@Override
					public void changed(ObservableValue observable, Object oldValue, Object newValue) {
						ObservableList<ObservableList<SpreadsheetCell>> allRow = cargoTankSpreadsheetView.getGrid().getRows();
						ObservableList<SpreadsheetCell> totalRow = cargoTankSpreadsheetView.getGrid().getRows().get(cargoTankList.size() + 1);
						SpreadsheetCell totalWeightCell = totalRow.get(8);
						Quantity<Mass> totalWeight = Quantities.getQuantity(0.0, smartloadPreferencePage.getMassUnit().get());
						Quantity<Torque> totalLongitudinalMomentOfForce = Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_FORCE_METRE);
						Quantity<Torque> totalVerticalMomentOfForce = Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_FORCE_METRE);
						Quantity<Torque> totalTransverseMomentOfForce = Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_FORCE_METRE);
						Quantity<FreeSurfaceMoment> totalFreeSurfaceMoment = Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_METRE);
						Quantity<Mass> totalCrudeOilWeight = Quantities.getQuantity(0.0, smartloadPreferencePage.getMassUnit().get());
						Quantity<Mass> totalProductOilWeight = Quantities.getQuantity(0.0, smartloadPreferencePage.getMassUnit().get());
						deadWeightMap.clear();
						for (ObservableList<SpreadsheetCell> row : allRow) {
							int rowIndex2 = allRow.indexOf(row);
							if (rowIndex2 > 0 && rowIndex2 < cargoTankList.size() + 1) {
								Quantity<Density> density = (Quantity<Density>) row.get(6).getItem();
								SpreadsheetCell cargoTypeCell=row.get(0);
								Quantity<Mass> mass = (Quantity<Mass>) row.get(8).getItem();
								totalWeight = (Quantity<Mass>) totalWeight.add(mass);

								Quantity<Volume> volume = (Quantity<Volume>) row.get(7).getItem();
								Tank tank2 = cargoTankList.get(rowIndex2 - 1);
								Quantity<Force> force = (Quantity<Force>) mass.multiply(Quantities.getQuantity(1.0, UCUM.ACCELERATION_OF_FREEFALL));
								Quantity<Torque> tankLongitudinalMomentOfForce = (Quantity<Torque>) shipTanksService.interpolateLCGFromVolume(tank2, volume).multiply(force);
								Quantity<Torque> tankVerticalMomentOfForce = (Quantity<Torque>) shipTanksService.interpolateVCGFromVolume(tank2, volume).multiply(force);
								Quantity<Torque> tankTransverseMomentOfForce = (Quantity<Torque>) shipTanksService.interpolateTCGFromVolume(tank2, volume).multiply(force);
								Quantity<FreeSurfaceMoment> tankFreeSurfaceMoment = (Quantity<FreeSurfaceMoment>) shipTanksService.interpolateINERTIAFromVolume(tank2, volume).multiply(density);
								totalLongitudinalMomentOfForce = totalLongitudinalMomentOfForce.add(tankLongitudinalMomentOfForce.to(SmartLoadUnits.METRIC_TON_FORCE_METRE));
								totalVerticalMomentOfForce = totalVerticalMomentOfForce.add(tankVerticalMomentOfForce.to(SmartLoadUnits.METRIC_TON_FORCE_METRE));
								totalTransverseMomentOfForce = totalTransverseMomentOfForce.add(tankTransverseMomentOfForce.to(SmartLoadUnits.METRIC_TON_FORCE_METRE));
								totalFreeSurfaceMoment = totalFreeSurfaceMoment.add(tankFreeSurfaceMoment.to(SmartLoadUnits.METRIC_TON_METRE));

								shearBendingService.distributeTankWeightInFrames(deadWeightMap, tank2, force);
								CargoLibrary cargoLibRow = cargoTypeCell.getGraphic().getUserData() != null ? (CargoLibrary) cargoTypeCell.getGraphic().getUserData() : null;
								CargoType cargoTypeRow = (CargoType) ((HBox) cargoTypeCell.getGraphic()).getChildren().get(0).getUserData();
								if ((cargoLibRow != null && cargoLibRow.getCargoType().equals(CargoType.CRUDE_OIL))){
									totalCrudeOilWeight = (Quantity<Mass>) totalCrudeOilWeight.add(mass);
								}
								if ((cargoTypeRow != null && cargoTypeRow.equals(CargoType.CRUDE_OIL))) {
									totalCrudeOilWeight = (Quantity<Mass>) totalCrudeOilWeight.add(mass);
								}
								if ((cargoLibRow != null && cargoLibRow.getCargoType().equals(CargoType.PRODUCTS))) {
									totalProductOilWeight = (Quantity<Mass>) totalProductOilWeight.add(mass);
								}
								if ((cargoTypeRow != null && cargoTypeRow.equals(CargoType.PRODUCTS))) {
									totalProductOilWeight = (Quantity<Mass>) totalProductOilWeight.add(mass);
								}
							}

						}
						
						cargoCurudeOilTanksMassProperty.setValue(totalCrudeOilWeight);
						cargoProductsTanksMassProperty.setValue(totalProductOilWeight);
						
						cargoTanksMassProperty.setValue(totalWeight);
						cargoTanksLongitudinalMomentOfForceProperty.setValue(totalLongitudinalMomentOfForce);
						cargoTanksVerticalMomentOfForceProperty.setValue(totalVerticalMomentOfForce);
						cargoTanksTransverseMomentOfForceProperty.setValue(totalTransverseMomentOfForce);
						cargoTanksFreeSurfaceMomentProperty.setValue(totalFreeSurfaceMoment);
						totalWeightCell.setEditable(true);
						totalWeightCell.setItem(totalWeight);
						totalWeightCell.setEditable(false);
					}
				});
				ullageCell.itemProperty().addListener(new ChangeListener<Object>() {
					@Override
					public void changed(ObservableValue observable, Object oldValue, Object newValue) {
						ObservableList<ObservableList<SpreadsheetCell>> allRow = cargoTankSpreadsheetView.getGrid().getRows();
						ObservableList<SpreadsheetCell> totalRow = cargoTankSpreadsheetView.getGrid().getRows().get(cargoTankList.size() + 1);
						SpreadsheetCell totalUllageCell = totalRow.get(2);
						Quantity<Length> totalUllage = Quantities.getQuantity(0.0, smartloadPreferencePage.getLengthUnit().get());
						for (ObservableList<SpreadsheetCell> row : allRow) {
							if (allRow.indexOf(row) > 0 && allRow.indexOf(row) < cargoTankList.size() + 1) {
								totalUllage = (Quantity<Length>) totalUllage.add((Quantity<Length>) row.get(2).getItem());
							}

						}
						totalUllageCell.setEditable(true);
						totalUllageCell.setItem(totalUllage);
						totalUllageCell.setEditable(false);
						if (((Quantity<Density>) densityCell.getItem()).getValue().doubleValue() == 0) {
							ullageCell.setItem(Quantities.getQuantity(0.0, Units.METRE));
						}
					}
				});
				// Calculate total Listener//
			}

		}
	}

	private ObservableList<SpreadsheetCell> getHeader(GridBase grid, int row) {

		final ObservableList<SpreadsheetCell> title = FXCollections.observableArrayList();

		SpreadsheetCell cell = SpreadsheetCellType.STRING.createCell(row, 0, 1, 1, "GRADE");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(0, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 1, 1, 1, "TANK");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(1, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 2, 1, 1, "ULLAGE (" + smartloadPreferencePage.getLengthUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("ULLAGE (", smartloadPreferencePage.getLengthUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(2, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 3, 1, 1, "MAX VOL (" + smartloadPreferencePage.getVolumeUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("MAX VOL (", smartloadPreferencePage.getVolumeUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(3, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 4, 1, 1, "VOL (" + PERCENT_UNIT + ")");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(4, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 5, 1, 1, "TEMP (" + smartloadPreferencePage.getTemperatureUnit() + ")");
		cell.itemProperty().bind(Bindings.concat("TEMP (", smartloadPreferencePage.getTemperatureUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(5, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 6, 1, 1, "DENS @ AIR (" + smartloadPreferencePage.getDensityUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("DENS @ AIR (", smartloadPreferencePage.getDensityUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(6, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 7, 1, 1, "VOL (" + smartloadPreferencePage.getVolumeUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("VOL (", smartloadPreferencePage.getVolumeUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(7, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 8, 1, 1, "WEIGHT (" + smartloadPreferencePage.getMassUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("WEIGHT (", smartloadPreferencePage.getMassUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(8, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 9, 1, 1, "VCF");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(9, cell);
		return title;
	}

	private ObservableList<SpreadsheetCell> getFooter(GridBase grid, int row) {
		final ObservableList<SpreadsheetCell> title = FXCollections.observableArrayList();

		SpreadsheetCell cell = SpreadsheetCellType.STRING.createCell(row, 0, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(0, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 1, 1, 1, "TOTAL CARGO");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		cell.getStyleClass().add("spreadsheetCellFooter");
		title.add(1, cell);
		cell = new CustomSpreadsheetCellQuantityType<Length>(smartloadPreferencePage.getLengthUnit()).createCell(row, 2, 1, 1, Quantities.getQuantity(0.0, Units.METRE).to(smartloadPreferencePage.getLengthUnit().get()));
		cell.setEditable(false);
		cell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(2, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 3, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(3, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 4, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(4, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 5, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(5, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 6, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(6, cell);

		cell = new CustomSpreadsheetCellQuantityType<Volume>(smartloadPreferencePage.getVolumeUnit()).createCell(row, 7, 1, 1, Quantities.getQuantity(0.0, Units.CUBIC_METRE).to(smartloadPreferencePage.getVolumeUnit().get()));
		cell.setEditable(false);
		cell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(7, cell);

		cell = new CustomSpreadsheetCellQuantityType<Mass>(smartloadPreferencePage.getMassUnit()).createCell(row, 8, 1, 1, Quantities.getQuantity(0.0, Units.KILOGRAM).to(smartloadPreferencePage.getMassUnit().get()));
		cell.setEditable(false);
		cell.formatProperty().bindBidirectional(smartloadPreferencePage.getQuantityPrecision());
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(8, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 9, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(9, cell);
		return title;
	}

	private Map<Integer, Double> generateRowHeight(Integer rowsize) {
		Map<Integer, Double> rowHeight = new HashMap<>();
		for (int i = 0; i <= rowsize; i++) {
			rowHeight.put(i, 35.0);
		}

		return rowHeight;
	}

	private HeterogeneousBidirectionalBinder bindBidirectionalVolumeVolumePercentage(Quantity<Volume> maxVolume, SpreadsheetCell volCell, SpreadsheetCell volPercentCell) {

		ObjectProperty<? extends Quantity<Volume>> volumeProperty = (ObjectProperty<? extends Quantity<Volume>>) volCell.itemProperty();
		ObjectProperty<? extends Quantity<Dimensionless>> percentProperty = (ObjectProperty<? extends Quantity<Dimensionless>>) volPercentCell.itemProperty();

		Function<Quantity<Volume>, Quantity<Dimensionless>> volumeToVolPercent = newValue -> {
			if (maxVolume == null || newValue == null)
				return null;
			return (Quantity<Dimensionless>) newValue.divide(maxVolume);
		};
		Function<Quantity<Dimensionless>, Quantity<Volume>> volPercentToVolume = newValue -> {
			if (maxVolume == null || newValue == null)
				return null;
			return (Quantity<Volume>) newValue.multiply(maxVolume);
		};

		HeterogeneousBidirectionalBinder volumeVolPercentBinding = new HeterogeneousBidirectionalBinder(volumeProperty, percentProperty, volumeToVolPercent, volPercentToVolume);
		return volumeVolPercentBinding;
	}

	public HeterogeneousBidirectionalBinder bindBidirectionalVolumeUllage(Tank tank, SpreadsheetCell volCell, SpreadsheetCell ullageCell) {
		ObjectProperty<? extends Quantity<Volume>> volumeProperty = (ObjectProperty<? extends Quantity<Volume>>) volCell.itemProperty();
		ObjectProperty<? extends Quantity<Length>> ullageProperty = (ObjectProperty<? extends Quantity<Length>>) ullageCell.itemProperty();

		Function<Quantity<Volume>, Quantity<Length>> volumeToUllage = newValue -> {
			if (tank == null || newValue == null)
				return null;
			return shipTanksService.interpolateUllageFromVolume(tank, newValue);
		};
		Function<Quantity<Length>, Quantity<Volume>> ullageToVolume = newValue -> {
			if (tank == null || newValue == null)
				return null;
			return shipTanksService.interpolateVolumeFromUllage(tank, newValue);
		};

		HeterogeneousBidirectionalBinder volumeUllageBinding = new HeterogeneousBidirectionalBinder(volumeProperty, ullageProperty, volumeToUllage, ullageToVolume);
		return volumeUllageBinding;
	}

	private HeterogeneousBidirectionalBinder bindBidirectionalVolumeMass(SpreadsheetCell densityCell, SpreadsheetCell volCell, SpreadsheetCell weightCell) {
		ObjectProperty<? extends Quantity<Volume>> volumeProperty = (ObjectProperty<? extends Quantity<Volume>>) volCell.itemProperty();
		ObjectProperty<? extends Quantity<Mass>> massProperty = (ObjectProperty<? extends Quantity<Mass>>) weightCell.itemProperty();

		Function<Quantity<Volume>, Quantity<Mass>> volumeToMass = newValue -> {
			if (densityCell == null || densityCell.getItem() == null || newValue == null)
				return null;
			return (Quantity<Mass>) volumeProperty.getValue().multiply((Quantity<Density>) densityCell.getItem());
		};
		Function<Quantity<Mass>, Quantity<Volume>> massToVolume = newValue -> {
			if (densityCell == null || densityCell.getItem() == null || newValue == null)
				return null;
			if (((Quantity<Density>) densityCell.getItem()).getValue().doubleValue() > 0) {
				return (Quantity<Volume>) massProperty.getValue().divide((Quantity<Density>) densityCell.getItem());
			} else {
				return (Quantities.getQuantity(0.0, Units.CUBIC_METRE));
			}
		};

		HeterogeneousBidirectionalBinder volumeMassBinding = new HeterogeneousBidirectionalBinder(volumeProperty, massProperty, volumeToMass, massToVolume);
		return volumeMassBinding;
	}

	public void openTankLoad(TankSavedData tankSavedData) {
		if (tankSavedData != null && tankSavedData.getTankLoading() != null && tankSavedData.getTankLoading().size() > 0) {
			for (TankLoading tankLoad : tankSavedData.getTankLoading()) {
				for (ObservableList<SpreadsheetCell> row : cargoTankSpreadsheetView.getGrid().getRows()) {
					int rowIndex = cargoTankSpreadsheetView.getGrid().getRows().indexOf(row);
					if (rowIndex != 0 && rowIndex != cargoTankSpreadsheetView.getGrid().getRows().size() - 1) {
						SpreadsheetCell cargoCell = row.get(0);
						SpreadsheetCell tankNameCell = row.get(1);
						SpreadsheetCell volPercentCell = row.get(4);
						SpreadsheetCell temperatureCell = row.get(5);
						SpreadsheetCell densityCell = row.get(6);
						if (tankNameCell.getText().equalsIgnoreCase(tankLoad.getTank().getName())) {
							HBox cargoHbox = (HBox) cargoCell.getGraphic();
							Label cargoLabel = (Label) cargoHbox.getChildren().get(0);
							if (tankLoad.getCargoLibrary() != null) {
								cargoLabel.setText(tankLoad.getCargoLibrary().getName());
								cargoHbox.setStyle("-fx-border-color:" + Color.web(tankLoad.getCargoLibrary().getColor() != null ? tankLoad.getCargoLibrary().getColor() : "ffffff00").toString().replaceAll("0x", "#") + ";");
								cargoHbox.setUserData(tankLoad.getCargoLibrary());
								cargoLabel.setUserData(null);
							} else if (tankLoad.getCargoType() != null) {
								cargoLabel.setText(tankLoad.getCargoType().getName());
								cargoLabel.setUserData(tankLoad.getCargoType());
								cargoHbox.setStyle("-fx-border-color:transparent");
								cargoHbox.setUserData(null);
							}
							disableTemperatureCellListener.set(true);
							temperatureCell.setItem(tankLoad.getTemperature());
							densityCell.setItem(tankLoad.getDensity());
							disableTemperatureCellListener.set(false);
							volPercentCell.setItem(Quantities.getQuantity(tankLoad.getVolumeFillPercentage(), Units.PERCENT));
						}
					}
				}
			}
		} else {
			for (ObservableList<SpreadsheetCell> row : cargoTankSpreadsheetView.getGrid().getRows()) {
				int rowIndex = cargoTankSpreadsheetView.getGrid().getRows().indexOf(row);
				if (rowIndex != 0 && rowIndex != cargoTankSpreadsheetView.getGrid().getRows().size() - 1) {
					SpreadsheetCell densityCell = row.get(6);
					disableTemperatureCellListener.set(true);
					densityCell.setItem(Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE));
					disableTemperatureCellListener.set(false);
					SpreadsheetCell cargoCell = row.get(0);
					HBox cargoHbox = (HBox) cargoCell.getGraphic();
					Label cargoLabel = (Label) cargoHbox.getChildren().get(0);
					cargoLabel.setText(CargoType.PRODUCTS.getName());
					cargoLabel.setUserData(CargoType.PRODUCTS);
					cargoHbox.setUserData(null);
				}
			}
		}

	}

	public void reloadCargoLib(ObservableList<CargoLibrary> cargoList) {
		for (ObservableList<SpreadsheetCell> row : cargoTankSpreadsheetView.getGrid().getRows()) {
			int rowIndex = cargoTankSpreadsheetView.getGrid().getRows().indexOf(row);
			if (rowIndex != 0 && rowIndex != cargoTankSpreadsheetView.getGrid().getRows().size() - 1) {
				SpreadsheetCell cargoCell = row.get(0);
				SpreadsheetCell densityCell = row.get(6);
				HBox cargoHbox = (HBox) cargoCell.getGraphic();
				CargoLibrary cargoRow = cargoHbox.getUserData() != null ? (CargoLibrary) cargoHbox.getUserData() : null;
				Label cargoLabel = (Label) cargoHbox.getChildren().get(0);
				if (cargoRow != null) {
					for (CargoLibrary cargo : cargoList) {
						if (cargoRow != null && cargoRow.getId().equals(cargo.getId())) {
							disableDensityCellListener.set(true);
							densityCell.setItem(cargo.getDensity());
							cargoCell.getGraphic().setStyle("-fx-border-color:" + Color.web(cargo.getColor() != null ? cargo.getColor() : "ffffff00").toString().replaceAll("0x", "#") + ";");
							cargoHbox.setUserData(cargo);
							cargoCell.setItem(cargo);
							cargoLabel.setText(cargo.getName());
							cargoLabel.setUserData(null);
							disableDensityCellListener.set(false);
						}
					}

				}
			}
		}
	}

	public void reloadCargoRemoved(CargoLibrary cargoRemoved) {
		for (ObservableList<SpreadsheetCell> row : cargoTankSpreadsheetView.getGrid().getRows()) {
			int rowIndex = cargoTankSpreadsheetView.getGrid().getRows().indexOf(row);
			if (rowIndex != 0 && rowIndex != cargoTankSpreadsheetView.getGrid().getRows().size() - 1) {
				SpreadsheetCell cargoCell = row.get(0);
				SpreadsheetCell densityCell = row.get(6);
				HBox cargoHbox = (HBox) cargoCell.getGraphic();
				CargoLibrary cargoRow = cargoHbox.getUserData() != null ? (CargoLibrary) cargoHbox.getUserData() : null;
				Label cargoLabel = (Label) cargoHbox.getChildren().get(0);
				if (cargoRow != null && cargoRow.getId().equals(cargoRemoved.getId())) {
					cargoLabel.setText(CargoType.PRODUCTS.getName());
					cargoLabel.setUserData(CargoType.PRODUCTS);
					cargoHbox.setStyle("-fx-border-color:transparent");
					cargoHbox.setUserData(null);
					densityCell.setItem(Quantities.getQuantity(0.0, SmartLoadUnits.METRIC_TON_PER_CUBIC_METRE));
				}
			}
		}
	}

	public CargoLibrary findCargoLibrary(Tank t) {
		for (ObservableList<SpreadsheetCell> row : cargoTankSpreadsheetView.getGrid().getRows()) {
			int rowIndex = cargoTankSpreadsheetView.getGrid().getRows().indexOf(row);
			if (rowIndex != 0 && rowIndex != cargoTankSpreadsheetView.getGrid().getRows().size() - 1) {
				Tank tank = cargoTankList.get(rowIndex - 1);
				SpreadsheetCell cargoCell = row.get(0);
				HBox cargoHbox = (HBox) cargoCell.getGraphic();
				CargoLibrary cargoRow = cargoHbox.getUserData() != null ? (CargoLibrary) cargoHbox.getUserData() : null;
				if (tank == t) {
					return cargoRow;
				}

			}
		}
		return null;
	}

	public VBox getMainVBox() {
		return mainVBox;
	}

	public void setMainVBox(VBox mainVBox) {
		this.mainVBox = mainVBox;
	}

	public BorderPane getBorderPane() {
		return borderPane;
	}

	public SpreadsheetView getCargoTankSpreadsheetView() {
		return cargoTankSpreadsheetView;
	}

	public Property<Quantity<Torque>> getCargoTanksLongitudinalMomentOfForceProperty() {
		return cargoTanksLongitudinalMomentOfForceProperty;
	}

	public Property<Quantity<Torque>> getCargoTanksVerticalMomentOfForceProperty() {
		return cargoTanksVerticalMomentOfForceProperty;
	}

	public Property<Quantity<Torque>> getCargoTanksTransverseMomentOfForceProperty() {
		return cargoTanksTransverseMomentOfForceProperty;
	}

	public Property<Quantity<FreeSurfaceMoment>> getCargoTanksFreeSurfaceMomentProperty() {
		return cargoTanksFreeSurfaceMomentProperty;
	}

	public Property<Quantity<Mass>> getCargoTanksMassProperty() {
		return cargoTanksMassProperty;
	}

	public Map<Double, Quantity<Force>> getDeadWeightMap() {
		return deadWeightMap;
	}

	public Property<Quantity<Mass>> getCargoCurudeOilTanksMassProperty() {
		return cargoCurudeOilTanksMassProperty;
	}

	public void setCargoCurudeOilTanksMassProperty(Property<Quantity<Mass>> cargoCurudeOilTanksMassProperty) {
		this.cargoCurudeOilTanksMassProperty = cargoCurudeOilTanksMassProperty;
	}

	public Property<Quantity<Mass>> getCargoProductsTanksMassProperty() {
		return cargoProductsTanksMassProperty;
	}

	public void setCargoProductsTanksMassProperty(Property<Quantity<Mass>> cargoProductsTanksMassProperty) {
		this.cargoProductsTanksMassProperty = cargoProductsTanksMassProperty;
	}

	public Property<Quantity<Volume>> getCargoCurudeOilTanksVolumeProperty() {
		return cargoCurudeOilTanksVolumeProperty;
	}

	public void setCargoCurudeOilTanksVolumeProperty(Property<Quantity<Volume>> cargoCurudeOilTanksVolumeProperty) {
		this.cargoCurudeOilTanksVolumeProperty = cargoCurudeOilTanksVolumeProperty;
	}

	public Property<Quantity<Volume>> getCargoProductsTanksVolumeProperty() {
		return cargoProductsTanksVolumeProperty;
	}

	public void setCargoProductsTanksVolumeProperty(Property<Quantity<Volume>> cargoProductsTanksVolumeProperty) {
		this.cargoProductsTanksVolumeProperty = cargoProductsTanksVolumeProperty;
	}
}
