package it.easymarine.ebr.smartload.views;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.inject.Inject;
import javax.measure.Quantity;
import javax.measure.Unit;
import javax.measure.quantity.Length;
import javax.measure.quantity.Mass;
import javax.measure.quantity.Volume;

import org.controlsfx.control.spreadsheet.GridBase;
import org.controlsfx.control.spreadsheet.SpreadsheetCell;
import org.controlsfx.control.spreadsheet.SpreadsheetCellType;
import org.controlsfx.control.spreadsheet.SpreadsheetView;

import it.easymarine.ebr.commons.utils.CustomSpreadsheetView;
import it.easymarine.ebr.smartload.CustomSpreadsheetCellQuantityType;
import it.easymarine.ebr.smartload.preferences.SmartloadPreferencePage;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import tech.units.indriya.quantity.Quantities;
import tech.units.indriya.unit.Units;

public class SummaryController implements Initializable {
	public static final String ACTUALLY_NOT_EDITABLE_STYLE_CLASS = "actually-not-editable";
	@Inject
	private SmartloadViewController smartloadViewController;
	@Inject
	private SmartloadPreferencePage smartloadPreferencePage;
	@FXML
	private VBox mainVBox;
	@FXML
	private BorderPane borderPane;
	@FXML
	private Pane customSpreadsheetHolderPane;
	private SpreadsheetView summarySpreadsheetView;
	private ObjectProperty<String> quantityPrecisionProp;
	private Quantity<Mass> shipWeight;
	private ObjectProperty<Unit<Mass>> prefMassUnitProp;
	private ObjectProperty<Unit<Volume>> prefVolumeUnitProp;
	private ObservableList<String> summaryType = FXCollections.observableArrayList("DEADWEIGHT", "LIGHTSHIP", "DISPLACEMENT", "MD DRAFT", "TRIM");
	private ObservableList<String> tankDataType = FXCollections.observableArrayList("PRODUCTS", "CRUDE OIL", "WATER BALLAST", "FUEL OIL", "DIESEL OIL", "LUB OIL", "FRESH WATER", "MISCELLANEOUS TANKS", "CONSUMABLES", "CONSTANTS");

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		summarySpreadsheetView = new CustomSpreadsheetView();
		quantityPrecisionProp = smartloadPreferencePage.getQuantityPrecision();
		shipWeight = smartloadViewController.getShip().getLightWeight();
		prefMassUnitProp = smartloadPreferencePage.getMassUnit();
		prefVolumeUnitProp = smartloadPreferencePage.getVolumeUnit();
		initSummarySpreadsheet();
		initSummarySpreadsheetListeners();

	}

	private void initSummarySpreadsheet() {
		summarySpreadsheetView.getStyleClass().add("smartload");
		VBox.setVgrow(summarySpreadsheetView, Priority.ALWAYS);
		summarySpreadsheetView.setShowColumnHeader(false);
		summarySpreadsheetView.setShowRowHeader(false);
		customSpreadsheetHolderPane.getChildren().add(summarySpreadsheetView);

		summarySpreadsheetView.getSelectionModel().setSelectionMode(true ? SelectionMode.MULTIPLE : SelectionMode.SINGLE);
		summarySpreadsheetView.getGrid().setDisplaySelection(true);

		EventHandler<Event> editableEventHandler = new EventHandler<Event>() {
			@Override
			public void handle(Event event) {
				if (((SpreadsheetCell) event.getTarget()).isEditable())
					((SpreadsheetCell) event.getTarget()).getStyleClass().remove(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
				else
					((SpreadsheetCell) event.getTarget()).getStyleClass().add(ACTUALLY_NOT_EDITABLE_STYLE_CLASS);
			}
		};
		GridBase grid = new GridBase(0, 0);
		ObservableList<ObservableList<SpreadsheetCell>> rows = FXCollections.observableArrayList();
		int rowIndex = 0;
		rows.add(getHeader(grid, rowIndex++));
		addTankDataRow(rows, rowIndex++);
		addSummaryRow(rows, rowIndex++);
		rows.add(getFooter(grid, rowIndex++));
		grid.setRows(rows);
		summarySpreadsheetView.setGrid(grid);
		grid.setRowHeightCallback(new GridBase.MapBasedRowHeightFactory(generateRowHeight(rows.size())));
		((Pane) summarySpreadsheetView.getParent()).widthProperty().addListener((obs, oldval, newval) -> {
			summarySpreadsheetView.getColumns().forEach(col -> col.setPrefWidth(newval.doubleValue() / 5 - 5));
		});

		summarySpreadsheetView.getContextMenu().getItems().remove(2);

	}

	private void initSummarySpreadsheetListeners() {
		// TODO Auto-generated method stub

	}

	private ObservableList<SpreadsheetCell> getHeader(GridBase grid, int row) {

		final ObservableList<SpreadsheetCell> title = FXCollections.observableArrayList();

		SpreadsheetCell cell = SpreadsheetCellType.STRING.createCell(row, 0, 1, 1, "GRADE");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(0, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 1, 1, 1, "VOL (" + smartloadPreferencePage.getVolumeUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("VOL (", smartloadPreferencePage.getVolumeUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(1, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 2, 1, 1, "DENS @ AIR (" + smartloadPreferencePage.getDensityUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("DENS @ AIR (", smartloadPreferencePage.getDensityUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(2, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 3, 1, 1, "WEIGHT (" + smartloadPreferencePage.getMassUnit().getValue() + ")");
		cell.itemProperty().bind(Bindings.concat("WEIGHT (", smartloadPreferencePage.getMassUnit(), ")"));
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(3, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 4, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(4, cell);
		return title;
	}

	public void addTankDataRow(ObservableList<ObservableList<SpreadsheetCell>> rows, int rowIndex) {
		for (String typeName : tankDataType) {
			final ObservableList<SpreadsheetCell> rowTankData = FXCollections.observableArrayList();
			SpreadsheetCell summaryName = SpreadsheetCellType.STRING.createCell(rowIndex, 0, 1, 1, typeName);
			summaryName.setEditable(false);
			summaryName.getStyleClass().add("spreadsheetCellBody");
			rowTankData.add(0, summaryName);
			SpreadsheetCell volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 1, 1, 1, "");
			if (typeName.equalsIgnoreCase("WATER BALLAST")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getBallastController().getBallastTanksVolumeProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getBallastController().getBallastTanksVolumeProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getBallastController().getBallastTanksDensityProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getBallastController().getBallastTanksDensityProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getBallastController().getBallastTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getBallastController().getBallastTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else if (typeName.equalsIgnoreCase("PRODUCTS")) {
				volDenWeightCell.setEditable(false);
				 volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() ->
				 {return new
				 DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCargoTankController().getCargoProductsTanksVolumeProperty().getValue().getValue().doubleValue())
				 + " ";},
				 smartloadViewController.getCargoTankController().getCargoProductsTanksVolumeProperty(),
				 quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCargoTankController().getCargoProductsTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getCargoTankController().getCargoProductsTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);

			} else if (typeName.equalsIgnoreCase("CRUDE OIL")) {
				volDenWeightCell.setEditable(false);
				 volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() ->
				 {return new
				 DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCargoTankController().getCargoCurudeOilTanksVolumeProperty().getValue().getValue().doubleValue())
				 + " ";},
				 smartloadViewController.getCargoTankController().getCargoCurudeOilTanksVolumeProperty(),
				 quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCargoTankController().getCargoCurudeOilTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getCargoTankController().getCargoCurudeOilTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);

			} else if (typeName.equalsIgnoreCase("FUEL OIL")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineFuelOilTanksVolumeProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineFuelOilTanksVolumeProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineFuelOilTanksDensityProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineFuelOilTanksDensityProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineFuelOilTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineFuelOilTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);

			} else if (typeName.equalsIgnoreCase("DIESEL OIL")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineDieselOilTanksVolumeProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineDieselOilTanksVolumeProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineDieselOilTanksDensityProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineDieselOilTanksDensityProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineDieselOilTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineDieselOilTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else if (typeName.equalsIgnoreCase("LUB OIL")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineLubOilTanksVolumeProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineLubOilTanksVolumeProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineLubOilTanksDensityProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineLubOilTanksDensityProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getEngineSpaceController().getEngineLubOilTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getEngineSpaceController().getEngineLubOilTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else if (typeName.equalsIgnoreCase("FRESH WATER")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksFreshWaterTanksVolumeProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksFreshWaterTanksVolumeProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksFreshWaterTanksDensityProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksFreshWaterTanksDensityProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksFreshWaterTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksFreshWaterTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else if (typeName.equalsIgnoreCase("MISCELLANEOUS TANKS")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksMiscellaneousTanksVolumeProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksMiscellaneousTanksVolumeProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksMiscellaneousTanksDensityProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksMiscellaneousTanksDensityProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksMiscellaneousTanksMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksMiscellaneousTanksMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else if (typeName.equalsIgnoreCase("CONSUMABLES")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksConsumablesMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksConsumablesMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else if (typeName.equalsIgnoreCase("CONSTANTS")) {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getOtherTanksController().getOtherTanksConstantsMassProperty().getValue().getValue().doubleValue()) + " ";
				}, smartloadViewController.getOtherTanksController().getOtherTanksConstantsMassProperty(), quantityPrecisionProp));
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			} else {
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(1, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(2, volDenWeightCell);

				volDenWeightCell = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
				volDenWeightCell.setEditable(false);
				volDenWeightCell.getStyleClass().add("spreadsheetCellBody");
				rowTankData.add(3, volDenWeightCell);
			}
			SpreadsheetCell emptyCell = SpreadsheetCellType.STRING.createCell(rowIndex, 4, 1, 1, "");
			emptyCell.setEditable(false);
			emptyCell.getStyleClass().add("spreadsheetCellBody");

			rowTankData.add(4, emptyCell);
			rows.add(rowTankData);
			rowIndex++;
		}
	}

	public void addSummaryRow(ObservableList<ObservableList<SpreadsheetCell>> rows, int rowIndex) {
		for (String typeName : summaryType) {
			final ObservableList<SpreadsheetCell> rowSumm = FXCollections.observableArrayList();
			SpreadsheetCell summaryName = SpreadsheetCellType.STRING.createCell(rowIndex, 0, 1, 1, typeName);
			summaryName.setEditable(false);
			summaryName.getStyleClass().add("spreadsheetCellTotal");
			rowSumm.add(0, summaryName);

			SpreadsheetCell empty = SpreadsheetCellType.STRING.createCell(rowIndex, 1, 1, 1, "");
			empty.setEditable(false);
			empty.getStyleClass().add("spreadsheetCellTotal");
			rowSumm.add(1, empty);

			empty = SpreadsheetCellType.STRING.createCell(rowIndex, 2, 1, 1, "");
			empty.setEditable(false);
			empty.getStyleClass().add("spreadsheetCellTotal");
			rowSumm.add(2, empty);

			empty = SpreadsheetCellType.STRING.createCell(rowIndex, 3, 1, 1, "");
			empty.setEditable(false);
			empty.getStyleClass().add("spreadsheetCellTotal");
			rowSumm.add(3, empty);

			SpreadsheetCell summaryTotal = SpreadsheetCellType.STRING.createCell(rowIndex, 4, 1, 1, "");
			summaryTotal.setEditable(false);
			summaryTotal.getStyleClass().add("spreadsheetCellTotal");
			if (typeName.equalsIgnoreCase("DISPLACEMENT")) {
				summaryTotal.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCalculationsController().getTotalWeightProperty().getValue().getValue().doubleValue()) + " "
							+ smartloadViewController.getCalculationsController().getTotalWeightProperty().getValue().getUnit().toString();
				}, smartloadViewController.getCalculationsController().getTotalWeightProperty(), quantityPrecisionProp));
			} else if (typeName.equalsIgnoreCase("DEADWEIGHT")) {
				summaryTotal.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue())
							.format(smartloadViewController.getCalculationsController().getTotalWeightProperty().getValue().getValue().doubleValue() - shipWeight.to(smartloadPreferencePage.getMassUnit().get()).getValue().doubleValue())
							+ " " + smartloadViewController.getCalculationsController().getTotalWeightProperty().getValue().getUnit().toString();
				}, smartloadViewController.getCalculationsController().getTotalWeightProperty(), quantityPrecisionProp));
			} else if (typeName.equalsIgnoreCase("LIGHTSHIP")) {
				summaryTotal.itemProperty().bind(Bindings.concat(shipWeight.to(prefMassUnitProp.get()).toString()));
			} else if (typeName.equalsIgnoreCase("TRIM")) {
				summaryTotal.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCalculationsController().getTrimProperty().getValue().getValue().doubleValue()) + " "
							+ smartloadViewController.getCalculationsController().getTrimProperty().getValue().getUnit().toString();
				}, smartloadViewController.getCalculationsController().getTrimProperty(), quantityPrecisionProp));
			} else if (typeName.equalsIgnoreCase("MD DRAFT")) {
				summaryTotal.itemProperty().bind(Bindings.createStringBinding(() -> {
					return new DecimalFormat(quantityPrecisionProp.getValue()).format(smartloadViewController.getCalculationsController().getDraftMDProperty().getValue().getValue().doubleValue()) + " "
							+ smartloadViewController.getCalculationsController().getDraftMDProperty().getValue().getUnit().toString();
				}, smartloadViewController.getCalculationsController().getDraftMDProperty(), quantityPrecisionProp));
			}
			rowSumm.add(4, summaryTotal);
			rows.add(rowSumm);
			rowIndex++;
		}
	}

	private ObservableList<SpreadsheetCell> getFooter(GridBase grid, int row) {
		final ObservableList<SpreadsheetCell> title = FXCollections.observableArrayList();

		SpreadsheetCell cell = SpreadsheetCellType.STRING.createCell(row, 0, 1, 1, "TOTAL CARGO");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		cell.getStyleClass().add("spreadsheetCellFooter");
		title.add(0, cell);
		
		
		Property<Quantity<Volume>> crudeOilTotalVolProp = smartloadViewController.getCargoTankController().getCargoCurudeOilTanksVolumeProperty();
		Property<Quantity<Volume>> productToalVolProp = smartloadViewController.getCargoTankController().getCargoProductsTanksVolumeProperty();
		Property<Quantity<Volume>> ballastTotalProp = smartloadViewController.getBallastController().getBallastTanksVolumeProperty();
		Property<Quantity<Volume>> engineTotalProp = smartloadViewController.getEngineSpaceController().getEngineTanksVolumeProperty();
		Property<Quantity<Volume>> otherTotalVolProp = smartloadViewController.getOtherTanksController().getOtherTanksTotalVolumeProperty();
		
		cell = SpreadsheetCellType.STRING.createCell(row, 1, 1, 1, "");cell.setEditable(false);
		ObjectBinding<Quantity<Volume>> totalVolBinding = Bindings.createObjectBinding(() -> {
			Quantity<Volume> vol = ((Quantity<Volume>)productToalVolProp.getValue())
					.add((Quantity<Volume>)crudeOilTotalVolProp.getValue())
					.add((Quantity<Volume>)ballastTotalProp.getValue())
					.add((Quantity<Volume>)engineTotalProp.getValue())
					.add((Quantity<Volume>)otherTotalVolProp.getValue())
					.to((Unit<Volume>)prefVolumeUnitProp.getValue());
			;
			return vol;
		}, crudeOilTotalVolProp, 
		   productToalVolProp,
		   ballastTotalProp,
		   engineTotalProp,
		   otherTotalVolProp, prefVolumeUnitProp);
		cell.itemProperty().bind(Bindings.createStringBinding(() -> {
			return new DecimalFormat(quantityPrecisionProp.getValue())
					.format(totalVolBinding.get().getValue().doubleValue()) + " "
					+ prefVolumeUnitProp.get().toString();
		}, totalVolBinding, quantityPrecisionProp));
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(1, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 2, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(2, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 3, 1, 1, "");
		cell.setEditable(false);
		cell.itemProperty().bind(Bindings.createStringBinding(() -> {
			return new DecimalFormat(quantityPrecisionProp.getValue())
					.format(smartloadViewController.getCalculationsController().getTotalWeightProperty().getValue().getValue().doubleValue() - shipWeight.to(smartloadPreferencePage.getMassUnit().get()).getValue().doubleValue()) + " "
					+ smartloadViewController.getCalculationsController().getTotalWeightProperty().getValue().getUnit().toString();
		}, smartloadViewController.getCalculationsController().getTotalWeightProperty(), quantityPrecisionProp));
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(3, cell);

		cell = SpreadsheetCellType.STRING.createCell(row, 4, 1, 1, "");
		cell.setEditable(false);
		cell.getStyleClass().add("spreadsheetCellHeader");
		title.add(4, cell);
		return title;
	}

	private Map<Integer, Double> generateRowHeight(Integer rowsize) {
		Map<Integer, Double> rowHeight = new HashMap<>();
		for (int i = 0; i <= rowsize; i++) {
			rowHeight.put(i, 35.0);
		}

		return rowHeight;
	}

	public VBox getMainVBox() {
		return mainVBox;
	}

	public void setMainVBox(VBox mainVBox) {
		this.mainVBox = mainVBox;
	}

	public Pane getCustomSpreadsheetHolderPane() {
		return customSpreadsheetHolderPane;
	}

	public void setCustomSpreadsheetHolderPane(Pane customSpreadsheetHolderPane) {
		this.customSpreadsheetHolderPane = customSpreadsheetHolderPane;
	}

	public BorderPane getBorderPane() {
		return borderPane;
	}

	public void setBorderPane(BorderPane borderPane) {
		this.borderPane = borderPane;
	}
	public SpreadsheetView getSummarySpreadsheetView() {
		return summarySpreadsheetView;
	}

	public void setSummarySpreadsheetView(SpreadsheetView summarySpreadsheetView) {
		this.summarySpreadsheetView = summarySpreadsheetView;
	}

	

}
