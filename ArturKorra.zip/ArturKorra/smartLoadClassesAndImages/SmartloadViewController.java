package it.easymarine.ebr.smartload.views;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.inject.Inject;
import javax.measure.Quantity;
import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.Mass;
import javax.measure.quantity.Temperature;

import org.controlsfx.control.MaskerPane;
import org.controlsfx.control.spreadsheet.SpreadsheetCell;
import org.eclipse.e4.tools.resources.WorkbenchResourceProvider;
import org.eclipse.e4.tools.services.IResourceProviderService;
import org.eclipse.fx.core.log.Logger;
import org.eclipse.fx.core.log.LoggerCreator;
import org.eclipse.fx.ui.services.resources.ImageProvider;
import org.eclipse.fx.ui.services.theme.ThemeManager;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.svg.SVGGlyph;
import com.jfoenix.svg.SVGGlyphLoader;
import com.sun.javafx.collections.ObservableListWrapper;

import afester.javafx.svg.SvgLoader;
import it.easymarine.ebr.commons.utils.JavaFXUtils;
import it.easymarine.ebr.smartload.core.services.ShipTanksService;
import it.easymarine.ebr.smartload.core.services.TempDensityService;
import it.easymarine.ebr.smartload.domain.CargoLibrary;
import it.easymarine.ebr.smartload.domain.CargoType;
import it.easymarine.ebr.smartload.domain.Ship;
import it.easymarine.ebr.smartload.domain.Tank;
import it.easymarine.ebr.smartload.domain.TankLoading;
import it.easymarine.ebr.smartload.domain.TankSavedData;
import it.easymarine.ebr.smartload.domain.TankType;
import it.easymarine.ebr.smartload.domain.TempDensTableType;
import it.easymarine.ebr.smartload.domain.Voyage;
import it.easymarine.ebr.smartload.domain.VoyageType;
import it.easymarine.ebr.smartload.preferences.SmartloadPreferencePage;
import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jfxtras.scene.control.ImageViewButton;
import si.uom.quantity.Density;
import tech.units.indriya.unit.Units;

public class SmartloadViewController implements Initializable {

	private static final Logger logger = LoggerCreator.createLogger(SmartloadViewController.class);
	private static final double defaultFontPointSize = 13;
	@Inject
	private static ThemeManager themeManager;
	@Inject
	private ShipTanksService shipTanksService;
	@Inject
	private TempDensityService tempDensityService;
	@Inject
	private IResourceProviderService resourcesService;
	@Inject
	private SmartloadPreferencePage smartloadPreferencePage;
	@Inject
	private ImageProvider imageProvider;
	private ObjectProperty<Font> fontTracking = new SimpleObjectProperty<Font>(Font.getDefault());
	@FXML
	private TextField smartLoadDisplacementTextField;
	private BorderPane shipViewBorderPane = new BorderPane();
	private static JFXButton closeButton;
	private static Alert alert;
	private Node tankSVGSelected = new SVGPath();
	private double shipBoderPaneCenterWidth = 0.0;
	private double shipBoderPaneRightWidth = 0.0;
	@Inject
	private TankPositionXY createShipTankPosition;
	private Group svgGroupShipTop;
	private Group svgGroupShipSide;
	private Polygon seaWaterView;
	@FXML
	private StackPane mainStackPane;
	@FXML
	private VBox tableCargoTankVBox;
	@FXML
	private TabPane mainTabPane;
	@FXML
	private TabPane smartLoadTabPane;
	private CargoTankController cargoTankController;
	private BallastController ballastController;
	private EngineSpaceController engineSpaceController;
	private OtherTanksController otherTanksController;
	private SummaryController summaryController;
	private StrengthStabilityController strengthStabilityController;
	private StowagePlanController stowagePlanController;
	private CargoLibraryController cargoLibraryController;
	private VBox calculationsVBox;
	private CalculationsController calculationsController;
	private ObservableList<Node> nodeShipTopView;
	private ObservableList<Node> nodeShipSideView;
	private List<Tank> allTanks = new ArrayList<Tank>();
	private List<Tank> ballastTanks = new ArrayList<Tank>();
	private List<Tank> cargoAndSlopTanks = new ArrayList<Tank>();
	private List<Tank> engineTanks = new ArrayList<Tank>();
	private List<Tank> otherTanks = new ArrayList<Tank>();
	private List<TempDensTableType> tempDensTableTypes = new ArrayList<TempDensTableType>();
	private TankSavedData tankSavedData = null;
	private Ship ship;
	private List<CargoLibrary> cargoLibrary;
	@FXML
	private ImageViewButton logbook2Help2ImageViewButton;
	private MaskerPane maskerPane = new MaskerPane();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			SVGGlyph timesGlyph = SVGGlyphLoader.getIcoMoonGlyph("icomoon.svg.times-circle");
			closeButton = new JFXButton();
			closeButton.getStyleClass().add("closeDialogButton");
			closeButton.setMinWidth(40);
			closeButton.setPrefWidth(40);
			closeButton.setMaxWidth(40);
			closeButton.setMinHeight(32);
			closeButton.setPrefHeight(32);
			closeButton.setMaxHeight(32);
			closeButton.setGraphic(timesGlyph);
			closeButton.ripplerFillProperty().setValue(Color.LIGHTSALMON);
			closeButton.setOnAction(event -> {
				((Stage) ((Button) event.getSource()).getScene().getWindow()).close();
			});
			Tooltip.install(closeButton, new Tooltip("Exit"));
			try {
				Image infoIconImage = imageProvider.getImage(((WorkbenchResourceProvider) resourcesService).getImageURI(WorkbenchResourceProvider.IMG_SMARTLOAD_LOGO));
				logbook2Help2ImageViewButton.setImage(infoIconImage);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ship = shipTanksService.getShip("EURODESTINY");

			cargoAndSlopTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.CARGO));
			cargoAndSlopTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.SLOP));

			ballastTanks = shipTanksService.getTanksByShipAndType(ship, TankType.BALLAST);

			engineTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.FUEL));
			engineTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.DIESEL));
			engineTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.LUB));

			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.FRESHWATER));
			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.MISCELLANEOUS));
			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.BILGE));
			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.SLUDGE));
			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.MGO));
			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.CONSUMABLES));
			otherTanks.addAll(shipTanksService.getTanksByShipAndType(ship, TankType.CONSTANTS));

			allTanks.addAll(cargoAndSlopTanks);
			allTanks.addAll(ballastTanks);
			allTanks.addAll(engineTanks);
			allTanks.addAll(otherTanks);
			tempDensTableTypes = tempDensityService.getTempDensTableTypes(ship);
			maskerPane.setVisible(false);
			mainStackPane.getChildren().add(maskerPane);
			cargoLibrary = shipTanksService.getCargoLibrary();
			cargoLibrary.sort(Comparator.comparing(CargoLibrary::getIndex));
			mainTabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
				@Override
				public void changed(ObservableValue<? extends Tab> ov, Tab oldTab, Tab newTab) {
					if (oldTab != null && newTab.getText().equalsIgnoreCase("OPEN SAVED")) {
						mainTabPane.getSelectionModel().clearAndSelect(mainTabPane.getTabs().indexOf(oldTab));
						boolean toContinue = showConfirmation("Tank Loading", "Do you want to save current data first?");
						if (toContinue) {
//							maskerPane.setVisible(true);
//							Task<Void> applyTask = new Task<Void>() {
//								@Override
//								protected Void call() throws Exception {
									boolean cont = saveTankLoadingData();
//									Platform.runLater(new Runnable() {
//										@Override
//										public void run() {
//											try {
									        if (cont) {
									        	loadOpenSaved();
									         }
												
//											} catch (Exception e) {
//												logger.error(e.toString());
//											}
//										}
//									});
//									return null;
//								}
//							};

							//applyTask.setOnSucceeded(e -> maskerPane.setVisible(false));
							//applyTask.setOnFailed(e -> maskerPane.setVisible(false));// handle error here...

							//new Thread(applyTask, "Apply thread").start();
						} else {
//							maskerPane.setVisible(true);
//							Task<Void> applyTask = new Task<Void>() {
//								@Override
//								protected Void call() throws Exception {
//									Platform.runLater(new Runnable() {
//										@Override
//										public void run() {
//											try {
												loadOpenSaved();
//											} catch (Exception e) {
//												logger.error(e.toString());
//											}
//										}
//									});
//									return null;
//								}
//							};
//							applyTask.setOnSucceeded(e -> maskerPane.setVisible(false));
//							applyTask.setOnFailed(e -> maskerPane.setVisible(false));// handle error here...
//
//							new Thread(applyTask, "Apply thread").start();
						}
					}
				}
			});

			smartLoadTabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
				@Override
				public void changed(ObservableValue<? extends Tab> ov, Tab oldTab, Tab newTab) {
					if (oldTab != null && newTab.getText().equalsIgnoreCase("CARGO TANK")) {
						cargoTankController.getBorderPane().setRight(calculationsVBox);
						if (cargoTankController != null && !cargoTankController.getMainVBox().getChildren().contains(shipViewBorderPane))
							try {
								List<TankType> tankType = new ArrayList<TankType>();
								tankType.add(TankType.SLOP);
								tankType.add(TankType.CARGO);
								cargoTankController.getMainVBox().getChildren().add(shipWithSpecificTanks(tankType));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					} else if (oldTab != null && newTab.getText().equalsIgnoreCase("BALLAST")) {
						ballastController.getBorderPane().setRight(calculationsVBox);
						if (ballastController != null && !ballastController.getMainVBox().getChildren().contains(shipViewBorderPane))
							try {
								List<TankType> tankType = new ArrayList<TankType>();
								tankType.add(TankType.BALLAST);
								ballastController.getMainVBox().getChildren().add(shipWithSpecificTanks(tankType));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					} else if (oldTab != null && newTab.getText().equalsIgnoreCase("ENGINE SPACE")) {
						engineSpaceController.getBorderPane().setRight(calculationsVBox);
						if (engineSpaceController != null && !engineSpaceController.getMainVBox().getChildren().contains(shipViewBorderPane))
							try {
								List<TankType> tankType = new ArrayList<TankType>();
								tankType.add(TankType.FUEL);
								tankType.add(TankType.DIESEL);
								tankType.add(TankType.LUB);
								engineSpaceController.getMainVBox().getChildren().add(shipWithSpecificTanks(tankType));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					} else if (oldTab != null && newTab.getText().equalsIgnoreCase("OTHER TANKS")) {
						otherTanksController.getBorderPane().setRight(calculationsVBox);
						if (otherTanksController != null && !otherTanksController.getMainVBox().getChildren().contains(shipViewBorderPane))
							try {
								List<TankType> tankType = new ArrayList<TankType>();
								tankType.add(TankType.MGO);
								tankType.add(TankType.BILGE);
								tankType.add(TankType.SLUDGE);
								tankType.add(TankType.FRESHWATER);
								tankType.add(TankType.MISCELLANEOUS);
								otherTanksController.getMainVBox().getChildren().add(shipWithSpecificTanks(tankType));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					} else if (oldTab != null && newTab.getText().equalsIgnoreCase("SUMMARY TABLE")) {
						summaryController.getBorderPane().setRight(calculationsVBox);
						if (summaryController != null && !summaryController.getMainVBox().getChildren().contains(shipViewBorderPane))
							try {
								List<TankType> tankType = new ArrayList<TankType>();
								tankType.add(TankType.SLOP);
								tankType.add(TankType.CARGO);
								// tankType.add(TankType.BALLAST);
								tankType.add(TankType.FUEL);
								tankType.add(TankType.LUB);
								tankType.add(TankType.DIESEL);
								tankType.add(TankType.MGO);
								tankType.add(TankType.BILGE);
								tankType.add(TankType.SLUDGE);
								tankType.add(TankType.FRESHWATER);
								tankType.add(TankType.MISCELLANEOUS);
								summaryController.getMainVBox().getChildren().add(shipWithSpecificTanks(tankType));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					} else if (oldTab != null && newTab.getText().equalsIgnoreCase("CARGO LIBRARY")) {
						loadCargoLibrary(oldTab, newTab);

					} else {
						List<TankType> tankType = new ArrayList<TankType>();
						tankType.add(TankType.SLOP);
						tankType.add(TankType.CARGO);
						if (cargoTankController != null && !cargoTankController.getMainVBox().getChildren().contains(shipViewBorderPane))
							try {
								cargoTankController.getMainVBox().getChildren().add(shipWithSpecificTanks(tankType));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					}
				}
			});
			createShipSVG();
			Platform.runLater(new Runnable() {
				@Override
				public void run() {
					try {
						Stage stage = (Stage) shipViewBorderPane.getScene().getWindow();
						stageSizeChageListener(stage);
					} catch (Exception e) {
						logger.error(e.toString());
					}
				}
			});
			firstLoadResize();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void createShipSVG() throws IOException {
		HBox hBox = initShip();
		shipViewBorderPane.setCenter(hBox);
		shipViewBorderPane.setRight(createShipTankPosition.getSubScene());
	}

	private HBox initShip() {
		HBox rootship = new HBox();
		BorderPane shipTopView = new BorderPane();
		InputStream svgFileShipTop = getClass().getResourceAsStream("/images/Layout_2_Eurodestiny.svg");
		SvgLoader loaderShipTop = new SvgLoader();
		svgGroupShipTop = loaderShipTop.loadSvg(svgFileShipTop);
		resize(svgGroupShipTop, shipBoderPaneCenterWidth / 2, (shipBoderPaneCenterWidth) * 0.10);
		Group groupShipTop = new Group();
		Optional<Node> nodeTankLevelTop = ((Collection<Node>) svgGroupShipTop.getChildren()).stream().filter(a -> a.getId().equals("tankLevel")).findFirst();
		nodeShipTopView = ((Group) nodeTankLevelTop.get()).getChildren();
		groupShipTop.getChildren().add(svgGroupShipTop);
		shipTopView.setCenter(groupShipTop);

		BorderPane shipSideView = new BorderPane();
		InputStream svgFileShipSide = getClass().getResourceAsStream("/images/Layout_1_Eurodestiny.svg");
		SvgLoader loaderShipSide = new SvgLoader();
		svgGroupShipSide = loaderShipSide.loadSvg(svgFileShipSide);
		resize(svgGroupShipSide, shipBoderPaneCenterWidth / 2, (shipBoderPaneCenterWidth) * 0.10);
		Group groupShipSide = new Group();
		Optional<Node> nodeTankLevelSide = ((Collection<Node>) svgGroupShipSide.getChildren()).stream().filter(a -> a.getId().equals("tankLevel")).findFirst();
		Optional<Node> nodeTankLevelSide2 = ((Collection<Node>) svgGroupShipSide.getChildren()).stream().filter(a -> a.getId().equals("seaWater")).findFirst();
		seaWaterView = (Polygon) nodeTankLevelSide2.get();
		nodeShipSideView = ((Group) nodeTankLevelSide.get()).getChildren();
		groupShipSide.getChildren().add(svgGroupShipSide);
		shipSideView.setCenter(groupShipSide);
		rootship.getChildren().addAll(shipTopView, shipSideView);
		return rootship;
	}

	private BorderPane shipWithSpecificTanks(List<TankType> tankType) throws IOException {
		// ship top view
		for (Node path : nodeShipTopView) {
			path.setDisable(true);
			for (Tank tank : allTanks) {
				if (path.getId().equalsIgnoreCase(tank.getName()) && (tankType.contains(tank.getTankType()))) {
					path.setVisible(true);
					path.setDisable(false);
					Tooltip toolTipTank = new Tooltip();
					StringBuilder tooltipText = new StringBuilder();
					tooltipText.append("Tank Name:" + tank.getName());
					tooltipText.append(System.lineSeparator());
					tooltipText.append("Tank Type:" + tank.getTankType());
					tooltipText.append(System.lineSeparator());
					tooltipText.append("Max Volume:" + tank.getVolume());
					toolTipTank.setText(tooltipText.toString());
					if (path instanceof SVGPath) {
						((SVGPath) path).setStroke(Paint.valueOf("black"));
						((SVGPath) path).setStrokeWidth(10.0);
						((SVGPath) path).setUserData(tank);
						if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
							getGradientFillTop(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						} else {
							getGradientFillTop(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

						}
						Tooltip.install(path, toolTipTank);

					} else if (path instanceof Polygon) {
						((Polygon) path).setStroke(Paint.valueOf("black"));
						((Polygon) path).setStrokeWidth(10.0);
						((Polygon) path).setUserData(tank);
						if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
							getGradientFillTop(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						} else {
							getGradientFillTop(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

						}
						Tooltip.install(path, toolTipTank);

					} else if (path instanceof Rectangle) {
						((Rectangle) path).setStroke(Paint.valueOf("black"));
						((Rectangle) path).setStrokeWidth(10.0);
						((Rectangle) path).setUserData(tank);
						if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
							getGradientFillTop(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						} else {
							getGradientFillTop(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

						}
						Tooltip.install(path, toolTipTank);

					}

					path.setOnMouseEntered(aevent -> {
						if (path instanceof SVGPath) {
							((SVGPath) path).setStroke(Paint.valueOf("red"));
							((SVGPath) path).setStrokeWidth(40);
						} else if (path instanceof Polygon) {
							((Polygon) path).setStroke(Paint.valueOf("red"));
							((Polygon) path).setStrokeWidth(40);
						} else if (path instanceof Rectangle) {
							((Rectangle) path).setStroke(Paint.valueOf("red"));
							((Rectangle) path).setStrokeWidth(40);
						}
					});
					path.setOnMouseExited(aevent -> {
						if (path instanceof SVGPath) {
							((SVGPath) path).setStroke(Paint.valueOf("black"));
							((SVGPath) path).setStrokeWidth(10);
						} else if (path instanceof Polygon) {
							((Polygon) path).setStroke(Paint.valueOf("black"));
							((Polygon) path).setStrokeWidth(10);
						} else if (path instanceof Rectangle) {
							((Rectangle) path).setStroke(Paint.valueOf("black"));
							((Rectangle) path).setStrokeWidth(10);
						}
					});
					path.setOnMousePressed(aevent -> {
						Tank t = (Tank) path.getUserData();
						if (aevent.getButton() == MouseButton.PRIMARY) {
							if (path instanceof SVGPath) {
								((SVGPath) path).setStrokeWidth(40);
							} else if (path instanceof Polygon) {
								((Polygon) path).setStrokeWidth(40);
							} else if (path instanceof Rectangle) {
								((Rectangle) path).setStrokeWidth(40);
							}

							// showInformation(t.getName(), t.getVolume().toString());
							selectTableRowFromSVG(path);
							tankSVGSelected = path;
							createShipTankPosition.createTankView(tankSVGSelected);
						} else if (aevent.getButton() == MouseButton.SECONDARY) {
							selectTankDetails(t);
						}
					});
				} else if (path.getId().equalsIgnoreCase(tank.getName())) {
					path.setVisible(false);
					path.setDisable(true);
				}
			}
		}
		// ship side view
		for (Node path : nodeShipSideView) {
			path.setDisable(true);
			for (Tank tank : allTanks) {
				if (path.getId().equalsIgnoreCase(tank.getName()) && (tankType.contains(tank.getTankType()))) {
					path.setVisible(true);
					path.setDisable(false);
					Tooltip toolTipTank = new Tooltip();
					StringBuilder tooltipText = new StringBuilder();
					tooltipText.append("Tank Name:" + tank.getName());
					tooltipText.append(System.lineSeparator());
					tooltipText.append("Tank Type:" + tank.getTankType());
					tooltipText.append(System.lineSeparator());
					tooltipText.append("Max Volume:" + tank.getVolume());
					toolTipTank.setText(tooltipText.toString());
					if (path instanceof SVGPath) {
						((SVGPath) path).setStroke(Paint.valueOf("black"));
						((SVGPath) path).setStrokeWidth(10.0);
						((SVGPath) path).setUserData(tank);
						if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
							getGradientFillSide(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						} else {
							getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

						}
						Tooltip.install(path, toolTipTank);

					} else if (path instanceof Polygon) {
						((Polygon) path).setStroke(Paint.valueOf("black"));
						((Polygon) path).setStrokeWidth(10.0);
						((Polygon) path).setUserData(tank);
						if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
							getGradientFillSide(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						} else {
							getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

						}
						Tooltip.install(path, toolTipTank);

					} else if (path instanceof Rectangle) {
						((Rectangle) path).setStroke(Paint.valueOf("black"));
						((Rectangle) path).setStrokeWidth(10.0);
						((Rectangle) path).setUserData(tank);
						if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
							getGradientFillSide(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						} else {
							getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

						}
						Tooltip.install(path, toolTipTank);

					}

					path.setOnMouseEntered(aevent -> {
						if (path instanceof SVGPath) {
							((SVGPath) path).setStroke(Paint.valueOf("red"));
							((SVGPath) path).setStrokeWidth(50);
						} else if (path instanceof Polygon) {
							((Polygon) path).setStroke(Paint.valueOf("red"));
							((Polygon) path).setStrokeWidth(50);
						} else if (path instanceof Rectangle) {
							((Rectangle) path).setStroke(Paint.valueOf("red"));
							((Rectangle) path).setStrokeWidth(50);
						}
					});
					path.setOnMouseExited(aevent -> {
						if (path instanceof SVGPath) {
							((SVGPath) path).setStroke(Paint.valueOf("black"));
							((SVGPath) path).setStrokeWidth(10);
						} else if (path instanceof Polygon) {
							((Polygon) path).setStroke(Paint.valueOf("black"));
							((Polygon) path).setStrokeWidth(10);
						} else if (path instanceof Rectangle) {
							((Rectangle) path).setStroke(Paint.valueOf("black"));
							((Rectangle) path).setStrokeWidth(10);
						}
					});
					path.setOnMousePressed(aevent -> {
						Tank t = (Tank) path.getUserData();
						if (aevent.getButton() == MouseButton.PRIMARY) {
							if (path instanceof SVGPath) {
								((SVGPath) path).setStrokeWidth(50);
							} else if (path instanceof Polygon) {
								((Polygon) path).setStrokeWidth(50);
							} else if (path instanceof Rectangle) {
								((Rectangle) path).setStrokeWidth(50);
							}
							selectTableRowFromSVG(path);
							tankSVGSelected = path;
							createShipTankPosition.createTankView(tankSVGSelected);
						} else if (aevent.getButton() == MouseButton.SECONDARY) {
							selectTankDetails(t);
						}
					});
				} else if (path.getId().contains(tank.getName()) && tankType.contains(tank.getTankType())) {
					path.setVisible(true);
					path.setDisable(false);
					if (path instanceof SVGPath) {
						((SVGPath) path).setFill(Paint.valueOf("white"));
					} else if (path instanceof Polygon) {
						((Polygon) path).setFill(Paint.valueOf("white"));
					} else if (path instanceof Rectangle) {
						((Rectangle) path).setFill(Paint.valueOf("white"));
					}

					path.setOnMouseEntered(aevent -> {
						if (path instanceof SVGPath) {
							((SVGPath) path).setStroke(Paint.valueOf("red"));
							((SVGPath) path).setStrokeWidth(50);
						} else if (path instanceof Polygon) {
							((Polygon) path).setStroke(Paint.valueOf("red"));
							((Polygon) path).setStrokeWidth(50);
						} else if (path instanceof Rectangle) {
							((Rectangle) path).setStroke(Paint.valueOf("red"));
							((Rectangle) path).setStrokeWidth(50);
						}
					});
					path.setOnMouseExited(aevent -> {
						if (path instanceof SVGPath) {
							((SVGPath) path).setStroke(Paint.valueOf("black"));
							((SVGPath) path).setStrokeWidth(10);
						} else if (path instanceof Polygon) {
							((Polygon) path).setStroke(Paint.valueOf("black"));
							((Polygon) path).setStrokeWidth(10);
						} else if (path instanceof Rectangle) {
							((Rectangle) path).setStroke(Paint.valueOf("black"));
							((Rectangle) path).setStrokeWidth(10);
						}
					});
					path.setOnMousePressed(aevent -> {
						if (path.getId().contains("and")) {
							try {
								selectTankBallastType(path);
							} catch (IOException e) {
								logger.error(e.toString());
							}

						} else {
							Tooltip toolTipTank = new Tooltip();
							StringBuilder tooltipText = new StringBuilder();
							tooltipText.append("Tank Name:" + tank.getName());
							tooltipText.append(System.lineSeparator());
							tooltipText.append("Tank Type:" + tank.getTankType());
//							tooltipText.append(System.lineSeparator());
//							tooltipText.append("Current Weight:" + tank.getVolume());
//							tooltipText.append(System.lineSeparator());
//							tooltipText.append("Available Weight:" + tank.getVolume());
							tooltipText.append(System.lineSeparator());
							tooltipText.append("Max Volume:" + tank.getVolume());
							toolTipTank.setText(tooltipText.toString());
							if (path instanceof SVGPath) {
								((SVGPath) path).setStrokeWidth(10.0);
								((SVGPath) path).setUserData(tank);
								if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
									getGradientFillSide(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
								} else {
									getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

								}
								Tooltip.install(path, toolTipTank);

							} else if (path instanceof Polygon) {
								((Polygon) path).setStrokeWidth(10.0);
								((Polygon) path).setUserData(tank);
								if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
									getGradientFillSide(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
								} else {
									getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

								}
								Tooltip.install(path, toolTipTank);

							} else if (path instanceof Rectangle) {
								((Rectangle) path).setStrokeWidth(10.0);
								((Rectangle) path).setUserData(tank);
								if (((Tank) path.getUserData()).getTankType().equals(TankType.CARGO) || ((Tank) path.getUserData()).getTankType().equals(TankType.SLOP)) {
									getGradientFillSide(cargoTankController.findCargoLibrary((Tank) path.getUserData()), (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
								} else {
									getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));

								}
								Tooltip.install(path, toolTipTank);

							}
							if (aevent.getButton() == MouseButton.PRIMARY) {
								if (path instanceof SVGPath) {
									((SVGPath) path).setStrokeWidth(50);
								} else if (path instanceof Polygon) {
									((Polygon) path).setStrokeWidth(50);
								} else if (path instanceof Rectangle) {
									((Rectangle) path).setStrokeWidth(50);
								}

								selectTableRowFromSVG(path);
								tankSVGSelected = path;
								createShipTankPosition.createTankView(tankSVGSelected);
							} else if (aevent.getButton() == MouseButton.SECONDARY) {
								selectTankDetails(tank);
							}
						}
					});

				} else if (path.getId().contains(tank.getName())) {
					path.setVisible(false);
					path.setDisable(true);

				}
			}
		}
		return shipViewBorderPane;
	}

	private void selectTableRowFromSVG(Node path) {
		Tank t = (Tank) path.getUserData();
		if (t.getTankType().equals(TankType.CARGO) || t.getTankType().equals(TankType.SLOP)) {
			int index = cargoAndSlopTanks.indexOf(t) + 1;
			cargoTankController.getCargoTankSpreadsheetView().getSelectionModel().clearSelection();
			cargoTankController.getCargoTankSpreadsheetView().getSelectionModel().selectRange(index, cargoTankController.getCargoTankSpreadsheetView().getColumns().get(0), index,
					cargoTankController.getCargoTankSpreadsheetView().getColumns().get(cargoTankController.getCargoTankSpreadsheetView().getColumns().size() - 1));
			cargoTankController.getCargoTankSpreadsheetView().scrollToRow(index);
		} else if (t.getTankType().equals(TankType.BALLAST)) {
			int index = ballastTanks.indexOf(t) + 1;
			ballastController.getBallastTankSpreadsheetView().getSelectionModel().clearSelection();
			ballastController.getBallastTankSpreadsheetView().getSelectionModel().selectRange(index, ballastController.getBallastTankSpreadsheetView().getColumns().get(0), index,
					ballastController.getBallastTankSpreadsheetView().getColumns().get(ballastController.getBallastTankSpreadsheetView().getColumns().size() - 1));
			ballastController.getBallastTankSpreadsheetView().scrollToRow(index);
		} else if (t.getTankType().equals(TankType.FUEL) || t.getTankType().equals(TankType.DIESEL) || t.getTankType().equals(TankType.LUB)) {
			int index = engineTanks.indexOf(t) + 1;
			engineSpaceController.getEngineTankSpreadsheetView().getSelectionModel().clearSelection();
			engineSpaceController.getEngineTankSpreadsheetView().getSelectionModel().selectRange(index, engineSpaceController.getEngineTankSpreadsheetView().getColumns().get(0), index,
					engineSpaceController.getEngineTankSpreadsheetView().getColumns().get(engineSpaceController.getEngineTankSpreadsheetView().getColumns().size() - 1));
			engineSpaceController.getEngineTankSpreadsheetView().scrollToRow(index);
		} else if (t.getTankType().equals(TankType.BILGE) || t.getTankType().equals(TankType.MGO) || t.getTankType().equals(TankType.SLUDGE) || t.getTankType().equals(TankType.FRESHWATER) || t.getTankType().equals(TankType.MISCELLANEOUS)) {
			int index = otherTanks.indexOf(t) + 1;
			otherTanksController.getOtherTankSpreadsheetView().getSelectionModel().clearSelection();
			otherTanksController.getOtherTankSpreadsheetView().getSelectionModel().selectRange(index, otherTanksController.getOtherTankSpreadsheetView().getColumns().get(0), index,
					otherTanksController.getOtherTankSpreadsheetView().getColumns().get(otherTanksController.getOtherTankSpreadsheetView().getColumns().size() - 1));
			otherTanksController.getOtherTankSpreadsheetView().scrollToRow(index);
		}

	}

	private String getDensityFromSpreadsheetView(Tank tank) {
		Tank t = tank;
		if (t.getTankType().equals(TankType.CARGO) || t.getTankType().equals(TankType.SLOP)) {
			int index = cargoAndSlopTanks.indexOf(t) + 1;
			ObservableListWrapper row = (ObservableListWrapper) cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows().get(index);
			SpreadsheetCell densityCell = (SpreadsheetCell) row.get(6);
			return densityCell.getItem().toString();
		} else if (t.getTankType().equals(TankType.BALLAST)) {
			int index = ballastTanks.indexOf(t) + 1;
			ObservableListWrapper row = (ObservableListWrapper) ballastController.getBallastTankSpreadsheetView().getGrid().getRows().get(index);
			SpreadsheetCell densityCell = (SpreadsheetCell) row.get(2);
			return densityCell.getItem().toString();
		} else if (t.getTankType().equals(TankType.FUEL) || t.getTankType().equals(TankType.DIESEL) || t.getTankType().equals(TankType.LUB)) {
			int index = engineTanks.indexOf(t) + 1;
			ObservableListWrapper row = (ObservableListWrapper) engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows().get(index);
			SpreadsheetCell densityCell = (SpreadsheetCell) row.get(3);
			return densityCell.getItem().toString();
		} else if (t.getTankType().equals(TankType.BILGE) || t.getTankType().equals(TankType.MGO) || t.getTankType().equals(TankType.SLUDGE) || t.getTankType().equals(TankType.FRESHWATER) || t.getTankType().equals(TankType.MISCELLANEOUS)) {
			int index = otherTanks.indexOf(t) + 1;
			ObservableListWrapper row = (ObservableListWrapper) otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows().get(index);
			SpreadsheetCell densityCell = (SpreadsheetCell) row.get(2);
			return densityCell.getItem().toString();
		}
		return "0.0";
	}

	private String getTableCellItemVolumePerc(Tank t) {
		if (t.getTankType().equals(TankType.CARGO) || t.getTankType().equals(TankType.SLOP)) {
			ObservableList<ObservableList<SpreadsheetCell>> allRow = cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows();
			for (ObservableList<SpreadsheetCell> row : allRow) {
				if (allRow.indexOf(row) > 0 && allRow.indexOf(row) < cargoAndSlopTanks.size() + 1) {
					if (row.get(1).getItem().equals(t.getName())) {
						if (row.get(4).getItem().toString().contains("%")) {
							return row.get(4).getItem().toString();
						} else {
							try {
								 Quantity<Dimensionless> perc=((Quantity<Dimensionless>) row.get(4).getItem()).to(Units.PERCENT);
								 return perc.toString();
							} catch (Exception e) {
								logger.error(e + "");
							}

						}

					}
				}

			}
		} else if (t.getTankType().equals(TankType.BALLAST)) {
			ObservableList<ObservableList<SpreadsheetCell>> allRow = ballastController.getBallastTankSpreadsheetView().getGrid().getRows();
			for (ObservableList<SpreadsheetCell> row : allRow) {
				if (allRow.indexOf(row) > 0 && allRow.indexOf(row) < ballastTanks.size() + 1) {
					if (row.get(0).getItem().equals(t.getName())) {
						if (row.get(4).getItem().toString().contains("%")) {
							return row.get(4).getItem().toString();
						} else {
							try {
								 Quantity<Dimensionless> perc=((Quantity<Dimensionless>) row.get(4).getItem()).to(Units.PERCENT);
								 return perc.toString();
							} catch (Exception e) {
								logger.error(e + "");
							}

						}

					}
				}

			}

		} else if (t.getTankType().equals(TankType.FUEL) || t.getTankType().equals(TankType.DIESEL) || t.getTankType().equals(TankType.LUB)) {
			ObservableList<ObservableList<SpreadsheetCell>> allRow = engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows();
			for (ObservableList<SpreadsheetCell> row : allRow) {
				if (allRow.indexOf(row) > 0 && allRow.indexOf(row) < engineTanks.size() + 1) {
					if (row.get(1).getItem().equals(t.getName())) {
						if (row.get(5).getItem().toString().contains("%")) {
							return row.get(5).getItem().toString();
						} else {
							try {
								 Quantity<Dimensionless> perc=((Quantity<Dimensionless>) row.get(5).getItem()).to(Units.PERCENT);
								 return perc.toString();
							} catch (Exception e) {
								logger.error(e + "");
							}

						}

					}
				}

			}

		} else if (t.getTankType().equals(TankType.BILGE) || t.getTankType().equals(TankType.MGO) || t.getTankType().equals(TankType.SLUDGE) || t.getTankType().equals(TankType.FRESHWATER) || t.getTankType().equals(TankType.MISCELLANEOUS)) {
			ObservableList<ObservableList<SpreadsheetCell>> allRow = otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows();
			for (ObservableList<SpreadsheetCell> row : allRow) {
				if (allRow.indexOf(row) > 0 && allRow.indexOf(row) < otherTanks.size() + 1) {
					if (row.get(0).getItem().equals(t.getName())) {
						if (row.get(4).getItem().toString().contains("%")) {
							return row.get(4).getItem().toString();
						} else {
							try {
								 Quantity<Dimensionless> perc=((Quantity<Dimensionless>) row.get(4).getItem()).to(Units.PERCENT);
								 return perc.toString();
							} catch (Exception e) {
								logger.error(e + "");
							}

						}

					}
				}

			}
		}

		return null;
	}

	public void selectTankSVGFromTableRow(String tankName) {
		for (Node path : nodeShipTopView) {
			if (path.getId().equalsIgnoreCase(tankName)) {
				if (path instanceof SVGPath) {
					((SVGPath) path).setStroke(Paint.valueOf("red"));
					((SVGPath) path).setStrokeWidth(40);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
				} else if (path instanceof Polygon) {
					((Polygon) path).setStroke(Paint.valueOf("red"));
					((Polygon) path).setStrokeWidth(40);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
				} else if (path instanceof Rectangle) {
					((Rectangle) path).setStroke(Paint.valueOf("red"));
					((Rectangle) path).setStrokeWidth(40);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
				}
			} else {
				if (path instanceof SVGPath) {
					((SVGPath) path).setStroke(Paint.valueOf("black"));
					((SVGPath) path).setStrokeWidth(10);
				} else if (path instanceof Polygon) {
					((Polygon) path).setStroke(Paint.valueOf("black"));
					((Polygon) path).setStrokeWidth(10);
				} else if (path instanceof Rectangle) {
					((Rectangle) path).setStroke(Paint.valueOf("black"));
					((Rectangle) path).setStrokeWidth(10);
				}
			}
		}
		for (Node path : nodeShipSideView) {
			if (path.getId().equalsIgnoreCase(tankName)) {
				if (path instanceof SVGPath) {
					((SVGPath) path).setStroke(Paint.valueOf("red"));
					((SVGPath) path).setStrokeWidth(50);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
				} else if (path instanceof Polygon) {
					((Polygon) path).setStroke(Paint.valueOf("red"));
					((Polygon) path).setStrokeWidth(50);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
				} else if (path instanceof Rectangle) {
					((Rectangle) path).setStroke(Paint.valueOf("red"));
					((Rectangle) path).setStrokeWidth(50);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
				}
			} else {
				if (path instanceof SVGPath) {
					((SVGPath) path).setStroke(Paint.valueOf("black"));
					((SVGPath) path).setStrokeWidth(10);
				} else if (path instanceof Polygon) {
					((Polygon) path).setStroke(Paint.valueOf("black"));
					((Polygon) path).setStrokeWidth(10);
				} else if (path instanceof Rectangle) {
					((Rectangle) path).setStroke(Paint.valueOf("black"));
					((Rectangle) path).setStrokeWidth(10);
				}
			}
		}
	}

	public LinearGradient getGradientFillTop(CargoLibrary cargoLib, Tank t, String percFill) {
		Color c1 = Color.web("E8A900", 1);
		String perc = " 5%, ";
		if (t != null) {
			if (t.getTankColor() != null) {
				try {
					c1 = Color.web(t.getTankColor(), 1.0);
				} catch (Exception e) {
					logger.error(e + "" + t.getTankColor());
				}

			}
			if (cargoLib != null) {
				c1 = Color.web(cargoLib.getColor(), 1.0);
			}
			if (percFill != null) {
				perc = " " + percFill.replaceFirst("%", "").replaceAll("\\s+", "") + "%, ";
			}

			Color c2 = Color.web("ffffff", 0.3);
			LinearGradient g = LinearGradient.valueOf("linear-gradient(to left top," + c1.toString().replaceAll("0x", "#") + " 0%," + c1.toString().replaceAll("0x", "#") + perc + c2 + perc + c2 + " 100%)");
			for (Node path : nodeShipTopView) {
				if (path.getId().equalsIgnoreCase(t.getName())) {
					if (path instanceof SVGPath) {
						((SVGPath) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					} else if (path instanceof Polygon) {
						((Polygon) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					} else if (path instanceof Rectangle) {
						((Rectangle) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					}
				}
			}
		}
		return null;
	}

	public LinearGradient getGradientFillSide(CargoLibrary cargoLib, Tank t, String percFill) {
		Color c1 = Color.web("E8A900", 1);
		String perc = " 5%, ";
		if (t != null) {
			if (t.getTankColor() != null) {
				try {
					c1 = Color.web(t.getTankColor(), 1.0);
				} catch (Exception e) {
					logger.error(e + "" + t.getTankColor());
				}
			}
			if (cargoLib != null) {
				c1 = Color.web(cargoLib.getColor(), 1.0);
			}
			if (percFill != null) {
				perc = " " + percFill.replaceFirst("%", "").replaceAll("\\s+", "") + "%, ";
			}

			Color c2 = Color.web("ffffff", 0.3);
			LinearGradient g = LinearGradient.valueOf("linear-gradient(to top," + c1.toString().replaceAll("0x", "#") + " 0%," + c1.toString().replaceAll("0x", "#") + perc + c2 + perc + c2 + " 100%)");
			for (Node path : nodeShipSideView) {
				if (path.getId().equalsIgnoreCase(t.getName()) && t.getTankType() != TankType.BALLAST) {
					if (path instanceof SVGPath) {
						((SVGPath) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					} else if (path instanceof Polygon) {
						((Polygon) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					} else if (path instanceof Rectangle) {
						((Rectangle) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					}
				} else if (path.getId().contains(t.getName())) {
					if (path instanceof SVGPath) {
						((SVGPath) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					} else if (path instanceof Polygon) {
						((Polygon) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					} else if (path instanceof Rectangle) {
						((Rectangle) path).setFill(g);
						tankSVGSelected = path;
						createShipTankPosition.createTankView(tankSVGSelected);
					}
				}
			}
		}
		return null;
	}

	public void resize(Group svg, double width, double height) {

		double originalWidth = svg.prefWidth(-1);
		double originalHeight = svg.prefHeight(originalWidth);

		double scaleX = width / originalWidth;
		double scaleY = height / originalHeight;

		svg.setScaleX(scaleX);
		svg.setScaleY(scaleY);
	}

	public boolean showInformation(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.initStyle(StageStyle.UTILITY);
		alert.setTitle("Information");
		alert.setHeaderText(title);
		alert.setContentText(message);
		JavaFXUtils.undecorate(alert, closeButton, themeManager);
		alert.showAndWait();
		Optional<ButtonType> optional = alert.showAndWait();
		if (optional.isPresent() && optional.get() == ButtonType.OK)
			return true;
		else
			return false;
	}
	public boolean showWaring(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.initStyle(StageStyle.UTILITY);
		alert.setTitle("Information");
		alert.setHeaderText(title);
		alert.setContentText(message);
		JavaFXUtils.undecorate(alert, closeButton, themeManager);
		alert.showAndWait();
		Optional<ButtonType> optional = alert.showAndWait();
		if (optional.isPresent() && optional.get() == ButtonType.OK)
			return true;
		else
			return false;
	}

	private void selectTankDetails(Tank tank) {
		String dens = getDensityFromSpreadsheetView(tank);
		Stage tankDetailsStage = new Stage(StageStyle.UNDECORATED);
		tankDetailsStage.setTitle("Tank Details");
		tankDetailsStage.initModality(Modality.WINDOW_MODAL);
		tankDetailsStage.setResizable(true);
		tankDetailsStage.initOwner((Stage) shipViewBorderPane.getScene().getWindow());

		FXMLLoader loaderTankDetails = new FXMLLoader(getClass().getResource("TankDetails.fxml"));
		try {
			Parent root = loaderTankDetails.load();
			tankDetailsStage.setScene(new Scene(root));
			JavaFXUtils.undecorate(tankDetailsStage, closeButton, themeManager);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		TankDetailsController tankDetailsController = (TankDetailsController) loaderTankDetails.getController();
		tankDetailsController.setTank(tank);
		tankDetailsController.setStage(tankDetailsStage);
		tankDetailsController.fillData(dens);
		tankDetailsStage.showAndWait();
	}

	private void selectTankBallastType(Node path) throws IOException {
		Stage tankDetailsStage = new Stage(StageStyle.UNDECORATED);
		String[] tankId = path.getId().split("and");
		Tank t0 = getTankByListUsingName(tankId[0]);
		Tank t1 = getTankByListUsingName(tankId[1]);
		TableView<Tank> selectTank = new TableView<Tank>();
		selectTank.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		TableColumn<Tank, String> tankName = new TableColumn<Tank, String>();
		tankName.setText("Tank Name");
		selectTank.getColumns().add(tankName);
		selectTank.getItems().addAll(t0, t1);

		tankName.setCellValueFactory(new PropertyValueFactory<>("name"));
		selectTank.setRowFactory(tableView -> {
			final TableRow<Tank> row = new TableRow<>();
			row.selectedProperty().addListener((observable) -> {
				final Tank t = row.getItem();
				if (row.isSelected() && t != null) {
					Tooltip toolTipTank = new Tooltip();
					StringBuilder tooltipText = new StringBuilder();
					tooltipText.append("Tank Name:" + t.getName());
					tooltipText.append(System.lineSeparator());
					tooltipText.append("Tank Type:" + t.getTankType());
//					tooltipText.append(System.lineSeparator());
//					tooltipText.append("Current Weight:" + t.getVolume());
//					tooltipText.append(System.lineSeparator());
//					tooltipText.append("Available Weight:" + t.getVolume());
					tooltipText.append(System.lineSeparator());
					tooltipText.append("Max Volume:" + t.getVolume());
					toolTipTank.setText(tooltipText.toString());
					if (path instanceof SVGPath) {
						((SVGPath) path).setStrokeWidth(10.0);
						((SVGPath) path).setUserData(t);
						getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						Tooltip.install(path, toolTipTank);

					} else if (path instanceof Polygon) {
						((Polygon) path).setStrokeWidth(10.0);
						((Polygon) path).setUserData(t);
						getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						Tooltip.install(path, toolTipTank);

					} else if (path instanceof Rectangle) {
						((Rectangle) path).setStrokeWidth(10.0);
						((Rectangle) path).setUserData(t);
						getGradientFillSide(null, (Tank) path.getUserData(), getTableCellItemVolumePerc((Tank) path.getUserData()));
						Tooltip.install(path, toolTipTank);

					}
					selectTableRowFromSVG(path);
					tankSVGSelected = path;
					createShipTankPosition.createTankView(tankSVGSelected);
					tankDetailsStage.close();
				}
			});

			row.hoverProperty().addListener((observable) -> {
				final Tank tank = row.getItem();
				if (row.isHover() && tank != null) {
					row.setStyle("-fx-background-color: #e86b11;");
				} else {
					row.setStyle(row.getStyle().replaceAll("-fx-background-color: #e86b11;", " "));
				}
			});

			return row;
		});
		tankDetailsStage.setTitle("Please Select Tank");
		tankDetailsStage.initModality(Modality.WINDOW_MODAL);
		tankDetailsStage.setResizable(true);
		tankDetailsStage.initOwner((Stage) shipViewBorderPane.getScene().getWindow());
		tankDetailsStage.setScene(new Scene(selectTank));
		JavaFXUtils.undecorate(tankDetailsStage, closeButton, themeManager);
		tankDetailsStage.setHeight(120.0);
		Stage parentStage = (Stage) shipViewBorderPane.getScene().getWindow();
		final double midX = (parentStage.getX() + parentStage.getWidth()) / 2;
		final double midY = (parentStage.getY() + parentStage.getHeight()) / 1.3;
		tankDetailsStage.setX(midX);
		tankDetailsStage.setY(midY);
		tankDetailsStage.showAndWait();
	}

	private void loadCargoLibrary(Tab oldTab, Tab newTab) {
		setCargoLibrary(shipTanksService.getCargoLibrary());
		Stage cargoLibraryStage = new Stage(StageStyle.UNDECORATED);
		cargoLibraryStage.setTitle("Cargo Library");
		cargoLibraryStage.initModality(Modality.WINDOW_MODAL);
		cargoLibraryStage.setResizable(true);
		if (shipViewBorderPane.getScene() != null) {
			cargoLibraryStage.initOwner((Stage) shipViewBorderPane.getScene().getWindow());

			FXMLLoader loaderCargoLibrary = new FXMLLoader(getClass().getResource("CargoLibrary.fxml"));
			try {
				Parent root = loaderCargoLibrary.load();
				cargoLibraryStage.setScene(new Scene(root));// -fx-background-color: #8497B0;
				JavaFXUtils.undecorate(cargoLibraryStage, closeButton, themeManager);
			} catch (IOException e) {
				logger.error(e.toString());
			}
			CargoLibraryController cargoLibraryController = (CargoLibraryController) loaderCargoLibrary.getController();
			cargoLibraryController.setStage(cargoLibraryStage);
			smartLoadTabPane.getSelectionModel().clearAndSelect(smartLoadTabPane.getTabs().indexOf(oldTab));
			cargoLibraryController.setSmartloadViewController(this);
			cargoLibraryController.fillDatat();
			cargoLibraryStage.showAndWait();

		}
	}

	private void loadOpenSaved() {
		Stage openSavedStage = new Stage(StageStyle.UNDECORATED);
		openSavedStage.setTitle("Open Saved");
		openSavedStage.initModality(Modality.WINDOW_MODAL);
		openSavedStage.setResizable(true);
		if (shipViewBorderPane.getScene() != null) {
			openSavedStage.initOwner((Stage) shipViewBorderPane.getScene().getWindow());

			FXMLLoader loaderOpenSaved = new FXMLLoader(getClass().getResource("OpenSaved.fxml"));
			try {
				Parent root = loaderOpenSaved.load();
				openSavedStage.setScene(new Scene(root));// -fx-background-color: #8497B0;
				JavaFXUtils.undecorate(openSavedStage, closeButton, themeManager);
			} catch (IOException e) {
				logger.error(e.toString());
			}
			OpenSavedController openSavedController = (OpenSavedController) loaderOpenSaved.getController();
			openSavedController.setStage(openSavedStage);
			openSavedController.setShipTanksService(shipTanksService);
			openSavedController.setSmartloadViewController(this);
			openSavedController.setSmartloadPreferencePage(smartloadPreferencePage);
			openSavedController.fillDatat();
			openSavedStage.showAndWait();

		}
	}

	public boolean saveTankLoadingData() {
		try {
			Date date = new Date();// local Time
			if (tankSavedData == null || tankSavedData.getTankLoading().isEmpty()) {
				TankSavedData saveTankLoadData = tankSavedData;
				if (tankSavedData == null) {
					saveTankLoadData = new TankSavedData();
					saveTankLoadData.setUuid(UUID.randomUUID().toString());
					saveTankLoadData.setCreatedDate(date);
					saveTankLoadData.setModifiedDate(date);
					saveTankLoadData.setName("Untitled(" + date.toLocaleString() + ")");
					saveTankLoadData.setType("Condition");
					saveTankLoadData.setShip(ship);
					Voyage addNewVoyage=new Voyage();
					LocalDateTime compileLocalDate = stowagePlanController.getVoyageFromLocalDateTimeTextField().getLocalDateTime();
					if (stowagePlanController.getVoyageNrTextField().getText()==null||stowagePlanController.getVoyageNrTextField().getText().isEmpty()) {
					 showInformation("Voyage Number", "Please Insert Voyage Number");
					 return false;
					}
					if (stowagePlanController.getVoyageFromTextField().getText()==null||stowagePlanController.getVoyageFromTextField().getText().isEmpty()) {
						 showInformation("Voyage From", "Please Insert Voyage From");
						 return false;
					}
					if (stowagePlanController.getVoyageToTextField().getText()==null||stowagePlanController.getVoyageToTextField().getText().isEmpty()) {
						 showInformation("Voyage To", "Please Insert Voyage To");
						 return false;
					}
					if (compileLocalDate==null) {
						 showInformation("Voyage Date", "Please Insert Voyage Date");
						 return false;
					}
					addNewVoyage.setVoyageNumber(stowagePlanController.getVoyageNrTextField().getText());
					addNewVoyage.setVoyageFrom(stowagePlanController.getVoyageFromTextField().getText());
					addNewVoyage.setVoyageTo(stowagePlanController.getVoyageToTextField().getText());
					addNewVoyage.setVoyageDate(Timestamp.valueOf(compileLocalDate));
					if (calculationsController.getSeaCheckBox().isSelected()) {
						addNewVoyage.setVoyageType(VoyageType.SEA);
					}else if  (calculationsController.getPortCheckBox().isSelected()) {
						addNewVoyage.setVoyageType(VoyageType.PORT);
					}
					saveTankLoadData.setVoyage(addNewVoyage);
				}else if (tankSavedData!=null) {
					LocalDateTime compileLocalDate = stowagePlanController.getVoyageFromLocalDateTimeTextField().getLocalDateTime();
					if (stowagePlanController.getVoyageNrTextField().getText()==null||stowagePlanController.getVoyageNrTextField().getText().isEmpty()) {
						showWaring("Voyage Number", "Please Insert Voyage Number");
					 return false;
					}
					if (stowagePlanController.getVoyageFromTextField().getText()==null||stowagePlanController.getVoyageFromTextField().getText().isEmpty()) {
						showWaring("Voyage From", "Please Insert Voyage From");
					 return false;
					}
					if (stowagePlanController.getVoyageToTextField().getText()==null||stowagePlanController.getVoyageToTextField().getText().isEmpty()) {
						showWaring("Voyage To", "Please Insert Voyage To");
					 return false;
					}
					if (compileLocalDate==null) {
						showWaring("Voyage Date", "Please Insert Voyage Date");
					 return false;
					}
					saveTankLoadData.getVoyage().setVoyageNumber(stowagePlanController.getVoyageNrTextField().getText());
					saveTankLoadData.getVoyage().setVoyageFrom(stowagePlanController.getVoyageFromTextField().getText());
					saveTankLoadData.getVoyage().setVoyageTo(stowagePlanController.getVoyageToTextField().getText());
					saveTankLoadData.getVoyage().setVoyageDate(Timestamp.valueOf(compileLocalDate));
					if (calculationsController.getSeaCheckBox().isSelected()) {
						saveTankLoadData.getVoyage().setVoyageType(VoyageType.SEA);
					}else if  (calculationsController.getPortCheckBox().isSelected()) {
						saveTankLoadData.getVoyage().setVoyageType(VoyageType.PORT);
					}
				}
				saveTankLoadData.setTankLoading(new ArrayList<TankLoading>());
				// Cargo tanks
				for (ObservableList<SpreadsheetCell> row : cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows()) {

					int rowIndex = cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows().indexOf(row);
					if (rowIndex != 0 && rowIndex != cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows().size() - 1) {
						TankLoading tankLoad = new TankLoading();
						Tank tank = cargoAndSlopTanks.get(rowIndex - 1);
						tankLoad.setTank(tank);
						SpreadsheetCell cargoCell = row.get(0);
						HBox cargoHbox = (HBox) cargoCell.getGraphic();
						Label cargoLabel = (Label) cargoHbox.getChildren().get(0);
						CargoLibrary cargLib = cargoHbox.getUserData() != null ? (CargoLibrary) cargoHbox.getUserData() : null;
						CargoType cargType = cargoLabel.getUserData() != null ? (CargoType) cargoLabel.getUserData() : null;
						if (cargLib != null) {
							tankLoad.setCargoLibrary(cargLib);
						} else if (cargType != null) {
							tankLoad.setCargoType(cargType);
						} else {
							tankLoad.setCargoType(CargoType.PRODUCTS);
						}
						SpreadsheetCell volPercentCell = row.get(4);
						SpreadsheetCell temperatureCell = row.get(5);
						SpreadsheetCell densityCell = row.get(6);
						tankLoad.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
						tankLoad.setTemperature((Quantity<Temperature>) temperatureCell.getItem());
						tankLoad.setDensity((Quantity<Density>) densityCell.getItem());
						tankLoad.setDate(date);
						tankLoad.setUuid(UUID.randomUUID().toString());
						saveTankLoadData.getTankLoading().add(tankLoad);
						tankLoad.setTankSavedData(saveTankLoadData);
					}
				}
				// ballast tanks
				for (ObservableList<SpreadsheetCell> row : ballastController.getBallastTankSpreadsheetView().getGrid().getRows()) {

					int rowIndex = ballastController.getBallastTankSpreadsheetView().getGrid().getRows().indexOf(row);
					if (rowIndex != 0 && rowIndex != ballastController.getBallastTankSpreadsheetView().getGrid().getRows().size() - 1) {
						TankLoading tankLoad = new TankLoading();
						Tank tank = ballastTanks.get(rowIndex - 1);
						tankLoad.setTank(tank);
						SpreadsheetCell densityCell = row.get(2);
						SpreadsheetCell volPercentCell = row.get(4);
						tankLoad.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
						tankLoad.setDensity((Quantity<Density>) densityCell.getItem());
						tankLoad.setDate(date);
						tankLoad.setUuid(UUID.randomUUID().toString());
						saveTankLoadData.getTankLoading().add(tankLoad);
						tankLoad.setTankSavedData(saveTankLoadData);
					}
				}
				// engine tanks
				for (ObservableList<SpreadsheetCell> row : engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows()) {

					int rowIndex = engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows().indexOf(row);
					if (rowIndex != 0 && rowIndex != engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows().size() - 1) {
						TankLoading tankLoad = new TankLoading();
						Tank tank = engineTanks.get(rowIndex - 1);
						tankLoad.setTank(tank);
						SpreadsheetCell densityCell = row.get(3);
						SpreadsheetCell volPercentCell = row.get(5);
						tankLoad.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
						tankLoad.setDensity((Quantity<Density>) densityCell.getItem());
						tankLoad.setDate(date);
						tankLoad.setUuid(UUID.randomUUID().toString());
						saveTankLoadData.getTankLoading().add(tankLoad);
						tankLoad.setTankSavedData(saveTankLoadData);
					}
				}
				// other tanks
				for (ObservableList<SpreadsheetCell> row : otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows()) {

					int rowIndex = otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows().indexOf(row);
					if (rowIndex != 0 && rowIndex != otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows().size() - 1) {
						TankLoading tankLoad = new TankLoading();
						Tank tank = otherTanks.get(rowIndex - 1);
						tankLoad.setTank(tank);
						SpreadsheetCell densityCell = row.get(2);
						SpreadsheetCell volPercentCell = row.get(4);
						SpreadsheetCell weightCell = row.get(5);
						tankLoad.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
						tankLoad.setDensity((Quantity<Density>) densityCell.getItem());
						tankLoad.setDate(date);
						tankLoad.setUuid(UUID.randomUUID().toString());
						if (tank.getTankType().equals(TankType.CONSTANTS)||tank.getTankType().equals(TankType.CONSUMABLES)) {
							tankLoad.setWeightFill((Quantity<Mass>) weightCell.getItem());	
						}
						saveTankLoadData.getTankLoading().add(tankLoad);
						tankLoad.setTankSavedData(saveTankLoadData);
					}
				}
				shipTanksService.saveTankSavedData(saveTankLoadData);
				tankSavedData = shipTanksService.getTankSavedDataByUUID(saveTankLoadData.getUuid());
			} else {
				TankSavedData saveTankLoadData = tankSavedData;
				LocalDateTime compileLocalDate = stowagePlanController.getVoyageFromLocalDateTimeTextField().getLocalDateTime();
				if (stowagePlanController.getVoyageNrTextField().getText()==null||stowagePlanController.getVoyageNrTextField().getText().isEmpty()) {
					showWaring("Voyage Number", "Please Insert Voyage Number");
				 return false;
				}
				if (stowagePlanController.getVoyageFromTextField().getText()==null||stowagePlanController.getVoyageFromTextField().getText().isEmpty()) {
					showWaring("Voyage From", "Please Insert Voyage From");
					 return false;
				}
				if (stowagePlanController.getVoyageToTextField().getText()==null||stowagePlanController.getVoyageToTextField().getText().isEmpty()) {
					showWaring("Voyage To", "Please Insert Voyage To");
					 return false;
				}
				if (compileLocalDate==null) {
					showWaring("Voyage Date", "Please Insert Voyage Date");
					 return false;
				}
				if (calculationsController.getSeaCheckBox().isSelected()) {
					saveTankLoadData.getVoyage().setVoyageType(VoyageType.SEA);
				}else if  (calculationsController.getPortCheckBox().isSelected()) {
					saveTankLoadData.getVoyage().setVoyageType(VoyageType.PORT);
				}
				saveTankLoadData.getVoyage().setVoyageNumber(stowagePlanController.getVoyageNrTextField().getText());
				saveTankLoadData.getVoyage().setVoyageFrom(stowagePlanController.getVoyageFromTextField().getText());
				saveTankLoadData.getVoyage().setVoyageTo(stowagePlanController.getVoyageToTextField().getText());
				saveTankLoadData.getVoyage().setVoyageDate(Timestamp.valueOf(compileLocalDate));
				
				List<TankLoading> oldTankLoadData = saveTankLoadData.getTankLoading();
				if (oldTankLoadData.size() > 1) {
					for (TankLoading oldLoading : oldTankLoadData) {

						for (ObservableList<SpreadsheetCell> row : cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows()) {
							int rowIndex = cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows().indexOf(row);
							if (rowIndex != 0 && rowIndex != cargoTankController.getCargoTankSpreadsheetView().getGrid().getRows().size() - 1) {
								Tank tank = cargoAndSlopTanks.get(rowIndex - 1);
								if (oldLoading.getTank().getId().equals(tank.getId())) {
									oldLoading.setTank(tank);
									SpreadsheetCell cargoCell = row.get(0);
									HBox cargoHbox = (HBox) cargoCell.getGraphic();
									Label cargoLabel = (Label) cargoHbox.getChildren().get(0);
									CargoLibrary cargLib = cargoHbox.getUserData() != null ? (CargoLibrary) cargoHbox.getUserData() : null;
									CargoType cargType = cargoLabel.getUserData() != null ? (CargoType) cargoLabel.getUserData() : null;
									if (cargLib != null) {
										oldLoading.setCargoLibrary(cargLib);
									} else if (cargType != null) {
										oldLoading.setCargoType(cargType);
									} else {
										oldLoading.setCargoType(CargoType.PRODUCTS);
									}
									SpreadsheetCell volPercentCell = row.get(4);
									SpreadsheetCell temperatureCell = row.get(5);
									SpreadsheetCell densityCell = row.get(6);
									oldLoading.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
									oldLoading.setTemperature((Quantity<Temperature>) temperatureCell.getItem());
									oldLoading.setDensity((Quantity<Density>) densityCell.getItem());
									oldLoading.setDate(date);
								}
							}
						}
						// ballast tanks
						for (ObservableList<SpreadsheetCell> row : ballastController.getBallastTankSpreadsheetView().getGrid().getRows()) {
							int rowIndex = ballastController.getBallastTankSpreadsheetView().getGrid().getRows().indexOf(row);
							if (rowIndex != 0 && rowIndex != ballastController.getBallastTankSpreadsheetView().getGrid().getRows().size() - 1) {
								Tank tank = ballastTanks.get(rowIndex - 1);
								if (oldLoading.getTank().getId().equals(tank.getId())) {
									oldLoading.setTank(tank);
									SpreadsheetCell densityCell = row.get(2);
									SpreadsheetCell volPercentCell = row.get(4);
									oldLoading.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
									oldLoading.setDensity((Quantity<Density>) densityCell.getItem());
									oldLoading.setDate(date);
								}
							}
						}
						// engine tanks
						for (ObservableList<SpreadsheetCell> row : engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows()) {
							int rowIndex = engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows().indexOf(row);
							if (rowIndex != 0 && rowIndex != engineSpaceController.getEngineTankSpreadsheetView().getGrid().getRows().size() - 1) {
								Tank tank = engineTanks.get(rowIndex - 1);
								if (oldLoading.getTank().getId().equals(tank.getId())) {
									oldLoading.setTank(tank);
									SpreadsheetCell densityCell = row.get(3);
									SpreadsheetCell volPercentCell = row.get(5);
									oldLoading.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
									oldLoading.setDensity((Quantity<Density>) densityCell.getItem());
									oldLoading.setDate(date);
								}
							}
						}
						// other tanks
						for (ObservableList<SpreadsheetCell> row : otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows()) {
							int rowIndex = otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows().indexOf(row);
							if (rowIndex != 0 && rowIndex != otherTanksController.getOtherTankSpreadsheetView().getGrid().getRows().size() - 1) {
								Tank tank = otherTanks.get(rowIndex - 1);
								if (oldLoading.getTank().getId().equals(tank.getId())) {
									oldLoading.setTank(tank);
									SpreadsheetCell densityCell = row.get(2);
									SpreadsheetCell volPercentCell = row.get(4);
									SpreadsheetCell weightCell = row.get(5);
									oldLoading.setVolumeFillPercentage((Number) ((Quantity<Dimensionless>) volPercentCell.getItem()).getValue());
									oldLoading.setDensity((Quantity<Density>) densityCell.getItem());
									oldLoading.setDate(date);
									if (tank.getTankType().equals(TankType.CONSTANTS)||tank.getTankType().equals(TankType.CONSUMABLES)) {
										oldLoading.setWeightFill((Quantity<Mass>) weightCell.getItem());	
									}

								}
							}
						}
					}
				}
				shipTanksService.saveTankSavedData(saveTankLoadData);
				tankSavedData = shipTanksService.getTankSavedDataByUUID(saveTankLoadData.getUuid());

			}
			return true;
		} catch (Exception e) {
			logger.error("While saving tank loading data" + e);
			return false;
		}
	}

	public void writeTankSavedDataToSpreadsheet(TankSavedData tankSaved) {
		if (tankSaved!=null) {
		stowagePlanController.getVoyageNrTextField().setText(tankSaved.getVoyage().getVoyageNumber());
		stowagePlanController.getVoyageFromTextField().setText(tankSaved.getVoyage().getVoyageFrom());
		stowagePlanController.getVoyageToTextField().setText(tankSaved.getVoyage().getVoyageTo());
		if (tankSaved.getVoyage().getVoyageType().equals(VoyageType.SEA)) {
			calculationsController.getSeaCheckBox().setSelected(true);	
		}
		if (tankSaved.getVoyage().getVoyageType().equals(VoyageType.PORT)) {
			calculationsController.getPortCheckBox().setSelected(true);	
		}
		if (tankSaved.getVoyage().getVoyageDate()!=null) {
			stowagePlanController.getVoyageFromLocalDateTimeTextField().setLocalDateTime(tankSaved.getVoyage().getVoyageDate().toLocalDateTime());
				
		}else {
			stowagePlanController.getVoyageFromLocalDateTimeTextField().setLocalDateTime(null);
		}
		}else {
			int sizeVoyage = getShipTanksService().getAllVoyage().size();
	    	sizeVoyage++;
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYY");
			stowagePlanController.getVoyageNrTextField().setText("Nr:"+sizeVoyage+"-"+simpleDateFormat.format(new Date()).toUpperCase());
			stowagePlanController.getVoyageFromTextField().setText(null);
			stowagePlanController.getVoyageToTextField().setText(null);
			calculationsController.getSeaCheckBox().setSelected(true);	
			stowagePlanController.getVoyageFromLocalDateTimeTextField().setLocalDateTime(null);
				
		}
		setTankSavedData(tankSaved);
		cargoTankController.openTankLoad(tankSavedData);
		ballastController.openTankLoad(tankSavedData);
		engineSpaceController.openTankLoad(tankSavedData);
		otherTanksController.openTankLoad(tankSavedData);

	}

	public SimpleObjectProperty<Object> selectCargoTypeDetails(CargoType cargoType, CargoLibrary cargoLib) {
		Stage cargoLibraryDetailsStage = new Stage(StageStyle.UNDECORATED);
		cargoLibraryDetailsStage.setTitle("Define Cargo:");
		cargoLibraryDetailsStage.initModality(Modality.WINDOW_MODAL);
		cargoLibraryDetailsStage.setResizable(true);
		cargoLibraryDetailsStage.initOwner((Stage) shipViewBorderPane.getScene().getWindow());

		FXMLLoader loadercargoLibraryDetails = new FXMLLoader(getClass().getResource("CargoLibraryDetails.fxml"));
		try {
			Parent root = loadercargoLibraryDetails.load();
			cargoLibraryDetailsStage.setScene(new Scene(root));
			JavaFXUtils.undecorate(cargoLibraryDetailsStage, closeButton, themeManager);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CargoLibraryDetailsController cargoLibraryDetailsController = (CargoLibraryDetailsController) loadercargoLibraryDetails.getController();
		cargoLibraryDetailsController.setCargoLibrarySel(cargoLib);
		cargoLibraryDetailsController.setCargoType(cargoType);
		cargoLibraryDetailsController.setStage(cargoLibraryDetailsStage);
		cargoLibraryDetailsController.setShipTanksService(shipTanksService);
		cargoLibraryDetailsController.fillData();
		cargoLibraryDetailsStage.showAndWait();
		return ((CargoLibraryDetailsController) loadercargoLibraryDetails.getController()).getCargoTypeProperty();
	}

	private void firstLoadResize() {
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
		double width = primaryScreenBounds.getWidth();
		shipBoderPaneCenterWidth = width * 0.80;
		shipBoderPaneRightWidth = width - shipBoderPaneCenterWidth;
		mainTabPane.setPrefWidth(width - 5);
		smartLoadTabPane.setPrefWidth(width - 5);
		createShipTankPosition.getSubScene().setWidth(shipBoderPaneRightWidth - 50);
		createShipTankPosition.getSubScene().setHeight((shipBoderPaneCenterWidth * 0.10) + 30);
		resize(svgGroupShipTop, shipBoderPaneCenterWidth / 2, (shipBoderPaneCenterWidth) * 0.12);
		resize(svgGroupShipSide, shipBoderPaneCenterWidth / 2, (shipBoderPaneCenterWidth) * 0.12);
		// svgGroupShipSide.setRotate(0.5);
		// seaWaterView.setRotate(0.5);
		// 20px arrowtab
//		final Rotate rotationTransform = new Rotate(-0.2, 50, 50);
//		svgGroupShipSide.getTransforms().add(rotationTransform);
//		rotationTransform.setAxis(Rotate.X_AXIS);
//		final Timeline rotationAnimation = new Timeline();
//	    rotationAnimation.getKeyFrames()
//	      .add(
//	        new KeyFrame(
//	          Duration.seconds(5),
//	          new KeyValue(
//	            rotationTransform.angleProperty(),
//	            10
//	          )
//	        )
//	      );
//	    rotationAnimation.setCycleCount(Animation.INDEFINITE);
//	    rotationAnimation.play();
//		seaWaterView.getTransforms().add(new Rotate(0.2, 50, 50));
		Side sideSmart = smartLoadTabPane.getSide();
		int numTabSmart = smartLoadTabPane.getTabs().size() != 0 ? smartLoadTabPane.getTabs().size() : 8;
		if ((sideSmart == Side.BOTTOM || sideSmart == Side.TOP) && numTabSmart != 0) {
			if (width / numTabSmart - (20) >= 150) {
				smartLoadTabPane.setStyle("-fx-tab-min-width:" + (width / numTabSmart - (20)) + "px; ");
			}
		}
		// 300px log image + 20px arrowtab
		Side sideMain = mainTabPane.getSide();
		int numTabMain = mainTabPane.getTabs().size() != 0 ? mainTabPane.getTabs().size() : 7;
		if ((sideMain == Side.BOTTOM || sideMain == Side.TOP) && numTabMain != 0) {
			if ((width - 300) / numTabMain - (20) >= 150) {
				mainTabPane.setStyle("-fx-tab-min-width:" + ((width - 300) / numTabMain - (20)) + "px; ");
			}
		}
	}

	private void stageSizeChageListener(Stage stage) {
		stage.widthProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				logger.info("Width changed!!");
				logger.info("New value:" + newValue);
				shipBoderPaneCenterWidth = newValue.doubleValue() * 0.80;
				shipBoderPaneRightWidth = newValue.doubleValue() - shipBoderPaneCenterWidth;
				shipViewBorderPane.getCenter().prefWidth(shipBoderPaneCenterWidth);
				shipViewBorderPane.getCenter().prefHeight(shipBoderPaneCenterWidth * 0.12);
				resize(svgGroupShipTop, shipBoderPaneCenterWidth / 2, (shipBoderPaneCenterWidth) * 0.12);
				resize(svgGroupShipSide, shipBoderPaneCenterWidth / 2, (shipBoderPaneCenterWidth) * 0.12);
				createShipTankPosition.getSubScene().setWidth(shipBoderPaneRightWidth - 50);
				createShipTankPosition.getSubScene().setHeight((shipBoderPaneCenterWidth * 0.10) + 30);
				mainTabPane.setPrefWidth(newValue.doubleValue() - 20);
				smartLoadTabPane.setPrefWidth(newValue.doubleValue() - 20);
				// 20px arrowtab
				Side sideSmart = smartLoadTabPane.getSide();
				int numTabSmart = smartLoadTabPane.getTabs().size();
				if ((sideSmart == Side.BOTTOM || sideSmart == Side.TOP) && numTabSmart != 0) {
					if (newValue.intValue() / numTabSmart - (20) >= 150) {
						smartLoadTabPane.setStyle("-fx-tab-min-width:" + (newValue.intValue() / numTabSmart - (20)) + "px; ");
					}
				}
				// 300px log image + 20px arrowtab
				Side sideMain = mainTabPane.getSide();
				int numTabMain = mainTabPane.getTabs().size();
				if ((sideMain == Side.BOTTOM || sideMain == Side.TOP) && numTabMain != 0) {
					if ((newValue.intValue() - 300) / numTabMain - (20) >= 150) {
						mainTabPane.setStyle("-fx-tab-min-width:" + ((newValue.intValue() - 300) / numTabMain - (20)) + "px; ");
					}
				}
			}
		});

		stage.heightProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				logger.info("Height changed!!");
				logger.info("New value:" + newValue);
			}
		});

	}

	public static boolean showConfirmation(String title, String message) {
		alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.initStyle(StageStyle.UTILITY);
		alert.setTitle("Confirmation");
		alert.setHeaderText(title);
		alert.setContentText(message);
		JavaFXUtils.undecorate(alert, closeButton, themeManager);
		Optional<ButtonType> optional = alert.showAndWait();
		if (optional.isPresent() && optional.get() == ButtonType.OK)
			return true;
		else
			return false;
	}

	public BorderPane shipViewBasedOnTanks() {
		return shipViewBorderPane;
	}

	public void setSmartLoadCargoTankController(CargoTankController cargoTankController) {
		this.cargoTankController = cargoTankController;
	}

	public void setSmartLoadBallastController(BallastController ballastController) {
		this.ballastController = ballastController;
	}

	public void setSmartLoadEngineSpaceController(EngineSpaceController engineSpaceController) {
		this.engineSpaceController = engineSpaceController;
	}

	public void setSmartLoadOtherTanksController(OtherTanksController otherTanksController) {
		this.otherTanksController = otherTanksController;
	}

	public void setSmartLoadSummaryController(SummaryController summaryController) {
		this.summaryController = summaryController;
	}

	public void setSmartLoadStrengthStabilityController(StrengthStabilityController strengthStabilityController) {
		this.setStrengthStabilityController(strengthStabilityController);
	}

	public void setSmartLoadStowagePlanController(StowagePlanController stowagePlanController) {
		this.setStowagePlanController(stowagePlanController);
	}

	public void setSmartLoadCargoLibraryController(CargoLibraryController cargoLibraryController) {
		this.setCargoLibraryController(cargoLibraryController);
	}

	public VBox getCalculationsVBox() {
		return calculationsVBox;
	}

	public CalculationsController getCalculationsController() {
		return calculationsController;
	}

	public CargoTankController getCargoTankController() {
		return cargoTankController;
	}

	public BallastController getBallastController() {
		return ballastController;
	}

	public EngineSpaceController getEngineSpaceController() {
		return engineSpaceController;
	}

	public OtherTanksController getOtherTanksController() {
		return otherTanksController;
	}

	public TabPane getSmartLoadTabPane() {
		return smartLoadTabPane;
	}

	public void setSmartLoadTabPane(TabPane smartLoadTabPane) {
		this.smartLoadTabPane = smartLoadTabPane;
	}

	public List<Tank> getBallastTanks() {
		return ballastTanks;
	}

	public void setBallastTanks(List<Tank> ballastTanks) {
		this.ballastTanks = ballastTanks;
	}

	public List<Tank> getCargoAndSlopTanks() {
		return cargoAndSlopTanks;
	}

	public void setCargoAndSlopTanks(List<Tank> cargoAndSlopTanks) {
		this.cargoAndSlopTanks = cargoAndSlopTanks;
	}

	public List<Tank> getEngineTanks() {
		return engineTanks;
	}

	public void setEngineTanks(List<Tank> engineTanks) {
		this.engineTanks = engineTanks;
	}

	public List<Tank> getOtherTanks() {
		return otherTanks;
	}

	public void setOtherTanks(List<Tank> otherTanks) {
		this.otherTanks = otherTanks;
	}

	private Tank getTankByListUsingName(String tankName) {
		for (Tank tank : allTanks) {
			if (tank.getName().trim().contains(tankName.trim())) {
				return tank;
			}
		}
		return null;
	}

	public List<TempDensTableType> getTempDensTableTypes() {
		return tempDensTableTypes;
	}

	public void setSmartLoadCalculationsVBox(VBox calculationsVBox) {
		this.calculationsVBox = calculationsVBox;
	}

	public void setSmartLoadCalculationsController(CalculationsController calculationsController) {
		this.calculationsController = calculationsController;
	}

	public Ship getShip() {
		return ship;
	}

	public TabPane getMainTabPane() {
		return mainTabPane;
	}

	public void setMainTabPane(TabPane mainTabPane) {
		this.mainTabPane = mainTabPane;
	}

	public TankSavedData getTankSavedData() {
		return tankSavedData;
	}

	public void setTankSavedData(TankSavedData tankSavedData) {
		this.tankSavedData = tankSavedData;
	}

	public MaskerPane getMaskerPane() {
		return maskerPane;
	}

	public void setMaskerPane(MaskerPane maskerPane) {
		this.maskerPane = maskerPane;
	}

	public ShipTanksService getShipTanksService() {
		return shipTanksService;
	}

	public void setShipTanksService(ShipTanksService shipTanksService) {
		this.shipTanksService = shipTanksService;
	}

	public SmartloadPreferencePage getSmartloadPreferencePage() {
		return smartloadPreferencePage;
	}

	public void setSmartloadPreferencePage(SmartloadPreferencePage smartloadPreferencePage) {
		this.smartloadPreferencePage = smartloadPreferencePage;
	}

	public List<CargoLibrary> getCargoLibrary() {
		return cargoLibrary;
	}

	public void setCargoLibrary(List<CargoLibrary> cargoLibrary) {
		this.cargoLibrary = cargoLibrary;
	}

	public TempDensityService getTempDensityService() {
		return tempDensityService;
	}

	public void setTempDensityService(TempDensityService tempDensityService) {
		this.tempDensityService = tempDensityService;
	}
	public SummaryController getSummaryController() {
		return summaryController;
	}

	public void setSummaryController(SummaryController summaryController) {
		this.summaryController = summaryController;
	}

	public Group getSvgGroupShipSide() {
		return svgGroupShipSide;
	}

	public void setSvgGroupShipSide(Group svgGroupShipSide) {
		this.svgGroupShipSide = svgGroupShipSide;
	}

	public Polygon getSeaWaterView() {
		return seaWaterView;
	}

	public void setSeaWaterView(Polygon seaWaterView) {
		this.seaWaterView = seaWaterView;
	}

	public StrengthStabilityController getStrengthStabilityController() {
		return strengthStabilityController;
	}

	public void setStrengthStabilityController(StrengthStabilityController strengthStabilityController) {
		this.strengthStabilityController = strengthStabilityController;
	}

	public StowagePlanController getStowagePlanController() {
		return stowagePlanController;
	}

	public void setStowagePlanController(StowagePlanController stowagePlanController) {
		this.stowagePlanController = stowagePlanController;
	}

	public CargoLibraryController getCargoLibraryController() {
		return cargoLibraryController;
	}

	public void setCargoLibraryController(CargoLibraryController cargoLibraryController) {
		this.cargoLibraryController = cargoLibraryController;
	}

	
}
