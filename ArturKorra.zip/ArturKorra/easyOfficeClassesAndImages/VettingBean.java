package com.oceanpro.web.tmsa;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.icefaces.ace.component.fileentry.FileEntry;
import org.icefaces.ace.component.fileentry.FileEntryEvent;
import org.icefaces.ace.component.fileentry.FileEntryResults;
import org.icefaces.ace.component.fileentry.FileEntryResults.FileInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.icesoft.faces.context.effects.JavascriptContext;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.FdfReader;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.oceanpro.communication.message.CommunicationMessageType;
import com.oceanpro.communication.message.DataExchangeMessage;
import com.oceanpro.communication.ship.CommunicatorSenderNave;
import com.oceanpro.core.entity.oceanManager.commons.Country;
import com.oceanpro.core.entity.oceanManager.commons.Port;
import com.oceanpro.core.entity.oceanManager.tmsa.Deficiency;
import com.oceanpro.core.entity.oceanManager.tmsa.DeficiencyModel;
import com.oceanpro.core.entity.oceanManager.tmsa.FollowupAndCorrectiveAction;
import com.oceanpro.core.entity.oceanManager.tmsa.Inspection;
import com.oceanpro.core.entity.oceanManager.tmsa.SelfAssessmentItem;
import com.oceanpro.core.entity.oceanManager.tmsa.TmsaForm;
import com.oceanpro.core.exception.DocumentException;
import com.oceanpro.core.services.AgendaService;
import com.oceanpro.core.services.AuditService;
import com.oceanpro.core.services.DocumentService;
import com.oceanpro.core.services.GenericLookupService;
import com.oceanpro.core.services.InspectionService;
import com.oceanpro.core.services.MessageService;
import com.oceanpro.core.services.RequisitionService;
import com.oceanpro.core.services.ScriptService;
import com.oceanpro.core.services.SelfAssessmentItemsService;
import com.oceanpro.core.utils.FileUtils;
import com.oceanpro.core.utils.PropertiesUtils;
import com.oceanpro.core.utils.formsUtils.FormDataManipulationReader;
import com.oceanpro.utils.EasyDateUtils;
import com.oceanpro.web.NavigationBean;
import com.oceanpro.web.store.RequisitionBean;
import com.oceanpro.web.tmsa.servlet.FormCompiler;
import com.oceanpro.web.utils.jsf.BaseBean;
import com.oceanpro.web.utils.jsf.FacesUtils;
import com.oceanpro.web.utils.servlet.DownloadListBean;
import com.thoughtworks.xstream.XStream;

@Component
@Scope("session")
@Qualifier("vettingBean")
public class VettingBean extends BaseBean implements FormCompiler {

	// Serial
	private static final Logger log = LoggerFactory.getLogger(VettingBean.class);
	private static final long serialVersionUID = 3728837297908143258L;

	@Autowired
	private CommunicatorSenderNave communicatorSenderNave;
	@Autowired
	private RequisitionService requisitionService;
	@Autowired
	DownloadListBean downloadListBean;
	@Autowired
	AuditService auditService;
	@Autowired
	GenericLookupService genericLookupService;
	@Autowired
	InspectionService inspectionService;
	@Autowired
	private ScriptService scriptService;
	@Autowired
	private DocumentService documentService;
	@Autowired
	private AgendaService agendaService;
	@Autowired
	protected MessageService messageService;
	@Autowired
	protected SelfAssessmentItemsService selfAssessmentItemsService;

	private Inspection inspection;

	private List<SelectItem> countriesItems = null;
	private List<SelectItem> ports = null;
	private List<SelectItem> inspectionCompanies = null;
	private Long countryId;
	private Long portId;

	private List<SelectItem> vesselCondition = null;

	private List<SelectItem> deficiencyItems = null;
	private Long selectedDeficiencyType = null;
	private Deficiency deficienciesToModify;

	private List<SelectItem> deficiecyCodes = null;

	private List<FileInfo> currentAttachementFile;
	private List<String> currentAttachementFilePath;
	private List<FileInfo> currentAttachementFileDeficiencies;
	private List<String> currentAttachementFileDeficienciesPath;
	private List<SelectItem> areas = null;
	private List<SelectItem> subareas = null;
	private String[] subareasStructural = { "ENGINE", "DECK", "CARGO", "BRIDGE", "OTHER" };
	private String[] subareasMaintenance = { "ENGINE", "DECK", "CARGO", "SAFETY", "BRIDGE", "OTHER" };
	private String[] subareasHuman = { "ENGINE", "NAVIGATION", "DECK", "CARGO", "SAFETY", "CREW", "PROCEDURE",
			"MANAGEMENT", "OFFICER", "DRILL", "OTHER" };
	private String[] subareasManagement = { "ENGINE", "NAVIGATION", "DECK", "CARGO", "SAFETY", "CREW", "PROCEDURE",
			"CERTIFICATION", "DRILL", "OTHER" };
	private String[] subareasSecurity = { "ENGINE", "NAVIGATION", "DECK", "CARGO", "SAFETY", "CREW", "PROCEDURE",
			"CERTIFICATION", "OTHER" };
	private List<SelectItem> rootCauses = null;
	private String[] rootCausesStructural = { "IMPROPER MAINTENANCE", "SHIP BUILDING", "DEFECTIVE EQUIPMENT", "OTHER" };
	private String[] rootCausesMaintenance = { "REDUCED TIME", "CREW", "TECHNICAL", "PENDING REQUISITIONS", "OTHER" };
	private String[] rootCausesHuman = { "INEXPERIENCE", "Inattention", "Drugs-Alcohol", "Lack of Training",
			"Complacency", "Improper Equipment Use", "Forgetfulness", "FATIGUE", "OTHER" };
	private String[] rootCausesManagement = { "Communications", "Company Policy", "Insufficient Personnel",
			"Procedural Error", "Unspecified/Other", "Lack of supervision", "instructions not clear or enforced",
			"OTHER" };
	private String[] rootCausesGalley = { "IMPROPER FOOD EADLING", "DEFECTIVE EQUIPEMENT", "OTHER" };
	private String[] rootCausesBridge = { "DEFECTIVE EQUIPEMENT", "IMPROPER USAGE", "OTHER" };

	private List<SelectItem> potentialRisks = null;
	private List<SelectItem> contributingFactors = null;

	private List<SelectItem> operationCheck1Items = null;
	private List<SelectItem> operationCheck2Items = null;
	private List<SelectItem> immediateCauses = null;
	private List<SelectItem> rootCausesTwo = null;
	protected boolean inizializzato = false;

	public String newInspection() {
		inizializzato = false;
		initCustomModel();
		return "new_vetting_inspection";
	}

	public String editInspection() {
		String inspectionId = FacesUtils.getRequestParameter("inspectionId");
		log.info("Edit inspection - inspectionId: " + inspectionId);

		try {
			inspection = inspectionService.getInspection(Long.parseLong(inspectionId));
			List<Deficiency> deficiencies = inspection.getDeficiencies(); // serves to initialize deficiencies from db
			for (Deficiency def : deficiencies) { // serves to initialize deficiencies from db
				log.info(def.getId().toString());
			}
			if (inspection != null) {
				if (inspection.getCountry() != null) {
					countryId = inspection.getCountry().getId();
					populatePorts(countryId);
				} else {
					ports = new ArrayList<SelectItem>();
				}
				if (inspection.getPort() != null)
					portId = inspection.getPort().getId();

				// Allegati
				currentAttachementFile.clear();
				currentAttachementFilePath.clear();
				currentAttachementFile.add(null);
				currentAttachementFilePath.add(null);

				for (String at : inspection.getAttachments()) {
					try {
						currentAttachementFile.add(0, null);
						currentAttachementFilePath.add(0, at);

//						BaseResource br = new BaseResource();
//						br.setAttachement(true);
//						//br.setFileName(at);
//						br.setFileName(at.substring(at.lastIndexOf("\\")+1));
//						//br.setMimeType(mimeType);
//						Resource r = new ByteArrayResource(FileUtils.getBytesFromFile(PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")+File.separator+at));
//						br.setResource(r);
//						allegati.add(br);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		} catch (DocumentException e) {
			e.printStackTrace();
			inspection = null;
		}
		inizializzato = true;
		return "new_vetting_inspection";
	}

	public String updateInspection() {
		String inspectionId = FacesUtils.getRequestParameter("inspectionId");
		log.info("Update - inspectionId: " + inspectionId);
		Long inspId = Long.parseLong(inspectionId);

		try {
			// imposto syncroWithRemote a false in modo da renderlo modificabile
			inspection = inspectionService.getInspection(inspId);
			inspection.setSynchronizedWithRemote(false);
			inspection = inspectionService.update(inspection);

			inspection = inspectionService.getInspection(Long.parseLong(inspectionId));
			List<Deficiency> deficiencies = inspection.getDeficiencies(); // serves to initialize deficiencies from db
			for (Deficiency def : deficiencies) { // serves to initialize deficiencies from db
				log.info(def.getId().toString());
			}
			if (inspection != null) {
				if (inspection.getCountry() != null) {
					countryId = inspection.getCountry().getId();
					populatePorts(countryId);
				} else {
					ports = new ArrayList<SelectItem>();
				}
				if (inspection.getPort() != null)
					portId = inspection.getPort().getId();

				// Allegati
				currentAttachementFile.clear();
				currentAttachementFilePath.clear();
				currentAttachementFile.add(null);
				currentAttachementFilePath.add(null);

				for (String at : inspection.getAttachments()) {
					try {
						currentAttachementFile.add(0, null);
						currentAttachementFilePath.add(0, at);

					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		} catch (DocumentException e) {
			e.printStackTrace();
			inspection = null;
		}

		inizializzato = true;
		return "new_vetting_inspection";
	}

	private void populatePorts(Long countryId) {
		ports.clear();
		List<Port> cs = genericLookupService.getCountryPort(countryId);
		ports.add(new SelectItem(new Long(0), ""));
		for (Port c : cs) {
			SelectItem item = new SelectItem(c.getId(), c.getName());
			ports.add(item);
		}
	}

	@PostConstruct
	public void initCustomModel() {
		log.info("INIT PscBean");

		if (!inizializzato) {
			ports = new ArrayList<SelectItem>();
			inspectionCompanies = new ArrayList<SelectItem>();
			inspectionCompanies.add(new SelectItem(null, ""));
			inspectionCompanies.add(new SelectItem("OCIMF", "OCIMF"));
			inspectionCompanies.add(new SelectItem("CDI", "CDI"));
			inspectionCompanies.add(new SelectItem("CHARTERER/TERMINAL", "CHARTERER/TERMINAL"));

			vesselCondition = new ArrayList<SelectItem>();
			vesselCondition.add(new SelectItem(null, ""));
			vesselCondition.add(new SelectItem("Loading", "Loading"));
			vesselCondition.add(new SelectItem("Discharging", "Discharging"));
			vesselCondition.add(new SelectItem("STS/Load", "STS/Load"));
			vesselCondition.add(new SelectItem("STS/Disch", "STS/Disch"));
			vesselCondition.add(new SelectItem("NoOperations", "NoOperations"));

			inspection = new Inspection();

			String selfAssessmentItemsType = "SHIP";
			if (((NavigationBean) FacesUtils.getManagedBean("navigationBean")).getIsIstanzaNaveUfficio())
				selfAssessmentItemsType = "SHIP-OFFICE";

			deficiencyItems = new ArrayList<SelectItem>();
//			List<SelfAssessmentItem>  allItems = selfAssessmentItemsService.getAllItems();
			List<SelfAssessmentItem> allItems = selfAssessmentItemsService.getFinder().and("type")
					.eq(selfAssessmentItemsType).setDistinct().list();

			deficiencyItems.add(new SelectItem(null, ""));
			if (allItems != null) {
				for (int i = 0; i < allItems.size(); i++) {
					deficiencyItems.add(new SelectItem(allItems.get(i).getId(),
							allItems.get(i).getRef() + " - " + allItems.get(i).getTitle()));
				}
			}

			areas = new ArrayList<SelectItem>();
			areas.add(new SelectItem(null, ""));
			areas.add(new SelectItem("STRUCTURAL", "STRUCTURAL"));
			areas.add(new SelectItem("MAINTENANCE", "MAINTENANCE"));
			areas.add(new SelectItem("HUMAN", "HUMAN"));
			areas.add(new SelectItem("MANAGEMENT", "MANAGEMENT"));
			areas.add(new SelectItem("SECURITY", "SECURITY"));
			areas.add(new SelectItem("DECK", "DECK"));
			areas.add(new SelectItem("ENGINE", "ENGINE"));
			areas.add(new SelectItem("GALLEY", "GALLEY"));
			areas.add(new SelectItem("BRIDGE", "BRIDGE"));

			potentialRisks = new ArrayList<SelectItem>();
			potentialRisks.add(new SelectItem(null, ""));
			potentialRisks.add(new SelectItem("Process failure"));
			potentialRisks.add(new SelectItem("Ship damage / Owner property"));
			potentialRisks.add(new SelectItem("Environment"));
			potentialRisks.add(new SelectItem("Personnel"));
			potentialRisks.add(new SelectItem("Customer related property"));
			potentialRisks.add(new SelectItem("Health / Safety"));
			potentialRisks.add(new SelectItem("Reputation"));
			potentialRisks.add(new SelectItem("Financial Loss / Claim"));

			contributingFactors = new ArrayList<SelectItem>();
			contributingFactors.add(new SelectItem(null, ""));
			contributingFactors.add(new SelectItem("Adverse Weather and/or Sea Conditions"));
			contributingFactors.add(new SelectItem("Congested or restricted sailing condition"));
			contributingFactors.add(new SelectItem("Machinery / Equipment Breakdown or Failure"));
			contributingFactors.add(new SelectItem("Failure to Follow Rules and Regulations"));
			contributingFactors.add(new SelectItem("Failure to Secure / Rigging"));
			contributingFactors.add(new SelectItem("Failure to use PPE / Failure to use proper PPE"));
			contributingFactors.add(new SelectItem("Inadequate or defective PPE"));
			contributingFactors.add(new SelectItem("Improper Position for Task"));
			contributingFactors.add(new SelectItem("Improper Stepping, Handling or Lifting"));
			contributingFactors.add(new SelectItem("Inadequate Air Quality"));
			contributingFactors.add(new SelectItem("Inadequate Guards, Barriers or Warnings"));
			contributingFactors.add(new SelectItem("Inadequate or Excess Illumination (Insufficient lighting)"));
			contributingFactors.add(new SelectItem("Inadequate Preparation/Planning"));
			contributingFactors.add(new SelectItem("Inadequate Ship Security Measures"));
			contributingFactors.add(new SelectItem("Inappropriate Behavior (Unsuitable conduct)"));
			contributingFactors.add(new SelectItem("Incorrect Navigation or Ship Handling"));
			contributingFactors.add(new SelectItem("Incorrect Use of Equipment/Machinery or use without  competency"));
			contributingFactors.add(new SelectItem("Making Safety Devices Inoperative"));
			contributingFactors.add(new SelectItem("Outdated or Lack of Charts/Publications and/or Documents"));
			contributingFactors.add(new SelectItem("Poor Housekeeping"));
			contributingFactors.add(new SelectItem("External factors"));
			contributingFactors.add(new SelectItem("Under the Influence of Alcohol/Drugs/Medication"));
			contributingFactors.add(new SelectItem("Using Defective Tool(s)"));

			subareas = new ArrayList<SelectItem>();
			rootCauses = new ArrayList<SelectItem>();
			rootCauses.add(new SelectItem(null, ""));
			rootCauses.add(new SelectItem("N/A"));
			rootCauses.add(new SelectItem("2.1.1. - Inadequate Physical/Physiological Capability"));
			rootCauses.add(new SelectItem("2.1.2. - Inadequate Mental/Psychological Capability"));
			rootCauses.add(new SelectItem("2.1.3. - Physical/Physiological Stress"));
			rootCauses.add(new SelectItem("2.1.4. - Mental/Psychological Stress"));
			rootCauses.add(new SelectItem("2.1.5. - Lack of Competence"));
			rootCauses.add(new SelectItem("2.1.6. - Improper Motivation"));
			rootCauses.add(new SelectItem("2.2.1. - Unclear Organizational Structure"));
			rootCauses.add(new SelectItem("2.2.2. - Inadequate Leadership"));
			rootCauses.add(new SelectItem("2.2.3. - Inadequate Supervision/Coaching"));
			rootCauses.add(new SelectItem("2.2.4. - Inadequate Management of Change"));
			rootCauses.add(new SelectItem("2.2.5. - Inadequate Supply Chain Management"));
			rootCauses.add(new SelectItem("2.2.6. - Inadequate Maintenance/Inspection"));
			rootCauses.add(new SelectItem("2.2.7. - Excessive Wear/Tear"));
			rootCauses.add(new SelectItem("2.2.8. - Inadequate Tool/Equipment/Machinery/Device"));
			rootCauses.add(new SelectItem("2.2.9. - Inadequate Product/Service Design"));
			rootCauses.add(new SelectItem("2.2.10. - Inadequate Work/Production Standards"));
			rootCauses.add(new SelectItem("2.2.11. - Inadequate Communication/Information"));

//			rootCauses.add(new SelectItem("Inexperience"));
//			rootCauses.add(new SelectItem("Inattention"));
//			rootCauses.add(new SelectItem("Error in evaluation"));
//			rootCauses.add(new SelectItem("Weather condition"));
//			rootCauses.add(new SelectItem("Poor planning"));
//			rootCauses.add(new SelectItem("Incorrect use of equipment"));
//			rootCauses.add(new SelectItem("Incorrect use of safety equipment"));
//			rootCauses.add(new SelectItem("Missing procedures"));
//			rootCauses.add(new SelectItem("Equipment failure"));
//			rootCauses.add(new SelectItem("Insufficient training"));
//			rootCauses.add(new SelectItem("Not relevant"));
//			rootCauses.add(new SelectItem("Lack of rest"));
//			rootCauses.add(new SelectItem("Poor communication"));
//			rootCauses.add(new SelectItem("Language misunderstanding"));
//			rootCauses.add(new SelectItem("Negligence"));
//			rootCauses.add(new SelectItem("Failure to check or maintain equipment"));
//			rootCauses.add(new SelectItem("lack of safety precautions"));
//			rootCauses.add(new SelectItem("Excessive speed"));
//			rootCauses.add(new SelectItem("Alcohol or drugs intake"));
//			rootCauses.add(new SelectItem("Work under stress"));
//			rootCauses.add(new SelectItem("Capability"));
//			rootCauses.add(new SelectItem("lack of information"));
//			rootCauses.add(new SelectItem("loss of alertness"));
//			rootCauses.add(new SelectItem("Complacency"));
//			rootCauses.add(new SelectItem("Insufficient Personnel"));
//			rootCauses.add(new SelectItem("Human error"));
//			rootCauses.add(new SelectItem("Other"));
//			rootCauses.add(new SelectItem("Inadequate Design / Material / Installation"));
//			rootCauses.add(new SelectItem("Inadequate Leadership"));
//			rootCauses.add(new SelectItem("Lack of Supervision"));
//			rootCauses.add(new SelectItem("Inadequate Maintenance or Repair Instructions / Schedule"));
//			rootCauses.add(new SelectItem("Inadequate Maintenance or Repair Carried Out"));
//			rootCauses.add(new SelectItem("Lack in spares receiving"));
//			rootCauses.add(new SelectItem("Inadequate tools"));
//			rootCauses.add(new SelectItem("Inadequate procedures appliance (excluding maintenance)"));
//			rootCauses.add(new SelectItem("Lack of Knowledge or Skill"));
//			rootCauses.add(new SelectItem("Inadequate training"));
//			rootCauses.add(new SelectItem("Lack of familiarization"));
//			rootCauses.add(new SelectItem("Physical Capability / Health Factors"));
//			rootCauses.add(new SelectItem("Inadequate rest  / Stress"));
//			rootCauses.add(new SelectItem("Inadequate Management of Change"));
//			rootCauses.add(new SelectItem("Wear & Tear"));
//			rootCauses.add(new SelectItem("Human Error"));
//			rootCauses.add(new SelectItem("Fatigue / Human Failure / Work overcharge"));

			operationCheck1Items = new ArrayList<SelectItem>();
			operationCheck1Items.add(new SelectItem("Abbandon Ship", "Abbandon Ship"));
			operationCheck1Items.add(new SelectItem("Fire Drill", "Fire Drill"));
			operationCheck1Items.add(new SelectItem("Em'cy Fire Pump", "Em'cy Fire Pump"));
			operationCheck1Items.add(new SelectItem("Em'cy Steering", "Em'cy Steering"));
			operationCheck1Items.add(new SelectItem("Lifeboat Engine", "Lifeboat Engine"));
			operationCheck1Items.add(new SelectItem("Inert Gas System", "Inert Gas System"));
			operationCheck1Items.add(new SelectItem("Emergency Generator", "Emergency Generator"));
			operationCheck1Items.add(new SelectItem("Oily Water Separator", "Oily Water Separator"));
			operationCheck1Items.add(new SelectItem("Engine Room  Vent Shut Down", "Engine Room  Vent Shut Down"));
			operationCheck1Items.add(new SelectItem("Communication eq.", "Communication eq."));
			operationCheck1Items.add(new SelectItem("Damage control", "Damage control"));
			operationCheck1Items.add(new SelectItem("Other", "Other"));

			operationCheck2Items = new ArrayList<SelectItem>();
			operationCheck2Items.add(new SelectItem("Fireman Outfit", "Fireman Outfit"));
			operationCheck2Items
					.add(new SelectItem("International ship/Shore Connection", "International ship/Shore Connection"));
			operationCheck2Items.add(new SelectItem("Paint loker smothering system", "Paint loker smothering system"));
			operationCheck2Items.add(new SelectItem("Navigation equipment", "Navigation equipment"));
			operationCheck2Items.add(new SelectItem("EPIRB, Pyrothecnic and hydrostatic realeases",
					"EPIRB, Pyrothecnic and hydrostatic realeases"));
			operationCheck2Items.add(new SelectItem("Marine sanitation device", "Marine sanitation device"));
			operationCheck2Items
					.add(new SelectItem("Chart Publications and Corrections", "Chart Publications and Corrections"));
			operationCheck2Items.add(new SelectItem("Flame screens on Bunker and water Ballast Tanks",
					"Flame screens on Bunker and water Ballast Tanks"));
			operationCheck2Items.add(new SelectItem("Other", "Other"));

			deficiecyCodes = new ArrayList<SelectItem>();
			deficiecyCodes.add(new SelectItem("0117", "0117 safety management certificate(SMC/ISM Code)"));
			deficiecyCodes.add(new SelectItem("0120", "0120 load lines (including exemption)"));
			deficiecyCodes.add(new SelectItem("0130", "0130 liquefied gases in bulk (CoF/GC Code)"));
			deficiecyCodes.add(new SelectItem("0131", "0131 liquefied gases in bulk (CoF/GC Code)"));
			deficiecyCodes.add(new SelectItem("0135", "0135 safe manning document"));
			deficiecyCodes.add(new SelectItem("0140", "0140 dangerous chemical in bulk (CoF/BC Code)"));
			deficiecyCodes.add(new SelectItem("0141", "0141 dangerous chemical in bulk (CoF/IBC Code)"));
			deficiecyCodes.add(new SelectItem("0150", "0150 prevention of pollution By oil (IOPP)"));
			deficiecyCodes.add(new SelectItem("0155", "0155 pollution prevention noxious liquid substances in bulk"));
			deficiecyCodes.add(new SelectItem("0170", "0170 document of compliance dangerous goods"));
			deficiecyCodes.add(new SelectItem("0171", "0171 document of compliance dangerous goods"));
			deficiecyCodes.add(new SelectItem("0172", "0172 high speed craft"));
			deficiecyCodes.add(new SelectItem("0173", "0173 mobile offshore drilling unit safety"));
			deficiecyCodes.add(new SelectItem("0180", "0180 tonnage certificate"));
			deficiecyCodes.add(new SelectItem("0190", "0190 logbooks/compulsory entries"));
			deficiecyCodes.add(new SelectItem("0197", "0197 ISM certification in general"));
			deficiecyCodes.add(new SelectItem("0199", "0199 other (certificates)"));
			immediateCauses = new ArrayList<SelectItem>();
			immediateCauses.add(new SelectItem("None"));
			immediateCauses.add(new SelectItem("01.01 - Drugs/Alcohol intoxication"));
			immediateCauses.add(new SelectItem("01.02 - Failure to follow Rules or Regulations"));
			immediateCauses.add(new SelectItem("01.03 - Failure to secure"));
			immediateCauses.add(new SelectItem("01.04 - Failure to use proper personal protective equipment"));
			immediateCauses.add(new SelectItem("01.05 - Failure to warn"));
			immediateCauses.add(new SelectItem("01.06 - Horseplay"));
			immediateCauses.add(new SelectItem("01.07 - Improper lifting"));
			immediateCauses.add(new SelectItem("01.08 - Improper loading"));
			immediateCauses.add(new SelectItem("01.09 - Improper placement"));
			immediateCauses.add(new SelectItem("01.10 - Improper position for task"));
			immediateCauses.add(new SelectItem("01.11 - Incorrect navigation or ship handling"));
			immediateCauses.add(new SelectItem("01.12 - Making safety devices inoperable"));
			immediateCauses.add(new SelectItem("01.13 - Operating at improper speed"));
			immediateCauses.add(new SelectItem("01.14 - Operating equipment without authority"));
			immediateCauses.add(new SelectItem("01.15 - Removing safety devices"));
			immediateCauses.add(new SelectItem("01.16 - Sabotage, wilful damage"));
			immediateCauses.add(new SelectItem("01.17 - Servicing equipment in operation"));
			immediateCauses.add(new SelectItem("01.18 - Using defective equipment"));
			immediateCauses.add(new SelectItem("01.19 - Using equipment improperly"));
			immediateCauses.add(new SelectItem("02.01 - Pilots"));
			immediateCauses.add(new SelectItem("02.02 - Berthing crew"));
			immediateCauses.add(new SelectItem("02.03 - Terminal personnel"));
			immediateCauses.add(new SelectItem("02.04 - Local authorities"));
			immediateCauses
					.add(new SelectItem("02.05 - Other people not under control of the company/shipboard management"));
			immediateCauses.add(new SelectItem("03.01 - Cargo"));
			immediateCauses.add(new SelectItem("03.02 - Congestion or restricted action"));
			immediateCauses.add(new SelectItem("03.03 - Dangerous atmosphere hazards"));
			immediateCauses.add(new SelectItem("03.04 - Defective tools, equipment or materials"));
			immediateCauses.add(new SelectItem("03.05 - Electric current hazards"));
			immediateCauses.add(new SelectItem("03.06 - Exposure to chemicals"));
			immediateCauses.add(new SelectItem("03.07 - Exposure to high temperature"));
			immediateCauses.add(new SelectItem("03.08 - Exposure to low temperature"));
			immediateCauses.add(new SelectItem("03.09 - Exposure to noise"));
			immediateCauses.add(new SelectItem("03.10 - Exposure to radiation"));
			immediateCauses.add(new SelectItem("03.11 - Fire or explosion hazards"));
			immediateCauses.add(new SelectItem("03.12 - Inadequate guards or barriers"));
			immediateCauses.add(new SelectItem("03.13 - Inadequate or excessive illumination"));
			immediateCauses.add(new SelectItem("03.14 - Inadequate or improper protective equipment"));
			immediateCauses.add(new SelectItem("03.15 - Inadequate ventilation"));
			immediateCauses.add(new SelectItem("03.16 - Inadequate warning systems"));
			immediateCauses.add(new SelectItem("03.17 - Incorrect/inadequate tools, equipment or materials"));
			immediateCauses.add(new SelectItem("03.18 - Other excessive exposures"));
			immediateCauses.add(new SelectItem("03.19 - Outdated charts, publications and other documentation"));
			immediateCauses.add(new SelectItem("03.20 - Poor housekeeping, disorder"));
			immediateCauses.add(new SelectItem("03.21 - Wet/slippery surface"));
			immediateCauses.add(new SelectItem("04.01 - Adverse weather conditions"));
			immediateCauses.add(new SelectItem("04.02 - Adverse sea conditions"));
			immediateCauses.add(new SelectItem("04.03 - Inadequate port and berthing facilities"));

			rootCausesTwo = new ArrayList<SelectItem>();
			rootCausesTwo.add(new SelectItem("None"));
			rootCausesTwo.add(new SelectItem("01.01 - Inadequate height/weight/size/strength/reach, etc."));
			rootCausesTwo.add(new SelectItem("01.02 - Restricted range of body movement"));
			rootCausesTwo.add(new SelectItem("01.03 - Limited ability/inability to sustain body positions"));
			rootCausesTwo.add(new SelectItem("01.04 - Substance sensitivity/allergy"));
			rootCausesTwo.add(new SelectItem("01.05 - Sensitivities to sensory extreme (temperature/sound/etc.)"));
			rootCausesTwo.add(new SelectItem("01.06 - Vision deficiency"));
			rootCausesTwo.add(new SelectItem("01.07 - Hearing deficiency"));
			rootCausesTwo.add(new SelectItem("01.08 - Other sensory deficiency (touch/taste/smell/balance)"));
			rootCausesTwo.add(new SelectItem("01.09 - Respiratory incapacity"));
			rootCausesTwo.add(new SelectItem("01.10 - Other permanent physical disability"));
			rootCausesTwo.add(new SelectItem("01.11 - Temporary disability"));
			rootCausesTwo.add(new SelectItem("02.01 - Fears and phobisa"));
			rootCausesTwo.add(new SelectItem("02.02 - Emotionla disturbance"));
			rootCausesTwo.add(new SelectItem("02.03 - Mental illness"));
			rootCausesTwo.add(new SelectItem("02.04 - Intelligence level"));
			rootCausesTwo.add(new SelectItem("02.05 - Inability to comprehend"));
			rootCausesTwo.add(new SelectItem("02.06 - Poor coordination"));
			rootCausesTwo.add(new SelectItem("02.07 - Slow reaction time"));
			rootCausesTwo.add(new SelectItem("02.08 - Low mechanical aptitude"));
			rootCausesTwo.add(new SelectItem("02.09 - Low learning aptitude"));
			rootCausesTwo.add(new SelectItem("02.10 - Memory failure/lapse"));
			rootCausesTwo.add(new SelectItem("03.01 - Injury or illness"));
			rootCausesTwo.add(new SelectItem("03.02 - Fatigue due to task load or duration"));
			rootCausesTwo.add(new SelectItem("03.03 - Fatigue due to lack of rest"));
			rootCausesTwo.add(new SelectItem("03.04 - Fatigue due to sensory overload"));
			rootCausesTwo.add(new SelectItem("03.05 - Exposure to health hazard"));
			rootCausesTwo.add(new SelectItem("03.06 - Exposure to extreme temperature"));
			rootCausesTwo.add(new SelectItem("03.07 - Oxygen deficiency"));
			rootCausesTwo.add(new SelectItem("03.08 - Atmospheric pressure variation"));
			rootCausesTwo.add(new SelectItem("03.09 - Constrained movement"));
			rootCausesTwo.add(new SelectItem("03.10 - Blood sugar insufficiency"));
			rootCausesTwo.add(new SelectItem("03.11 - Alcohol/Drugs/Other Self Imposed Stress"));
			rootCausesTwo.add(new SelectItem("04.01 - Emotional overload"));
			rootCausesTwo.add(new SelectItem("04.02 - Fatigue due to mental task load or speed"));
			rootCausesTwo.add(new SelectItem("04.03 - Extreme judgment/decision demands"));
			rootCausesTwo.add(new SelectItem("04.04 - Routine/monotony demand for uneventful vigilance"));
			rootCausesTwo.add(new SelectItem("04.05 - Extreme concentration/perception demands"));
			rootCausesTwo.add(new SelectItem("04.06 - Meaningless/degrading activities"));
			rootCausesTwo.add(new SelectItem("04.07 - Confusing directions/demands"));
			rootCausesTwo.add(new SelectItem("04.08 - Conflicting demands/directions"));
			rootCausesTwo.add(new SelectItem("04.09 - Preoccupation with problems/Distractions by concern"));
			rootCausesTwo.add(new SelectItem("04.10 - Frustration"));
			rootCausesTwo.add(new SelectItem("04.11 - Mental illness"));
			rootCausesTwo.add(new SelectItem("05.01 - Inadequate experience"));
			rootCausesTwo.add(new SelectItem("05.02 - Inadequate orientation"));
			rootCausesTwo.add(new SelectItem("05.03 - Inadequate initial training"));
			rootCausesTwo.add(new SelectItem("05.04 - Inadequate update/refresher training"));
			rootCausesTwo.add(new SelectItem("05.05 - Misunderstood instruction/information"));
			rootCausesTwo.add(new SelectItem("05.06 - Lack of situational awareness/risk perception/risk awareness"));
			rootCausesTwo.add(new SelectItem("06.01 - Inadequate initial instruction/skill training"));
			rootCausesTwo.add(new SelectItem("06.02 - Inadequate practice"));
			rootCausesTwo.add(new SelectItem("06.03 - Inadequate performance"));
			rootCausesTwo.add(new SelectItem("06.04 - Inadequate coaching"));
			rootCausesTwo.add(new SelectItem("06.05 - Inadequate review instruction"));
			rootCausesTwo.add(new SelectItem("07.01 - Improper performance/behaviour is tolerated/rewarded"));
			rootCausesTwo.add(new SelectItem("07.02 - Proper performance/behaviour is discouraged/punished"));
			rootCausesTwo.add(new SelectItem("07.03 - Lack of incentive"));
			rootCausesTwo.add(new SelectItem("07.04 - Improper production incentive"));
			rootCausesTwo.add(new SelectItem("07.05 - Excessive frustration"));
			rootCausesTwo.add(new SelectItem("07.06 - Inappropriate aggression"));
			rootCausesTwo.add(new SelectItem("07.07 - Improper attempt to safe time/effort"));
			rootCausesTwo.add(new SelectItem("07.08 - Improper attempt to gain attention"));
			rootCausesTwo.add(new SelectItem("07.09 - Inadequate discipline"));
			rootCausesTwo.add(new SelectItem("07.10 - Inappropriate peer pressure"));
			rootCausesTwo.add(new SelectItem("07.11 - Improper leadership example"));
			rootCausesTwo.add(new SelectItem("07.12 - Inadequate performance feedback"));
			rootCausesTwo.add(new SelectItem("07.13 - Inadequate reinforcement of proper behaviour"));
			rootCausesTwo.add(new SelectItem("07.14 - Abuse (intentionally)"));
			rootCausesTwo.add(new SelectItem("07.15 - Misuse (unintentionally)"));
			rootCausesTwo.add(new SelectItem("08.01 - Unclear/conflicting reporting relationship"));
			rootCausesTwo.add(new SelectItem("08.02 - Unclear/conflicting assignment of function/role"));
			rootCausesTwo.add(new SelectItem("08.03 - Unclear/conflicting accountability/responsibility/task"));
			rootCausesTwo.add(new SelectItem("09.01 - Inadequate HSEO/asset strategy"));
			rootCausesTwo.add(new SelectItem("09.02 - Inadequate leadership development"));
			rootCausesTwo.add(new SelectItem("09.03 - Inadequate delegation"));
			rootCausesTwo.add(new SelectItem("09.04 - Inadequate standards"));
			rootCausesTwo.add(
					new SelectItem("09.05 - Inadequate communication/implementation of policy/procedure/practice"));
			rootCausesTwo.add(new SelectItem("09.06 - Conflicting policy/procedure/practice"));
			rootCausesTwo.add(new SelectItem("09.07 - Inadequate work/process planning/programming"));
			rootCausesTwo.add(new SelectItem("09.08 - Condone deviation form policy/procedure/practice"));
			rootCausesTwo.add(new SelectItem("09.09 - Condone misuse of equipment/tool"));
			rootCausesTwo.add(new SelectItem("09.10 - Condone improper/inappriorate behaviour"));
			rootCausesTwo.add(new SelectItem("09.11 - Inadequate management information"));
			rootCausesTwo.add(new SelectItem("10.01 - Inadequate instruction/orientation/training"));
			rootCausesTwo.add(new SelectItem("10.02 - Inadequate information document in supervision/coaching"));
			rootCausesTwo.add(new SelectItem("10.03 - Lack of supervisory/management job knowledge"));
			rootCausesTwo
					.add(new SelectItem("10.04 - Inadequate match between qualifications and job/task requirements"));
			rootCausesTwo.add(new SelectItem("10.05 - Inadequate performance measurement and evaluation"));
			rootCausesTwo.add(new SelectItem("10.06 - Inadequate performance feedback"));
			rootCausesTwo
					.add(new SelectItem("11.01 - Inadequate HSEO hazard identification/risk evaluation in design"));
			rootCausesTwo.add(new SelectItem("11.02 - Inadequate identification of failure mode"));
			rootCausesTwo.add(new SelectItem("11.03 - Inadequate evaluation of customer/stakeholder requirement"));
			rootCausesTwo.add(new SelectItem("11.04 - Inadequate identification of legal requirement"));
			rootCausesTwo.add(new SelectItem("11.05 - Inadequate consideration of human/ergonomic factor in design"));
			rootCausesTwo.add(new SelectItem("11.06 - Inadequate design process/standard/specifications/criteria"));
			rootCausesTwo.add(new SelectItem("11.07 - Inadequate process control automation"));
			rootCausesTwo
					.add(new SelectItem("11.08 - Inadequate (technical) standard/specification or absence thereof"));
			rootCausesTwo.add(new SelectItem("11.09 - Inadequate project HSEO review"));
			rootCausesTwo.add(new SelectItem("11.10 - Inadequate monitoring of construction/fabrication/assembly"));
			rootCausesTwo.add(new SelectItem("11.11 - Inadequate assessment of operational readiness"));
			rootCausesTwo.add(new SelectItem("11.12 - Inadequate commissioning/handover process"));
			rootCausesTwo.add(new SelectItem("11.13 - Inadequate monitoring of initial operation"));
			rootCausesTwo.add(new SelectItem("11.14 - Inadequate management of change"));
			rootCausesTwo.add(new SelectItem("12.01 - Inadequate specifications on requisitions/purchase order"));
			rootCausesTwo.add(new SelectItem("12.02 - Inadequate research on material/equipment/tool/supply/etc"));
			rootCausesTwo.add(new SelectItem("12.03 - Inadequate specification to vendor"));
			rootCausesTwo.add(new SelectItem("12.04 - Inadequate mode/route of shipment"));
			rootCausesTwo.add(new SelectItem("12.05 - Inadequate receiving inspection/acceptance"));
			rootCausesTwo.add(new SelectItem("12.06 - Inadequate communication of safety and health data"));
			rootCausesTwo.add(new SelectItem("12.07 - Improper handling of material"));
			rootCausesTwo.add(new SelectItem("12.08 - Improper storage of material"));
			rootCausesTwo.add(new SelectItem("12.09 - Improper transporting of material"));
			rootCausesTwo
					.add(new SelectItem("12.10 - Inadequate shelf life/validation of re-use of materials/equipment"));
			rootCausesTwo.add(new SelectItem("12.11 - Inadequate identification of material"));
			rootCausesTwo.add(new SelectItem("12.12 - Inadequate salvage/waste disposal"));
			rootCausesTwo.add(new SelectItem("12.13 - Inadequate selection of contractor/supplier"));
			rootCausesTwo.add(new SelectItem("13.01 - Inadequate assessment of preventive maintenance needs"));
			rootCausesTwo.add(new SelectItem("13.02 - Inadequate preventive lubrication and servicing"));
			rootCausesTwo.add(new SelectItem("13.03 - Inadequate adjustment/assembly"));
			rootCausesTwo.add(new SelectItem("13.04 - Inadequate preventive cleaning/resurfacing"));
			rootCausesTwo.add(new SelectItem("13.05 - Inadequate communication of corrective maintenance needs"));
			rootCausesTwo.add(new SelectItem("13.06 - Inadequate scheduling of maintenance work"));
			rootCausesTwo.add(new SelectItem("13.07 - Inadequate assessment of repair needs"));
			rootCausesTwo.add(new SelectItem("13.08 - Inadequate parts substitution/replacements"));
			rootCausesTwo.add(new SelectItem("13.09 - Inadequate inspection method/interval"));
			rootCausesTwo.add(new SelectItem("13.10 - Unable to inspect"));
			rootCausesTwo.add(new SelectItem("14.01 - Inadequate planning of use"));
			rootCausesTwo.add(new SelectItem("14.02 - Improper decision of extension of service life"));
			rootCausesTwo.add(new SelectItem("14.03 - Inadequate inspection/monitoring"));
			rootCausesTwo.add(new SelectItem("14.04 - Improper loading/rate of use"));
			rootCausesTwo.add(new SelectItem("14.05 - Used for wrong purpose/task/activity"));
			rootCausesTwo.add(new SelectItem("15.01 - Inadequate assessment of needs and risks"));
			rootCausesTwo.add(new SelectItem("15.02 - Inadequate human factors/ergonomics considerations"));
			rootCausesTwo.add(new SelectItem("15.03 - Inadequate (supplier) standards/specifications"));
			rootCausesTwo.add(new SelectItem("15.04 - Incorrect measurement/detection/(process) control"));
			rootCausesTwo.add(new SelectItem("15.05 - Inadequate availability of tool/equipment/machinery/device"));
			rootCausesTwo.add(new SelectItem("15.06 - Inadequate inspection/repair/maintenance"));
			rootCausesTwo.add(new SelectItem("15.07 - Inadequate adjustment/calibration"));
			rootCausesTwo.add(new SelectItem("15.08 - Inadequate salvage and reclamation"));
			rootCausesTwo.add(new SelectItem("15.09 - Inadequate removal and replacement of unsuitable items"));
			rootCausesTwo.add(new SelectItem("16.01 - Inadequate assessment of needs and risks"));
			rootCausesTwo.add(new SelectItem("16.02 - Inadequate product standard/specification/waiver system"));
			rootCausesTwo.add(new SelectItem("16.03 - Inadequate product design/development"));
			rootCausesTwo.add(new SelectItem("16.04 - Inadequate product standard/specification/waiver system"));
			rootCausesTwo.add(new SelectItem("16.05 - Inadequate product design validation"));
			rootCausesTwo.add(new SelectItem("16.06 - Inadequate product design verification"));
			rootCausesTwo.add(new SelectItem("16.07 - Inadequate product planning"));
			rootCausesTwo.add(new SelectItem("16.08 - Inadequate product quality verification prior to shipment"));
			rootCausesTwo.add(new SelectItem(
					"17.01 - Inadequate identification of requirements (regulatory/industry code/permit-to-operate)"));
			rootCausesTwo.add(
					new SelectItem("17.02 - Inadequate risk identification/eveluation in development of standard"));
			rootCausesTwo.add(new SelectItem("17.03 - Inadequate standard from supplier /contractor"));
			rootCausesTwo.add(
					new SelectItem("17.04 - Inadequate coordination with process design when developing standard"));
			rootCausesTwo.add(new SelectItem("17.05 - Inadequate employee involvement in developing standard"));
			rootCausesTwo.add(new SelectItem("17.06 - Conflicting standards,/improper priorization of standards"));
			rootCausesTwo.add(new SelectItem("17.07 - Inadequate publication of standard"));
			rootCausesTwo.add(new SelectItem("17.08 - Inadequate distribution of standard"));
			rootCausesTwo.add(new SelectItem("17.09 - Inadequate translation of appropriate language"));
			rootCausesTwo.add(new SelectItem("17.10 - Improper use of language"));
			rootCausesTwo.add(new SelectItem("17.11 - Inadequate training of standard"));
			rootCausesTwo.add(
					new SelectItem("17.12 - Inadequate reinforcing of standard with signs, color codes and job aids"));
			rootCausesTwo.add(new SelectItem("17.13 - Inadequate monitoring of standard compliance"));
			rootCausesTwo.add(new SelectItem("18.01 - Inadequate information handling"));
			rootCausesTwo.add(new SelectItem("18.02 - Unclear information"));
			rootCausesTwo.add(new SelectItem(
					"18.03 - Inadequate transfer of information between processes/organizational units"));
			rootCausesTwo.add(new SelectItem("18.04 - Inadequate transfer of information with client/stakeholder"));
			rootCausesTwo.add(new SelectItem("18.05 - Inadequate transfer of information with authorities"));
			rootCausesTwo.add(new SelectItem(
					"18.06 - Inadequate transfer of information with suppliers/contractors/third parties"));
			rootCausesTwo.add(new SelectItem("18.07 - Inadequate communication structure"));
			rootCausesTwo.add(new SelectItem("18.08 - Inadequate databases/information system"));
			rootCausesTwo.add(new SelectItem("18.09 - Inadequate communication method/technique used"));

			countryId = null;
			portId = null;

			currentAttachementFile = new ArrayList<FileInfo>();
			currentAttachementFile.add(null);
			currentAttachementFilePath = new ArrayList<String>();
			currentAttachementFilePath.add(null);

			currentAttachementFileDeficiencies = new ArrayList<FileInfo>();
			currentAttachementFileDeficiencies.add(null);
			currentAttachementFileDeficienciesPath = new ArrayList<String>();
			currentAttachementFileDeficienciesPath.add(null);
			inizializzato = true;
		}
	}

	public boolean getRequisitionEnebled() {

		boolean req = false;

//		log.info("Requisition Enabled: " + PropertiesUtils.getInstance().readProperty("requisition.enabled"));
//		log.info("Requisition Enabled diverso da null: " +  PropertiesUtils.getInstance().readProperty("requisition.enabled")!=null);

		if (PropertiesUtils.getInstance().readProperty("requisition.enabled") != null
				&& PropertiesUtils.getInstance().readProperty("requisition.enabled").toString().equals("true"))
			req = true;

		return req;
	}

	public String chapterDescription;

	public void populateChapterDescription(ValueChangeEvent event) {
		if (event.getNewValue() != null)
			selectedDeficiencyType = (Long) event.getNewValue();
		else
			selectedDeficiencyType = null;
		log.info("!!!populateChapterDescription defTypeid:" + selectedDeficiencyType);
		if (selectedDeficiencyType != null) {
			SelfAssessmentItem ite = selfAssessmentItemsService.getItem(selectedDeficiencyType);
			chapterDescription = ite.getTitle();
			log.info("Note: " + ite.getTitle());
		} else
			chapterDescription = "";
	}

	public void addDeficiency(ActionEvent e) {
		log.info("Aggiungo una nuova deficiency di tipo: " + selectedDeficiencyType);
		if (selectedDeficiencyType != null && selectedDeficiencyType > 0) {
			Deficiency def = new Deficiency();
			def.setCode(selfAssessmentItemsService.getItem(selectedDeficiencyType).getRef());
			def.setCodeDescription(selfAssessmentItemsService.getItem(selectedDeficiencyType).getTitle());
			def.setCodeNote(selfAssessmentItemsService.getItem(selectedDeficiencyType).getNote());
			def.setReferencedEntity(inspection);
			def.setUuid(UUID.randomUUID().toString());
			def.setStatus("Open");

			FollowupAndCorrectiveAction ca = new FollowupAndCorrectiveAction();
			ca.setType("CorrectiveAction");
			ca.setUuid(UUID.randomUUID().toString());
			def.setCorrectiveAction(ca);

			// setto i flag status a open
			ca.setOpenFlag(true);
			ca.setFollowUpFlag(false);
			ca.setProposedForClosingFlag(false);
			ca.setClosedFlag(false);

			// TODO Aggiungere campo num in deficency
			// Fare la ricerca dei num relativi a quella deficenza...prendere il piu grande
			// piu uno. Se non esiste assegnargli 1.
			if (inspection.getDeficiencies() == null)
				log.info("Aggiungo la deficenza NRO 1!!");
			else
				log.info("Aggiungo la deficenza NRO  " + (inspection.getDeficiencies().size() + 1));
			if (inspection.getDeficiencies() == null)
				def.setNro((long) 1);
			else
				def.setNro((long) inspection.getDeficiencies().size() + 1);

			currentAttachementFileDeficiencies.clear();
			currentAttachementFileDeficienciesPath.clear();
			currentAttachementFileDeficiencies.add(null);
			currentAttachementFileDeficienciesPath.add(null);

			deficienciesToModify = def;
			if (inspection.getDeficiencies() == null)
				inspection.setDeficiencies(new ArrayList<Deficiency>());
			inspection.getDeficiencies().add(def);
		} else
			addWarningMessage("Please select the chapter referred to new observation!");
	}

	public void uploadAttachementActionListener(FileEntryEvent e) {

		String idComponente = ((FileEntry) e.getSource()).getId();
		log.debug(idComponente + "  ...id completo!!!!!!!!!!!!");
		idComponente = idComponente.substring(idComponente.lastIndexOf("_") + 1);

		FileEntry fe = (FileEntry) e.getComponent();
		FileEntryResults results = fe.getResults();

		for (FileInfo i : results.getFiles()) {
			if (i.isSaved()) {
				log.info("Salvato: " + i.getFileName());
				currentAttachementFile.set(Integer.parseInt(idComponente), i);
				currentAttachementFilePath.set(Integer.parseInt(idComponente),
						currentAttachementFile.get(Integer.parseInt(idComponente)).getFileName());
			} else {
				addWarningMessage("File was not saved because: "
						+ i.getStatus().getFacesMessage(FacesContext.getCurrentInstance(), fe, i).getSummary());
			}
		}

	}

	public void addNewAttachement(ActionEvent e) {
		currentAttachementFile.add(null);
		currentAttachementFilePath.add(null);
	}

	public void removeAttachement(ActionEvent e) {
		Integer rowIndex = (Integer) e.getComponent().getAttributes().get("rowIndex");
		if (rowIndex != null) {
			Path path = Paths.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
					+ File.separator + currentAttachementFilePath.get(rowIndex)));
			try {
				Files.deleteIfExists(path);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			currentAttachementFile.remove(rowIndex.intValue());
			currentAttachementFilePath.remove(rowIndex.intValue());
		}
		if (currentAttachementFile == null || currentAttachementFile.size() == 0) {
			currentAttachementFile = new ArrayList<FileInfo>();
			currentAttachementFile.add(null);
			currentAttachementFilePath.add(null);
		}
	}

	public List<SelectItem> getDeficiencyItems() {
		if (deficiencyItems != null) {
			return deficiencyItems;
		}
		String selfAssessmentItemsType = "SHIP";
		if (((NavigationBean) FacesUtils.getManagedBean("navigationBean")).getIsIstanzaNaveUfficio())
			selfAssessmentItemsType = "SHIP-OFFICE";

		deficiencyItems = new ArrayList<SelectItem>();
		List<SelfAssessmentItem> allItems = selfAssessmentItemsService.getFinder().and("type")
				.eq(selfAssessmentItemsType).setDistinct().list();

		deficiencyItems.add(new SelectItem(null, ""));
		if (allItems != null) {
			for (int i = 0; i < allItems.size(); i++) {
				deficiencyItems.add(new SelectItem(allItems.get(i).getId(),
						allItems.get(i).getRef() + " - " + allItems.get(i).getTitle()));
			}
		}
		return deficiencyItems;
	}

	public void modifyDeficiency(ActionEvent e) {
		String deficencyUuid = (String) e.getComponent().getAttributes().get("deficencyUuid");
		log.info("modifyDeficiency:" + deficencyUuid);
		if (inspection.getDeficiencies() != null && deficencyUuid != null) {
			for (Deficiency d : inspection.getDeficiencies()) {
				if (d.getUuid().equals(deficencyUuid)) {
					RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
					if (requisitionBean != null)
						requisitionBean.newRequisition();
					deficienciesToModify = d;
					currentAttachementFileDeficiencies.clear();
					currentAttachementFileDeficienciesPath.clear();
					currentAttachementFileDeficiencies.add(null);
					currentAttachementFileDeficienciesPath.add(null);
					if (deficienciesToModify.getAttachments() != null) {
						for (String at : deficienciesToModify.getAttachments()) {
							try {
								currentAttachementFileDeficiencies.add(0, null);
								currentAttachementFileDeficienciesPath.add(0, at);

							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
					}

					break;
				}
			}
		}
	}

	public void deleteDeficiency(ActionEvent e) {
//		String deficencyUuid = FacesUtils.getRequestParameter("deficencyUuid");
		String deficencyUuid = (String) e.getComponent().getAttributes().get("deficencyUuid");

		if (inspection.getDeficiencies() != null && deficencyUuid != null) {
			for (Deficiency d : inspection.getDeficiencies()) {
				if (d.getUuid().equals(deficencyUuid)) {
					inspection.getDeficiencies().remove(d);
					break;
				}
			}
		}
		deficienciesToModify = null;
	}

	private boolean requisitionEdit = false;

//	public void closeRequisition(ActionEvent e) {
//		// Assegno la requisition se compilata
//		RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
//		if (requisitionBean!=null){
//			if (requisitionBean.getIdRequisitionForSendToOffice()!=null){
//				deficienciesToModify.getCorrectiveAction().setRequisition(requisitionService.getRequisition(requisitionBean.getIdRequisitionForSendToOffice()));
//				requisitionBean.setIdRequisitionForSendToOffice(null);
//			}
//		}
//		requisitionEdit = false;
//	}
	public void openRequisition(ActionEvent e) {
		// Nuova requisition
		RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
		if (requisitionBean != null) {
			requisitionBean.newRequisition(null);
		}

		requisitionEdit = true;
	}

//	public void closeDeficiency(ActionEvent e) {
//		
//		deficienciesToModify = null;
//	}
	public void saveDeficiencies() {
		try {
			if (deficienciesToModify.getId() != null) {
				inspectionService.update(deficienciesToModify);
			}
			setDeficiencyModifyVisible(false);
		} catch (Exception e) {
		}
	}

	public boolean isDeficiencyModifyVisible() {
		return (deficienciesToModify != null);
	}

	public void setDeficiencyModifyVisible(boolean aa) {
		if (!aa) {
			try {
				if (currentAttachementFileDeficiencies != null) {
					int iii = 0;
					if (deficienciesToModify != null) {

						List<String> tempList = deficienciesToModify.getAttachments();
						if (tempList == null)
							tempList = new ArrayList<String>();
						deficienciesToModify.setAttachments(new ArrayList<String>());
						for (String filePath : currentAttachementFileDeficienciesPath) {
							if (filePath != null && !filePath.equals("")) {
								if (!tempList.contains(filePath)) {
									InputStream data = new FileInputStream(
											currentAttachementFileDeficiencies.get(iii).getFile().getAbsolutePath());
									String realname = inspectionService.storeInspectionAttachementFile(data, filePath);
									deficienciesToModify.getAttachments().add(realname);
									// Aggiorno con il path reale
									currentAttachementFileDeficienciesPath.set(iii, realname);
								} else
									deficienciesToModify.getAttachments().add(filePath);
							}
							iii++;
						}
					}
				}
				currentAttachementFileDeficiencies.clear();
				currentAttachementFileDeficienciesPath.clear();
				currentAttachementFileDeficiencies.add(null);
				currentAttachementFileDeficienciesPath.add(null);
				inspectionService.update(deficienciesToModify);
			} catch (Exception e) {
				currentAttachementFileDeficiencies.clear();
				currentAttachementFileDeficienciesPath.clear();
				currentAttachementFileDeficiencies.add(null);
				currentAttachementFileDeficienciesPath.add(null);
			}
			deficienciesToModify = null;
		}
	}

	public void uploadAttachementDeficienciesActionListener(FileEntryEvent e) {

		log.info("uploadAttachementDeficienciesActionListener  ac01");
		String idComponente = ((FileEntry) e.getSource()).getId();
		log.info(idComponente + "  ...id completo!!!!!!!!!!!!");
		idComponente = idComponente.substring(idComponente.lastIndexOf("_") + 1);

		log.info("uploadAttachementDeficienciesActionListener  ac02");

		FileEntry fe = (FileEntry) e.getComponent();
		FileEntryResults results = fe.getResults();

		for (FileInfo i : results.getFiles()) {
			if (i.isSaved()) {
				log.info("Salvato: " + i.getFileName());
				currentAttachementFileDeficiencies.set(Integer.parseInt(idComponente), i);
				currentAttachementFileDeficienciesPath.set(Integer.parseInt(idComponente),
						currentAttachementFileDeficiencies.get(Integer.parseInt(idComponente)).getFileName());
			} else {
				addWarningMessage("File was not saved because: "
						+ i.getStatus().getFacesMessage(FacesContext.getCurrentInstance(), fe, i).getSummary());
			}
		}

	}

	public void addNewDeficienciesAttachement(ActionEvent e) {
		currentAttachementFileDeficiencies.add(null);
		currentAttachementFileDeficienciesPath.add(null);
	}

	public void removeDeficienciesAttachement(ActionEvent e) {
		Integer rowIndex = (Integer) e.getComponent().getAttributes().get("rowIndexd");
		if (rowIndex != null) {
			Path path = Paths.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
					+ File.separator + currentAttachementFileDeficienciesPath.get(rowIndex)));
			try {
				Files.deleteIfExists(path);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			currentAttachementFileDeficiencies.remove(rowIndex.intValue());
			currentAttachementFileDeficienciesPath.remove(rowIndex.intValue());
		}
		if (currentAttachementFileDeficiencies == null || currentAttachementFileDeficiencies.size() == 0) {
			currentAttachementFileDeficiencies = new ArrayList<FileInfo>();
			currentAttachementFileDeficiencies.add(null);
			currentAttachementFileDeficienciesPath.add(null);
		}
	}

	public List<SelectItem> getCountries() {
		if (countriesItems == null) {
			countriesItems = new ArrayList<SelectItem>();
			List<Country> cs = genericLookupService.getAll();
			countriesItems.add(new SelectItem(new Long(0), ""));
			for (Country c : cs) {
				SelectItem item = new SelectItem(c.getId(), c.getName());
				countriesItems.add(item);
			}
		}
		return countriesItems;
	}

	public void downloadDeficienciesAttachements(ActionEvent evt) {
		Integer fileIndex = (Integer) evt.getComponent().getAttributes().get("rowIndexd");
		log.info("downloadAttachement - fileIndex:" + fileIndex);
		if (fileIndex != null) {
			String pathF = currentAttachementFileDeficienciesPath.get(fileIndex);
			if (pathF != null) {

				try {
					log.info("Downlaod " + pathF);
					String uniqueId = UUID.randomUUID().toString();
					String fileName = "";
					Path path = Paths
							.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
									+ File.separator + pathF));
					byte[] res = null;
					if (Files.exists(path)) {
						res = FileUtils.getBytesFromFile(
								PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
										+ File.separator + pathF);
						fileName = pathF;
					} else {
						res = FileUtils.getBytesFromFile(
								currentAttachementFileDeficiencies.get(fileIndex).getFile().getAbsolutePath());
						fileName = pathF;
					}
					downloadListBean.addDownloadObject(uniqueId, res, fileName);

					JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
							"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
									+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
									+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void countrySelection(ValueChangeEvent e) {
		log.info("Nuova Country selezionata :" + e.getNewValue());

		if (e.getNewValue() != null && (Long) e.getNewValue() > 0) {
			ports.clear();
			List<Port> cs = genericLookupService.getCountryPort((Long) e.getNewValue());
			ports.add(new SelectItem(new Long(0), ""));
			for (Port c : cs) {
				SelectItem item = new SelectItem(c.getId(), c.getName());
				ports.add(item);
			}

			Country co = null;
			try {
				co = genericLookupService.get((Long) e.getNewValue());
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}
			inspection.setCountry(co);
		}
	}

	public void portSelection(ValueChangeEvent e) {
		log.info("Nuovo Port selezionato :" + e.getNewValue());

		if (e.getNewValue() != null && (Long) e.getNewValue() > 0) {
			Port port = null;
			try {
				port = genericLookupService.getPort((Long) e.getNewValue());
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}
			inspection.setPort(port);
		}
	}

	public void areaSelection(ValueChangeEvent e) {
		log.info("Nuova area selezionata :" + e.getNewValue());

		if (e.getNewValue() != null) {
			String ar = (String) e.getNewValue();

			// Subarea
			subareas.clear();
			String[] areasArray = null;
			if (ar.equalsIgnoreCase("structural"))
				areasArray = subareasStructural;
			if (ar.equalsIgnoreCase("human"))
				areasArray = subareasHuman;
			if (ar.equalsIgnoreCase("maintenance"))
				areasArray = subareasMaintenance;
			if (ar.equalsIgnoreCase("management"))
				areasArray = subareasManagement;
			if (ar.equalsIgnoreCase("security"))
				areasArray = subareasSecurity;

			subareas.add(new SelectItem(new Long(0), ""));
			if (areasArray != null) {
				for (int i = 0; i < areasArray.length; i++) {
					SelectItem item = new SelectItem(areasArray[i], areasArray[i]);
					subareas.add(item);
				}
			}

			// Root cause
			rootCauses.clear();
			String[] rootArray = null;
			if (ar.equalsIgnoreCase("structural") || ar.equalsIgnoreCase("deck") || ar.equalsIgnoreCase("engine"))
				rootArray = rootCausesStructural;
			if (ar.equalsIgnoreCase("human"))
				rootArray = rootCausesHuman;
			if (ar.equalsIgnoreCase("maintenance"))
				rootArray = rootCausesMaintenance;
			if (ar.equalsIgnoreCase("management") || ar.equalsIgnoreCase("security"))
				rootArray = rootCausesManagement;
			if (ar.equalsIgnoreCase("galley"))
				rootArray = rootCausesGalley;
			if (ar.equalsIgnoreCase("bridge"))
				rootArray = rootCausesBridge;

			for (int i = 0; i < rootArray.length; i++) {
				SelectItem item = new SelectItem(rootArray[i], rootArray[i]);
				rootCauses.add(item);
			}

		} else {
			subareas.clear();
			rootCauses.clear();
		}
	}

	public void saveAndSynchronizeWithOffice(ActionEvent e) {

		try {
			save(e);

			// INVIO a ufficio
			DataExchangeMessage message = new DataExchangeMessage(
					PropertiesUtils.getInstance().readProperty("ship.uuid"), true,
					CommunicationMessageType.TMSA_PSC_INSPECTION_SYNC);
			log.info("INVIO all'ufficio....");
			if (inspection != null) {
				try {
					for (String attI : inspection.getAttachments()) {
						log.info(attI);
					}
					for (Deficiency def : inspection.getDeficiencies()) {
						for (String at : def.getAttachments()) {
							log.info(at);
						}
					}
				} catch (Exception e2) {
					// TODO: handle exception
				}
				// Allego l'istanza serializzata
				XStream xs = new XStream();
//				xs.autodetectAnnotations(true);
				ByteArrayOutputStream baos = null;
				try {
					baos = new ByteArrayOutputStream();
					Writer writer = new OutputStreamWriter(baos, "UTF-8");
					xs.toXML(inspection, writer);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				message.getEntities().add(baos.toByteArray());

				// Allego gli eventuali allegati
				for (String attPath : inspection.getAttachments()) {
					final String filname = attPath;
					message.getFiles().put(filname,
							FileUtils.getBytesFromFile(
									PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
											+ File.separator + attPath));
				}
				if (inspection.getDeficiencies() != null) {
					for (Deficiency def : inspection.getDeficiencies()) {
						if (def.getAttachments() != null) {
							for (String attPath : def.getAttachments()) {
								final String filname = attPath;
								message.getFiles()
										.put(filname,
												FileUtils.getBytesFromFile(PropertiesUtils.getInstance()
														.readProperty("repository.location.audit.attachments")
														+ File.separator + attPath));
							}
						}
					}
				}
				message.getProperties().put("DATE", (EasyDateUtils.getGMT0CurrentDate()).toString());
				message.getProperties().put("UUID", inspection.getUuid());

				try {
					communicatorSenderNave.sendMessage(message);

					Inspection is = inspectionService.getInspection(inspection.getId());
					is.setSynchronizedWithRemote(true);
					inspection = inspectionService.update(is);

					log.info("Istanza inviata!!!");
				} catch (Throwable e2) {
					e2.printStackTrace();
					log.error("Errore nell'invio Istanza: " + e2.getMessage());
				}
			}

			addInfoMessage("Inspection sent to office!");
		} catch (Exception e2) {
			e2.printStackTrace();
			addErrorMessage("Error sending Inspection!");
		}

	}

	public void save(ActionEvent e) {

		try {

			if (inspection.getDeficiencies() != null && inspection.getDeficiencies().size() > 0)
				inspection.setStatus("Open");
			else
				inspection.setStatus("Closed");

			inspection.setType(1); // Vetting

			// Dal service fare un (count whare dateOfFirstBoarding.year = utc.year and
			// inspection.getType = 0 ) + 1
			log.info("inspectionService.getNroInspectionByTypeAndYear +1 _Type PSC: "
					+ inspectionService.getNroInspectionByTypeAndYear(1));
			if (inspection.getNro() == null || inspection.getNro().equals(""))
				inspection.setNro(inspectionService.getNroInspectionByTypeAndYear(1));

			// Salvo gli allgati
			// Salvo gli allgati
			if (currentAttachementFile != null) {
				int iii = 0;
				List<String> tempList = inspection.getAttachments();
				if (tempList == null)
					tempList = new ArrayList<String>();
				inspection.setAttachments(new ArrayList<String>());
				for (String filePath : currentAttachementFilePath) {
					if (filePath != null && !filePath.equals("")) {
						if (!tempList.contains(filePath)) {
							InputStream data = new FileInputStream(
									currentAttachementFile.get(iii).getFile().getAbsolutePath());
							String realname = inspectionService.storeInspectionAttachementFile(data, filePath);
							inspection.getAttachments().add(realname);
							// Aggiorno con il path reale
							currentAttachementFilePath.set(iii, realname);
						} else
							inspection.getAttachments().add(filePath);
					}
					iii++;
				}
			}

			inspection.setSynchronizedWithRemote(false);
			if (inspection.getId() == null) {
				inspection = inspectionService.add(inspection);
			} else
				inspection = inspectionService.update(inspection);

			// se esiste eseguo il workflow NO --->e creo l'azione correttiva associata alla
			// observation(Deficiency).
			if (inspection.getDeficiencies() != null) {
				for (Deficiency def : inspection.getDeficiencies()) {
					DeficiencyModel dm = inspectionService.getDeficiencyModelByDeficiencyType(def.getType());
					if (dm != null && dm.getWorkflow() != null && !dm.getWorkflow().equals("")) {
						// Eseguo il workflow
						if (!scriptService.evaluateWorkflow(dm.getWorkflow(), null, agendaService, documentService,
								messageService)) {
							addErrorMessage("Associated deficiency workflow not executed correctly...skipped");
						}
					}

					// Elemento agenda se impostata la data dell'azione correttiva.
					if (def.getCorrectiveAction() != null
							&& def.getCorrectiveAction().getTimeLimitForCorrectiveAction() != null) {

						// Aggiungo un elemento all'agenda con data TimeLimitForCorrectiveAction (lo
						// faccio scattare a mezzanotte e 1 minuto)
						Calendar cal = Calendar.getInstance();
						cal.setTime(def.getCorrectiveAction().getTimeLimitForCorrectiveAction());
						String triggerString = "0 1 0 " + cal.get(Calendar.DAY_OF_MONTH) + " "
								+ (cal.get(Calendar.MONTH) + 1) + " ? " + cal.get(Calendar.YEAR);
						String script = "messageService.addMessage(\"Vetting Inspection " + inspection.getId()
								+ ": Corrective action for deficiecy with code " + def.getCode()
								+ " will expire today!!!\", \"INFO\");";
						agendaService.addTodo(
								"Vetting Inspection " + inspection.getId()
										+ ": Corrective action for deficiecy with code " + def.getCode() + " expiring.",
								null, null, triggerString, script);
						log.info("elemento agenda inserito!!!!!");
					}
				}
			}

//			 synchronizeWithOffice();

			// Azzero ricerca
			VettingOpenedInspectionBean bb = (VettingOpenedInspectionBean) FacesUtils
					.getManagedBean("vettingOpenedInspectionBean");
			if (bb != null)
				bb.search(null);

			addInfoMessage("Inspection updated.");
		} catch (Exception e2) {
			e2.printStackTrace();
			addErrorMessage("Error updating Inspection!", e2);
		}
	}

	public void selectSection(ActionEvent evt) {
		String sectionId = FacesUtils.getRequestParameter("sectionName");
		log.info("sectionName=" + sectionId);

	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public Long getPortId() {
		return portId;
	}

	public void setPortId(Long portId) {
		this.portId = portId;
	}

	public List<SelectItem> getPorts() {
		return ports;
	}

	public Inspection getInspection() {
		return inspection;
	}

	public void setInspection(Inspection inspection) {
		this.inspection = inspection;
	}

	public List<SelectItem> getAreas() {
		return areas;
	}

	public List<SelectItem> getSubareas() {
		return subareas;
	}

	public List<SelectItem> getRootCauses() {
		return rootCauses;
	}

	public List<SelectItem> getOperationCheck1Items() {
		return operationCheck1Items;
	}

	public List<SelectItem> getOperationCheck2Items() {
		return operationCheck2Items;
	}

	public List<SelectItem> getDeficiecyCodes() {
		return deficiecyCodes;
	}

	public Long getSelectedDeficiencyType() {
		return selectedDeficiencyType;
	}

	public void setSelectedDeficiencyType(Long selectedDeficiencyType) {
		this.selectedDeficiencyType = selectedDeficiencyType;
	}

	public Deficiency getDeficienciesToModify() {
		return deficienciesToModify;
	}

	public void setDeficienciesToModify(Deficiency deficienciesToModify) {
		this.deficienciesToModify = deficienciesToModify;
	}

	public String getChapterDescription() {
		return chapterDescription;
	}

	public void setChapterDescription(String chapterDescription) {
		this.chapterDescription = chapterDescription;
	}

	public List<SelectItem> getInspectionCompanies() {
		return inspectionCompanies;
	}

	public List<FileInfo> getCurrentAttachementFile() {
		return currentAttachementFile;
	}

	public void setCurrentAttachementFile(List<FileInfo> currentAttachementFile) {
		this.currentAttachementFile = currentAttachementFile;
	}

	public List<String> getCurrentAttachementFilePath() {
		return currentAttachementFilePath;
	}

	public void setCurrentAttachementFilePath(List<String> currentAttachementFilePath) {
		this.currentAttachementFilePath = currentAttachementFilePath;
	}

	public boolean isRequisitionEdit() {
		return requisitionEdit;
	}

	public void setRequisitionEdit(boolean requisitionEdit) {
		this.requisitionEdit = requisitionEdit;

		if (!requisitionEdit) { // chiudo
			RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
			if (requisitionBean != null) {
				if (requisitionBean.getIdRequisitionForSendToOffice() != null) {
					deficienciesToModify.getCorrectiveAction().setRequisition(
							requisitionService.getRequisition(requisitionBean.getIdRequisitionForSendToOffice()));
					requisitionBean.setIdRequisitionForSendToOffice(null);
				}
			}
		}
	}

	public void dryDockReport(ActionEvent ev) {
		if (deficienciesToModify != null && deficienciesToModify.getDryDockForm() != null) {

			try {
				// log.info("getFormInspectionn... form path:" +
				// inspectionSelected.getForm().getPath());
				// Create a reader that interprets the input stream
				FdfReader fdf = new FdfReader(deficienciesToModify.getDryDockFormData()); // Valido solo se il pulsante
																							// di submit � di tipo fdf
																							// submit

				// Get document input stream
				InputStream pdfInputStream = new FileInputStream(
						PropertiesUtils.getInstance().readProperty("repository.location.tmsa.forms")
								+ File.separatorChar + deficienciesToModify.getDryDockForm().getPath());
//	            InputStream  pdfInputStream = new FileInputStream(deficienciesToModify.getDryDockForm().getPath());

				// We create a reader with the InputStream
				PdfReader reader = new PdfReader(pdfInputStream, null);
				// We create an OutputStream for the new PDF
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				// Now we create the new PDF
				PdfStamper stamper = new PdfStamper(reader, baos);

				// We alter the fields of the existing PDF
				AcroFields fields = stamper.getAcroFields();
				fields.setFields(fdf);
				stamper.setFormFlattening(true); // Diventa un pdf non form
				// stamper.setFormFlattening(false); // rimane un pdf form scrivibile

				// close the stamper
				stamper.close();

				String uniqueId = UUID.randomUUID().toString();
				downloadListBean.addDownloadObject(uniqueId, baos.toByteArray(), "DryDock.pdf");

				JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
						"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
								+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
								+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");

//	            return new ByteArrayResource(baos.toByteArray());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (com.itextpdf.text.DocumentException e) {
				e.printStackTrace();
			}
		}

	}

	private boolean showPopupPdfForm = false;
	private Long documentPdfFormIdToCompile = null;

	public void dryDockDocumentChanged(ValueChangeEvent e) {

		if (e != null && e.getNewValue() != null && (e.getNewValue()).equals(true)) {

			Long dryDockDocumentId = null;
			try {
				List<TmsaForm> forms = auditService.getAuditFormFinder().and("enabled").eq(Boolean.TRUE).and("type")
						.eq("DD").list();
				if (forms != null && !forms.isEmpty()) {
					log.info("getCurrentM23DocumentId nell'if...");
					dryDockDocumentId = forms.get(0).getId();
				}
			} catch (Throwable e1) {
				e1.printStackTrace();
			}

			showPopupPdfForm = true;
			documentPdfFormIdToCompile = dryDockDocumentId;

			// String call="changeIframe('" + docId + "', '0', false,
			// 'iframe_pdf_audit_edit');";
			String call = "changeIframeGen('" + dryDockDocumentId
					+ "', 'fdfAudit.pdf', 'false', 'iframe_pdf_audit_edit', 'VettingEdit');";
			log.info("documentSelected...call:" + call);
			JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(), call);
		}
	}

//	public void hidePopupPdfForm(ActionEvent e) {
//		showPopupPdfForm=false;
//	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.oceanpro.web.tmsa.servlet.FormCompiler#setRisultato(byte[])
	 */
	@Override
	public void setRisultato(byte[] risultato) {
		log.info("Risultato vetting edit ...");

		FormDataManipulationReader fdmr = new FormDataManipulationReader(risultato);
		// DEBUG
		log.info("CAMPI:");
		for (String key : fdmr.getFieldsName()) {
			log.info("Campo: " + key + " Valore: " + fdmr.getFieldValue(key));
		}

		// Dry Document
		log.info("Dry document!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

		deficienciesToModify.setDryDockFormData(risultato);
		deficienciesToModify
				.setDryDockForm(auditService.getAuditFormFinder().and("id").eq(documentPdfFormIdToCompile).result());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.oceanpro.web.tmsa.servlet.FormCompiler#getDocumentStream(java.lang.
	 * String)
	 */
	@Override
	public InputStream getDocumentStream(String docId) {
		log.info("Vetting Bean getDocumentStream - docId:" + docId);
		try {
			FileInputStream fis = null;
			TmsaForm forms = auditService.getAuditFormFinder().and("id").eq(Long.parseLong(docId)).result();
			if (forms != null) {

				File a = new File(PropertiesUtils.getInstance().readProperty("repository.location.tmsa.forms")
						+ File.separatorChar + forms.getPath());
//    			File a = new File(forms.getPath());

				fis = new FileInputStream(a);
			}

			return fis;
		} catch (Throwable e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean isShowPopupPdfForm() {
		return showPopupPdfForm;
	}

	public void setShowPopupPdfForm(boolean showPopupPdfForm) {
		this.showPopupPdfForm = showPopupPdfForm;
	}

	public Long getDocumentPdfFormIdToCompile() {
		return documentPdfFormIdToCompile;
	}

	public void setDocumentPdfFormIdToCompile(Long documentPdfFormIdToCompile) {
		this.documentPdfFormIdToCompile = documentPdfFormIdToCompile;
	}

	public List<SelectItem> getPotentialRisks() {
		return potentialRisks;
	}

	public void setPotentialRisks(List<SelectItem> potentialRisks) {
		this.potentialRisks = potentialRisks;
	}

	public List<SelectItem> getContributingFactors() {
		return contributingFactors;
	}

	public void setContributingFactors(List<SelectItem> contributingFactors) {
		this.contributingFactors = contributingFactors;
	}

	public List<SelectItem> getVesselCondition() {
		return vesselCondition;
	}

	public void setVesselCondition(List<SelectItem> vesselCondition) {
		this.vesselCondition = vesselCondition;
	}

	private String uploadDir = PropertiesUtils.getInstance().readProperty("repository.location.audit");

	public String getUploadFolder() {
		return uploadDir;
	}

	private FileInfo currentFile;

	public FileInfo getCurrentFile() {
		return currentFile;
	}

	public void setCurrentFile(FileInfo currentFile) {
		this.currentFile = currentFile;
	}

	public void uploadDatasheetActionListener(FileEntryEvent e) {
		FileEntry fe = (FileEntry) e.getComponent();
		FileEntryResults results = fe.getResults();

		for (FileInfo i : results.getFiles()) {
			if (i.isSaved()) {
				log.info("Salvato: " + i.getFileName());
				currentFile = i;
				deficienciesToModify.setDatasheet(currentFile.getFileName());
			} else {
				addWarningMessage("File was not saved because: "
						+ i.getStatus().getFacesMessage(FacesContext.getCurrentInstance(), fe, i).getSummary());
			}
		}
	}

	public void downloadAttachements(ActionEvent evt) {
		Integer fileIndex = (Integer) evt.getComponent().getAttributes().get("rowIndex");
		log.info("downloadAttachement - fileIndex:" + fileIndex);
		if (fileIndex != null) {
			String pathF = currentAttachementFilePath.get(fileIndex);
			if (pathF != null) {

				try {
					log.info("Downlaod " + pathF);
					String uniqueId = UUID.randomUUID().toString();
					String fileName = "";
					Path path = Paths
							.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
									+ File.separator + pathF));
					byte[] res = null;
					if (Files.exists(path)) {
						res = FileUtils.getBytesFromFile(
								PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
										+ File.separator + pathF);
						fileName = pathF;
					} else {
						res = FileUtils
								.getBytesFromFile(currentAttachementFile.get(fileIndex).getFile().getAbsolutePath());
						fileName = pathF;
					}
					downloadListBean.addDownloadObject(uniqueId, res, fileName);

					JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
							"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
									+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
									+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void downloadAttachement(ActionEvent evt) {
		long deficiencyId = FacesUtils.getRequestParameter("deficienciesToModifyId", Long.class, 0L);
		if (deficiencyId != 0L) {
			try {
				Deficiency deficiency = auditService.getDeficiency(deficiencyId);
				String uniqueId = deficiency.getUuid();
				String fileName = deficiency.getDatasheet();
				byte[] res = FileUtils.getBytesFromFile(uploadDir + File.separator + fileName);
				downloadListBean.addDownloadObject(uniqueId, res, fileName);
				JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
						"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
								+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
								+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void removeDatasheet(ActionEvent actionEvent) {

		String fileName = deficienciesToModify.getDatasheet();
		String filePath = uploadDir + File.separator + fileName;

		deficienciesToModify.setDatasheet("");

	}

	public List<SelectItem> getRootCausesTwo() {
		return rootCausesTwo;
	}

	public void setRootCausesTwo(List<SelectItem> rootCausesTwo) {
		this.rootCausesTwo = rootCausesTwo;
	}

	public List<SelectItem> getImmediateCauses() {
		return immediateCauses;
	}

	public void setImmediateCauses(List<SelectItem> immediateCauses) {
		this.immediateCauses = immediateCauses;
	}

	public List<FileInfo> getCurrentAttachementFileDeficiencies() {
		return currentAttachementFileDeficiencies;
	}

	public void setCurrentAttachementFileDeficiencies(List<FileInfo> currentAttachementFileDeficiencies) {
		this.currentAttachementFileDeficiencies = currentAttachementFileDeficiencies;
	}

	public List<String> getCurrentAttachementFileDeficienciesPath() {
		return currentAttachementFileDeficienciesPath;
	}

	public void setCurrentAttachementFileDeficienciesPath(List<String> currentAttachementFileDeficienciesPath) {
		this.currentAttachementFileDeficienciesPath = currentAttachementFileDeficienciesPath;
	}

}
