package com.oceanpro.web.tmsa;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.icefaces.ace.component.fileentry.FileEntry;
import org.icefaces.ace.component.fileentry.FileEntryEvent;
import org.icefaces.ace.component.fileentry.FileEntryResults;
import org.icefaces.ace.component.fileentry.FileEntryResults.FileInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.icesoft.faces.context.effects.JavascriptContext;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.FdfReader;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.oceanpro.communication.message.CommunicationMessageType;
import com.oceanpro.communication.message.DataExchangeMessage;
import com.oceanpro.communication.ship.CommunicatorSenderNave;
import com.oceanpro.core.entity.oceanManager.commons.Country;
import com.oceanpro.core.entity.oceanManager.commons.Port;
import com.oceanpro.core.entity.oceanManager.tmsa.Deficiency;
import com.oceanpro.core.entity.oceanManager.tmsa.DeficiencyModel;
import com.oceanpro.core.entity.oceanManager.tmsa.DeficiencyType;
import com.oceanpro.core.entity.oceanManager.tmsa.FollowupAndCorrectiveAction;
import com.oceanpro.core.entity.oceanManager.tmsa.Inspection;
import com.oceanpro.core.entity.oceanManager.tmsa.TmsaForm;
import com.oceanpro.core.exception.DocumentException;
import com.oceanpro.core.services.AgendaService;
import com.oceanpro.core.services.AuditService;
import com.oceanpro.core.services.DocumentService;
import com.oceanpro.core.services.GenericLookupService;
import com.oceanpro.core.services.InspectionService;
import com.oceanpro.core.services.MessageService;
import com.oceanpro.core.services.RequisitionService;
import com.oceanpro.core.services.ScriptService;
import com.oceanpro.core.utils.FileUtils;
import com.oceanpro.core.utils.PropertiesUtils;
import com.oceanpro.core.utils.formsUtils.FormDataManipulationReader;
import com.oceanpro.utils.EasyDateUtils;
import com.oceanpro.web.store.RequisitionBean;
import com.oceanpro.web.tmsa.servlet.FormCompiler;
import com.oceanpro.web.utils.jsf.BaseBean;
import com.oceanpro.web.utils.jsf.FacesUtils;
import com.oceanpro.web.utils.servlet.DownloadListBean;
import com.thoughtworks.xstream.XStream;

@Component
@Scope("session")
@Qualifier("pscBean")
public class PscBean extends BaseBean implements FormCompiler {

	// Serial
	private static final long serialVersionUID = -1227579890711748600L;
	private static final Logger log = LoggerFactory.getLogger(PscBean.class);
	@Autowired
	private CommunicatorSenderNave communicatorSenderNave;
	@Autowired
	private RequisitionService requisitionService;
	@Autowired
	AuditService auditService;
	@Autowired
	GenericLookupService genericLookupService;
	@Autowired
	InspectionService inspectionService;
	@Autowired
	private ScriptService scriptService;
	@Autowired
	private DocumentService documentService;
	@Autowired
	private AgendaService agendaService;
	@Autowired
	protected MessageService messageService;
	@Autowired
	private DownloadListBean downloadListBean;

	private Inspection inspection;

	private List<SelectItem> countriesItems = null;
	private List<SelectItem> ports = null;
	private List<SelectItem> mous = null;
	private Long countryId;
	private Long portId;

	private List<SelectItem> deficiencyItems = null;
	private DeficiencyType selectedDeficiencyType = null;
	private String selectedDeficiencyCode = null;
	private Deficiency deficienciesToModify;

	private List<SelectItem> deficiecyCodes = null;

	private List<FileInfo> currentAttachementFile;
	private List<String> currentAttachementFilePath;

	private List<FileInfo> currentAttachementFileDeficiencies;
	private List<String> currentAttachementFileDeficienciesPath;

	// TEST
	private List<FileInfo> testCA;
	private List<String> testCAF;

	private List<SelectItem> areas = null;
	private List<SelectItem> subareas = null;
	private String[] subareasStructural = { "ENGINE", "DECK", "CARGO", "BRIDGE", "OTHER" };
	private String[] subareasMaintenance = { "ENGINE", "DECK", "CARGO", "SAFETY", "BRIDGE", "OTHER" };
	private String[] subareasHuman = { "ENGINE", "NAVIGATION", "DECK", "CARGO", "SAFETY", "CREW", "PROCEDURE",
			"MANAGEMENT", "OFFICER", "DRILL", "OTHER" };
	private String[] subareasManagement = { "ENGINE", "NAVIGATION", "DECK", "CARGO", "SAFETY", "CREW", "PROCEDURE",
			"CERTIFICATION", "DRILL", "OTHER" };
	private String[] subareasSecurity = { "ENGINE", "NAVIGATION", "DECK", "CARGO", "SAFETY", "CREW", "PROCEDURE",
			"CERTIFICATION", "OTHER" };
	private List<SelectItem> rootCauses = null;
	private String[] rootCausesStructural = { "IMPROPER MAINTENANCE", "SHIP BUILDING", "DEFECTIVE EQUIPMENT", "OTHER" };
	private String[] rootCausesMaintenance = { "REDUCED TIME", "CREW", "TECHNICAL", "PENDING REQUISITIONS", "OTHER" };
	private String[] rootCausesHuman = { "INEXPERIENCE", "Inattention", "Drugs-Alcohol", "Lack of Training",
			"Complacency", "Improper Equipment Use", "Forgetfulness", "FATIGUE", "OTHER" };
	private String[] rootCausesManagement = { "Communications", "Company Policy", "Insufficient Personnel",
			"Procedural Error", "Unspecified/Other", "Lack of supervision", "instructions not clear or enforced",
			"OTHER" };
	private String[] rootCausesGalley = { "IMPROPER FOOD EADLING", "DEFECTIVE EQUIPEMENT", "OTHER" };
	private String[] rootCausesBridge = { "DEFECTIVE EQUIPEMENT", "IMPROPER USAGE", "OTHER" };

	private List<SelectItem> potentialRisks = null;
	private List<SelectItem> contributingFactors = null;

	private Map<String, String> actionCodes = null;

	private List<SelectItem> operationCheck1Items = null;
	private List<SelectItem> operationCheck2Items = null;
	private List<SelectItem> immediateCauses = null;
	private List<SelectItem> rootCausesTwo = null;
	protected boolean inizializzato = false;

	public String newInspection() {
		inizializzato = false;
		initCustomModel();
		return "new_psc_inspection";
	}

	public String editInspection() {
		String inspectionId = FacesUtils.getRequestParameter("inspectionId");
		log.info("Edit inspection - inspectionId: " + inspectionId);

		try {
			inspection = inspectionService.getInspection(Long.parseLong(inspectionId));
			List<Deficiency> deficiencies = inspection.getDeficiencies(); // serves to initialize deficiencies from db
			for (Deficiency def : deficiencies) { // serves to initialize deficiencies from db
				log.info(def.getId().toString());
			}
			if (inspection != null) {
				if (inspection.getCountry() != null) {
					countryId = inspection.getCountry().getId();
					populatePorts(countryId);
				} else {
					ports = new ArrayList<SelectItem>();
				}
				if (inspection.getPort() != null)
					portId = inspection.getPort().getId();

				// Allegati
				currentAttachementFile.clear();
				currentAttachementFilePath.clear();
				currentAttachementFile.add(null);
				currentAttachementFilePath.add(null);
				for (String at : inspection.getAttachments()) {
					try {
						currentAttachementFile.add(0, null);
						currentAttachementFilePath.add(0, at);

//						BaseResource br = new BaseResource();
//						br.setAttachement(true);
//						//br.setFileName(at);
//						br.setFileName(at.substring(at.lastIndexOf("\\")+1));
//						//br.setMimeType(mimeType);
//						Resource r = new ByteArrayResource(FileUtils.getBytesFromFile(PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")+File.separator+at));
//						br.setResource(r);
//						allegati.add(br);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		} catch (DocumentException e) {
			e.printStackTrace();
			inspection = null;
		}
		inizializzato = true;
		return "new_psc_inspection";
	}

	public String updateInspection() {
		String inspectionId = FacesUtils.getRequestParameter("inspectionId");
		log.info("Update inspection - inspectionId: " + inspectionId);
		Long inspId = Long.parseLong(inspectionId);

		try {

			// imposto syncroWithRemote a false in modo da renderlo modificabile
			inspection = inspectionService.getInspection(inspId);
			inspection.setSynchronizedWithRemote(false);
			inspection = inspectionService.update(inspection);

			inspection = inspectionService.getInspection(Long.parseLong(inspectionId));
			List<Deficiency> deficiencies = inspection.getDeficiencies(); // serves to initialize deficiencies from db
			for (Deficiency def : deficiencies) { // serves to initialize deficiencies from db
				log.info(def.getId().toString());
			}
			if (inspection != null) {
				if (inspection.getCountry() != null) {
					countryId = inspection.getCountry().getId();
					populatePorts(countryId);
				} else {
					ports = new ArrayList<SelectItem>();
				}
				if (inspection.getPort() != null)
					portId = inspection.getPort().getId();

				// Allegati
				currentAttachementFile.clear();
				currentAttachementFilePath.clear();
				currentAttachementFile.add(null);
				currentAttachementFilePath.add(null);
				for (String at : inspection.getAttachments()) {
					try {
						currentAttachementFile.add(0, null);
						currentAttachementFilePath.add(0, at);

					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		} catch (DocumentException e) {
			e.printStackTrace();
			inspection = null;
		}
		inizializzato = true;
		return "new_psc_inspection";
	}

	private void populatePorts(Long countryId) {
		ports.clear();
		List<Port> cs = genericLookupService.getCountryPort(countryId);
		ports.add(new SelectItem(new Long(0), ""));
		for (Port c : cs) {
			SelectItem item = new SelectItem(c.getId(), c.getName());
			ports.add(item);
		}
	}

	@PostConstruct
	public void initCustomModel() {
		log.info("INIT PscBean");

		// TODO Mettere questi dati in tabella db perch� servono anche in TmsaPscData
		if (!inizializzato) {
			ports = new ArrayList<SelectItem>();
			mous = new ArrayList<SelectItem>();
			mous.add(new SelectItem(null, ""));
			mous.add(new SelectItem("PARIS MOU", "PARIS MOU"));
			mous.add(new SelectItem("Acuerdo de Vina del Mar", "Acuerdo de Vina del Mar"));
			mous.add(new SelectItem("TOKIO MOU", "TOKIO MOU"));
			mous.add(new SelectItem("Caribbean MOU", "Caribbean MOU"));
			mous.add(new SelectItem("Black Sea MOU", "Black Sea MOU"));
			mous.add(new SelectItem("Indian Ocean MOU", "Indian Ocean MOU"));
			mous.add(new SelectItem("West and Central Afican MOU", "West and Central Afican MOU"));
			mous.add(new SelectItem("USA & Territory", "USA & Territory"));
			mous.add(new SelectItem("Mediterranean MOU", "Mediterranean MOU"));
			mous.add(new SelectItem("RIAD MOU", "RIAD MOU"));
			mous.add(new SelectItem("Other/Local Inspection", "Other/Local Inspection"));

			inspection = new Inspection();

			deficiencyItems = new ArrayList<SelectItem>();
			for (int i = 0; i < DeficiencyType.values().length; i++) {
//				deficiencyItems.add(new SelectItem(DeficiencyType.values()[i], DeficiencyType.values()[i].getName()));

				deficiencyItems
						.add(new SelectItem(DeficiencyType.values()[i].name(), DeficiencyType.values()[i].getName()));

			}

			areas = new ArrayList<SelectItem>();
			areas.add(new SelectItem(null, ""));
			areas.add(new SelectItem("STRUCTURAL", "STRUCTURAL"));
			areas.add(new SelectItem("MAINTENANCE", "MAINTENANCE"));
			areas.add(new SelectItem("HUMAN", "HUMAN"));
			areas.add(new SelectItem("MANAGEMENT", "MANAGEMENT"));
			areas.add(new SelectItem("SECURITY", "SECURITY"));

			areas.add(new SelectItem("DECK", "DECK"));
			areas.add(new SelectItem("ENGINE", "ENGINE"));
			areas.add(new SelectItem("GALLEY", "GALLEY"));
			areas.add(new SelectItem("BRIDGE", "BRIDGE"));

			subareas = new ArrayList<SelectItem>();
			rootCauses = new ArrayList<SelectItem>();
			rootCauses.add(new SelectItem(null, ""));
			rootCauses.add(new SelectItem("N/A"));
			rootCauses.add(new SelectItem("2.1.1. - Inadequate Physical/Physiological Capability"));
			rootCauses.add(new SelectItem("2.1.2. - Inadequate Mental/Psychological Capability"));
			rootCauses.add(new SelectItem("2.1.3. - Physical/Physiological Stress"));
			rootCauses.add(new SelectItem("2.1.4. - Mental/Psychological Stress"));
			rootCauses.add(new SelectItem("2.1.5. - Lack of Competence"));
			rootCauses.add(new SelectItem("2.1.6. - Improper Motivation"));
			rootCauses.add(new SelectItem("2.2.1. - Unclear Organizational Structure"));
			rootCauses.add(new SelectItem("2.2.2. - Inadequate Leadership"));
			rootCauses.add(new SelectItem("2.2.3. - Inadequate Supervision/Coaching"));
			rootCauses.add(new SelectItem("2.2.4. - Inadequate Management of Change"));
			rootCauses.add(new SelectItem("2.2.5. - Inadequate Supply Chain Management"));
			rootCauses.add(new SelectItem("2.2.6. - Inadequate Maintenance/Inspection"));
			rootCauses.add(new SelectItem("2.2.7. - Excessive Wear/Tear"));
			rootCauses.add(new SelectItem("2.2.8. - Inadequate Tool/Equipment/Machinery/Device"));
			rootCauses.add(new SelectItem("2.2.9. - Inadequate Product/Service Design"));
			rootCauses.add(new SelectItem("2.2.10. - Inadequate Work/Production Standards"));
			rootCauses.add(new SelectItem("2.2.11. - Inadequate Communication/Information"));

//			rootCauses.add(new SelectItem("Inexperience"));
//			rootCauses.add(new SelectItem("Inattention"));
//			rootCauses.add(new SelectItem("Error in evaluation"));
//			rootCauses.add(new SelectItem("Weather condition"));
//			rootCauses.add(new SelectItem("Poor planning"));
//			rootCauses.add(new SelectItem("Incorrect use of equipment"));
//			rootCauses.add(new SelectItem("Incorrect use of safety equipment"));
//			rootCauses.add(new SelectItem("Missing procedures"));
//			rootCauses.add(new SelectItem("Equipment failure"));
//			rootCauses.add(new SelectItem("Insufficient training"));
//			rootCauses.add(new SelectItem("Not relevant"));
//			rootCauses.add(new SelectItem("Lack of rest"));
//			rootCauses.add(new SelectItem("Poor communication"));
//			rootCauses.add(new SelectItem("Language misunderstanding"));
//			rootCauses.add(new SelectItem("Negligence"));
//			rootCauses.add(new SelectItem("Failure to check or maintain equipment"));
//			rootCauses.add(new SelectItem("lack of safety precautions"));
//			rootCauses.add(new SelectItem("Excessive speed"));
//			rootCauses.add(new SelectItem("Alcohol or drugs intake"));
//			rootCauses.add(new SelectItem("Work under stress"));
//			rootCauses.add(new SelectItem("Capability"));
//			rootCauses.add(new SelectItem("lack of information"));
//			rootCauses.add(new SelectItem("loss of alertness"));
//			rootCauses.add(new SelectItem("Complacency"));
//			rootCauses.add(new SelectItem("Insufficient Personnel"));
//			rootCauses.add(new SelectItem("Human error"));
//			rootCauses.add(new SelectItem("Other"));
//			rootCauses.add(new SelectItem("Inadequate Design / Material / Installation"));
//			rootCauses.add(new SelectItem("Inadequate Leadership"));
//			rootCauses.add(new SelectItem("Lack of Supervision"));
//			rootCauses.add(new SelectItem("Inadequate Maintenance or Repair Instructions / Schedule"));
//			rootCauses.add(new SelectItem("Inadequate Maintenance or Repair Carried Out"));
//			rootCauses.add(new SelectItem("Lack in spares receiving"));
//			rootCauses.add(new SelectItem("Inadequate tools"));
//			rootCauses.add(new SelectItem("Inadequate procedures appliance (excluding maintenance)"));
//			rootCauses.add(new SelectItem("Lack of Knowledge or Skill"));
//			rootCauses.add(new SelectItem("Inadequate training"));
//			rootCauses.add(new SelectItem("Lack of familiarization"));
//			rootCauses.add(new SelectItem("Physical Capability / Health Factors"));
//			rootCauses.add(new SelectItem("Inadequate rest  / Stress"));
//			rootCauses.add(new SelectItem("Inadequate Management of Change"));
//			rootCauses.add(new SelectItem("Wear & Tear"));
//			rootCauses.add(new SelectItem("Human Error"));
//			rootCauses.add(new SelectItem("Fatigue / Human Failure / Work overcharge"));

			immediateCauses = new ArrayList<SelectItem>();
			immediateCauses.add(new SelectItem("None"));
			immediateCauses.add(new SelectItem("01.01 - Drugs/Alcohol intoxication"));
			immediateCauses.add(new SelectItem("01.02 - Failure to follow Rules or Regulations"));
			immediateCauses.add(new SelectItem("01.03 - Failure to secure"));
			immediateCauses.add(new SelectItem("01.04 - Failure to use proper personal protective equipment"));
			immediateCauses.add(new SelectItem("01.05 - Failure to warn"));
			immediateCauses.add(new SelectItem("01.06 - Horseplay"));
			immediateCauses.add(new SelectItem("01.07 - Improper lifting"));
			immediateCauses.add(new SelectItem("01.08 - Improper loading"));
			immediateCauses.add(new SelectItem("01.09 - Improper placement"));
			immediateCauses.add(new SelectItem("01.10 - Improper position for task"));
			immediateCauses.add(new SelectItem("01.11 - Incorrect navigation or ship handling"));
			immediateCauses.add(new SelectItem("01.12 - Making safety devices inoperable"));
			immediateCauses.add(new SelectItem("01.13 - Operating at improper speed"));
			immediateCauses.add(new SelectItem("01.14 - Operating equipment without authority"));
			immediateCauses.add(new SelectItem("01.15 - Removing safety devices"));
			immediateCauses.add(new SelectItem("01.16 - Sabotage, wilful damage"));
			immediateCauses.add(new SelectItem("01.17 - Servicing equipment in operation"));
			immediateCauses.add(new SelectItem("01.18 - Using defective equipment"));
			immediateCauses.add(new SelectItem("01.19 - Using equipment improperly"));
			immediateCauses.add(new SelectItem("02.01 - Pilots"));
			immediateCauses.add(new SelectItem("02.02 - Berthing crew"));
			immediateCauses.add(new SelectItem("02.03 - Terminal personnel"));
			immediateCauses.add(new SelectItem("02.04 - Local authorities"));
			immediateCauses
					.add(new SelectItem("02.05 - Other people not under control of the company/shipboard management"));
			immediateCauses.add(new SelectItem("03.01 - Cargo"));
			immediateCauses.add(new SelectItem("03.02 - Congestion or restricted action"));
			immediateCauses.add(new SelectItem("03.03 - Dangerous atmosphere hazards"));
			immediateCauses.add(new SelectItem("03.04 - Defective tools, equipment or materials"));
			immediateCauses.add(new SelectItem("03.05 - Electric current hazards"));
			immediateCauses.add(new SelectItem("03.06 - Exposure to chemicals"));
			immediateCauses.add(new SelectItem("03.07 - Exposure to high temperature"));
			immediateCauses.add(new SelectItem("03.08 - Exposure to low temperature"));
			immediateCauses.add(new SelectItem("03.09 - Exposure to noise"));
			immediateCauses.add(new SelectItem("03.10 - Exposure to radiation"));
			immediateCauses.add(new SelectItem("03.11 - Fire or explosion hazards"));
			immediateCauses.add(new SelectItem("03.12 - Inadequate guards or barriers"));
			immediateCauses.add(new SelectItem("03.13 - Inadequate or excessive illumination"));
			immediateCauses.add(new SelectItem("03.14 - Inadequate or improper protective equipment"));
			immediateCauses.add(new SelectItem("03.15 - Inadequate ventilation"));
			immediateCauses.add(new SelectItem("03.16 - Inadequate warning systems"));
			immediateCauses.add(new SelectItem("03.17 - Incorrect/inadequate tools, equipment or materials"));
			immediateCauses.add(new SelectItem("03.18 - Other excessive exposures"));
			immediateCauses.add(new SelectItem("03.19 - Outdated charts, publications and other documentation"));
			immediateCauses.add(new SelectItem("03.20 - Poor housekeeping, disorder"));
			immediateCauses.add(new SelectItem("03.21 - Wet/slippery surface"));
			immediateCauses.add(new SelectItem("04.01 - Adverse weather conditions"));
			immediateCauses.add(new SelectItem("04.02 - Adverse sea conditions"));
			immediateCauses.add(new SelectItem("04.03 - Inadequate port and berthing facilities"));

			rootCausesTwo = new ArrayList<SelectItem>();
			rootCausesTwo.add(new SelectItem("None"));
			rootCausesTwo.add(new SelectItem("01.01 - Inadequate height/weight/size/strength/reach, etc."));
			rootCausesTwo.add(new SelectItem("01.02 - Restricted range of body movement"));
			rootCausesTwo.add(new SelectItem("01.03 - Limited ability/inability to sustain body positions"));
			rootCausesTwo.add(new SelectItem("01.04 - Substance sensitivity/allergy"));
			rootCausesTwo.add(new SelectItem("01.05 - Sensitivities to sensory extreme (temperature/sound/etc.)"));
			rootCausesTwo.add(new SelectItem("01.06 - Vision deficiency"));
			rootCausesTwo.add(new SelectItem("01.07 - Hearing deficiency"));
			rootCausesTwo.add(new SelectItem("01.08 - Other sensory deficiency (touch/taste/smell/balance)"));
			rootCausesTwo.add(new SelectItem("01.09 - Respiratory incapacity"));
			rootCausesTwo.add(new SelectItem("01.10 - Other permanent physical disability"));
			rootCausesTwo.add(new SelectItem("01.11 - Temporary disability"));
			rootCausesTwo.add(new SelectItem("02.01 - Fears and phobisa"));
			rootCausesTwo.add(new SelectItem("02.02 - Emotionla disturbance"));
			rootCausesTwo.add(new SelectItem("02.03 - Mental illness"));
			rootCausesTwo.add(new SelectItem("02.04 - Intelligence level"));
			rootCausesTwo.add(new SelectItem("02.05 - Inability to comprehend"));
			rootCausesTwo.add(new SelectItem("02.06 - Poor coordination"));
			rootCausesTwo.add(new SelectItem("02.07 - Slow reaction time"));
			rootCausesTwo.add(new SelectItem("02.08 - Low mechanical aptitude"));
			rootCausesTwo.add(new SelectItem("02.09 - Low learning aptitude"));
			rootCausesTwo.add(new SelectItem("02.10 - Memory failure/lapse"));
			rootCausesTwo.add(new SelectItem("03.01 - Injury or illness"));
			rootCausesTwo.add(new SelectItem("03.02 - Fatigue due to task load or duration"));
			rootCausesTwo.add(new SelectItem("03.03 - Fatigue due to lack of rest"));
			rootCausesTwo.add(new SelectItem("03.04 - Fatigue due to sensory overload"));
			rootCausesTwo.add(new SelectItem("03.05 - Exposure to health hazard"));
			rootCausesTwo.add(new SelectItem("03.06 - Exposure to extreme temperature"));
			rootCausesTwo.add(new SelectItem("03.07 - Oxygen deficiency"));
			rootCausesTwo.add(new SelectItem("03.08 - Atmospheric pressure variation"));
			rootCausesTwo.add(new SelectItem("03.09 - Constrained movement"));
			rootCausesTwo.add(new SelectItem("03.10 - Blood sugar insufficiency"));
			rootCausesTwo.add(new SelectItem("03.11 - Alcohol/Drugs/Other Self Imposed Stress"));
			rootCausesTwo.add(new SelectItem("04.01 - Emotional overload"));
			rootCausesTwo.add(new SelectItem("04.02 - Fatigue due to mental task load or speed"));
			rootCausesTwo.add(new SelectItem("04.03 - Extreme judgment/decision demands"));
			rootCausesTwo.add(new SelectItem("04.04 - Routine/monotony demand for uneventful vigilance"));
			rootCausesTwo.add(new SelectItem("04.05 - Extreme concentration/perception demands"));
			rootCausesTwo.add(new SelectItem("04.06 - Meaningless/degrading activities"));
			rootCausesTwo.add(new SelectItem("04.07 - Confusing directions/demands"));
			rootCausesTwo.add(new SelectItem("04.08 - Conflicting demands/directions"));
			rootCausesTwo.add(new SelectItem("04.09 - Preoccupation with problems/Distractions by concern"));
			rootCausesTwo.add(new SelectItem("04.10 - Frustration"));
			rootCausesTwo.add(new SelectItem("04.11 - Mental illness"));
			rootCausesTwo.add(new SelectItem("05.01 - Inadequate experience"));
			rootCausesTwo.add(new SelectItem("05.02 - Inadequate orientation"));
			rootCausesTwo.add(new SelectItem("05.03 - Inadequate initial training"));
			rootCausesTwo.add(new SelectItem("05.04 - Inadequate update/refresher training"));
			rootCausesTwo.add(new SelectItem("05.05 - Misunderstood instruction/information"));
			rootCausesTwo.add(new SelectItem("05.06 - Lack of situational awareness/risk perception/risk awareness"));
			rootCausesTwo.add(new SelectItem("06.01 - Inadequate initial instruction/skill training"));
			rootCausesTwo.add(new SelectItem("06.02 - Inadequate practice"));
			rootCausesTwo.add(new SelectItem("06.03 - Inadequate performance"));
			rootCausesTwo.add(new SelectItem("06.04 - Inadequate coaching"));
			rootCausesTwo.add(new SelectItem("06.05 - Inadequate review instruction"));
			rootCausesTwo.add(new SelectItem("07.01 - Improper performance/behaviour is tolerated/rewarded"));
			rootCausesTwo.add(new SelectItem("07.02 - Proper performance/behaviour is discouraged/punished"));
			rootCausesTwo.add(new SelectItem("07.03 - Lack of incentive"));
			rootCausesTwo.add(new SelectItem("07.04 - Improper production incentive"));
			rootCausesTwo.add(new SelectItem("07.05 - Excessive frustration"));
			rootCausesTwo.add(new SelectItem("07.06 - Inappropriate aggression"));
			rootCausesTwo.add(new SelectItem("07.07 - Improper attempt to safe time/effort"));
			rootCausesTwo.add(new SelectItem("07.08 - Improper attempt to gain attention"));
			rootCausesTwo.add(new SelectItem("07.09 - Inadequate discipline"));
			rootCausesTwo.add(new SelectItem("07.10 - Inappropriate peer pressure"));
			rootCausesTwo.add(new SelectItem("07.11 - Improper leadership example"));
			rootCausesTwo.add(new SelectItem("07.12 - Inadequate performance feedback"));
			rootCausesTwo.add(new SelectItem("07.13 - Inadequate reinforcement of proper behaviour"));
			rootCausesTwo.add(new SelectItem("07.14 - Abuse (intentionally)"));
			rootCausesTwo.add(new SelectItem("07.15 - Misuse (unintentionally)"));
			rootCausesTwo.add(new SelectItem("08.01 - Unclear/conflicting reporting relationship"));
			rootCausesTwo.add(new SelectItem("08.02 - Unclear/conflicting assignment of function/role"));
			rootCausesTwo.add(new SelectItem("08.03 - Unclear/conflicting accountability/responsibility/task"));
			rootCausesTwo.add(new SelectItem("09.01 - Inadequate HSEO/asset strategy"));
			rootCausesTwo.add(new SelectItem("09.02 - Inadequate leadership development"));
			rootCausesTwo.add(new SelectItem("09.03 - Inadequate delegation"));
			rootCausesTwo.add(new SelectItem("09.04 - Inadequate standards"));
			rootCausesTwo.add(
					new SelectItem("09.05 - Inadequate communication/implementation of policy/procedure/practice"));
			rootCausesTwo.add(new SelectItem("09.06 - Conflicting policy/procedure/practice"));
			rootCausesTwo.add(new SelectItem("09.07 - Inadequate work/process planning/programming"));
			rootCausesTwo.add(new SelectItem("09.08 - Condone deviation form policy/procedure/practice"));
			rootCausesTwo.add(new SelectItem("09.09 - Condone misuse of equipment/tool"));
			rootCausesTwo.add(new SelectItem("09.10 - Condone improper/inappriorate behaviour"));
			rootCausesTwo.add(new SelectItem("09.11 - Inadequate management information"));
			rootCausesTwo.add(new SelectItem("10.01 - Inadequate instruction/orientation/training"));
			rootCausesTwo.add(new SelectItem("10.02 - Inadequate information document in supervision/coaching"));
			rootCausesTwo.add(new SelectItem("10.03 - Lack of supervisory/management job knowledge"));
			rootCausesTwo
					.add(new SelectItem("10.04 - Inadequate match between qualifications and job/task requirements"));
			rootCausesTwo.add(new SelectItem("10.05 - Inadequate performance measurement and evaluation"));
			rootCausesTwo.add(new SelectItem("10.06 - Inadequate performance feedback"));
			rootCausesTwo
					.add(new SelectItem("11.01 - Inadequate HSEO hazard identification/risk evaluation in design"));
			rootCausesTwo.add(new SelectItem("11.02 - Inadequate identification of failure mode"));
			rootCausesTwo.add(new SelectItem("11.03 - Inadequate evaluation of customer/stakeholder requirement"));
			rootCausesTwo.add(new SelectItem("11.04 - Inadequate identification of legal requirement"));
			rootCausesTwo.add(new SelectItem("11.05 - Inadequate consideration of human/ergonomic factor in design"));
			rootCausesTwo.add(new SelectItem("11.06 - Inadequate design process/standard/specifications/criteria"));
			rootCausesTwo.add(new SelectItem("11.07 - Inadequate process control automation"));
			rootCausesTwo
					.add(new SelectItem("11.08 - Inadequate (technical) standard/specification or absence thereof"));
			rootCausesTwo.add(new SelectItem("11.09 - Inadequate project HSEO review"));
			rootCausesTwo.add(new SelectItem("11.10 - Inadequate monitoring of construction/fabrication/assembly"));
			rootCausesTwo.add(new SelectItem("11.11 - Inadequate assessment of operational readiness"));
			rootCausesTwo.add(new SelectItem("11.12 - Inadequate commissioning/handover process"));
			rootCausesTwo.add(new SelectItem("11.13 - Inadequate monitoring of initial operation"));
			rootCausesTwo.add(new SelectItem("11.14 - Inadequate management of change"));
			rootCausesTwo.add(new SelectItem("12.01 - Inadequate specifications on requisitions/purchase order"));
			rootCausesTwo.add(new SelectItem("12.02 - Inadequate research on material/equipment/tool/supply/etc"));
			rootCausesTwo.add(new SelectItem("12.03 - Inadequate specification to vendor"));
			rootCausesTwo.add(new SelectItem("12.04 - Inadequate mode/route of shipment"));
			rootCausesTwo.add(new SelectItem("12.05 - Inadequate receiving inspection/acceptance"));
			rootCausesTwo.add(new SelectItem("12.06 - Inadequate communication of safety and health data"));
			rootCausesTwo.add(new SelectItem("12.07 - Improper handling of material"));
			rootCausesTwo.add(new SelectItem("12.08 - Improper storage of material"));
			rootCausesTwo.add(new SelectItem("12.09 - Improper transporting of material"));
			rootCausesTwo
					.add(new SelectItem("12.10 - Inadequate shelf life/validation of re-use of materials/equipment"));
			rootCausesTwo.add(new SelectItem("12.11 - Inadequate identification of material"));
			rootCausesTwo.add(new SelectItem("12.12 - Inadequate salvage/waste disposal"));
			rootCausesTwo.add(new SelectItem("12.13 - Inadequate selection of contractor/supplier"));
			rootCausesTwo.add(new SelectItem("13.01 - Inadequate assessment of preventive maintenance needs"));
			rootCausesTwo.add(new SelectItem("13.02 - Inadequate preventive lubrication and servicing"));
			rootCausesTwo.add(new SelectItem("13.03 - Inadequate adjustment/assembly"));
			rootCausesTwo.add(new SelectItem("13.04 - Inadequate preventive cleaning/resurfacing"));
			rootCausesTwo.add(new SelectItem("13.05 - Inadequate communication of corrective maintenance needs"));
			rootCausesTwo.add(new SelectItem("13.06 - Inadequate scheduling of maintenance work"));
			rootCausesTwo.add(new SelectItem("13.07 - Inadequate assessment of repair needs"));
			rootCausesTwo.add(new SelectItem("13.08 - Inadequate parts substitution/replacements"));
			rootCausesTwo.add(new SelectItem("13.09 - Inadequate inspection method/interval"));
			rootCausesTwo.add(new SelectItem("13.10 - Unable to inspect"));
			rootCausesTwo.add(new SelectItem("14.01 - Inadequate planning of use"));
			rootCausesTwo.add(new SelectItem("14.02 - Improper decision of extension of service life"));
			rootCausesTwo.add(new SelectItem("14.03 - Inadequate inspection/monitoring"));
			rootCausesTwo.add(new SelectItem("14.04 - Improper loading/rate of use"));
			rootCausesTwo.add(new SelectItem("14.05 - Used for wrong purpose/task/activity"));
			rootCausesTwo.add(new SelectItem("15.01 - Inadequate assessment of needs and risks"));
			rootCausesTwo.add(new SelectItem("15.02 - Inadequate human factors/ergonomics considerations"));
			rootCausesTwo.add(new SelectItem("15.03 - Inadequate (supplier) standards/specifications"));
			rootCausesTwo.add(new SelectItem("15.04 - Incorrect measurement/detection/(process) control"));
			rootCausesTwo.add(new SelectItem("15.05 - Inadequate availability of tool/equipment/machinery/device"));
			rootCausesTwo.add(new SelectItem("15.06 - Inadequate inspection/repair/maintenance"));
			rootCausesTwo.add(new SelectItem("15.07 - Inadequate adjustment/calibration"));
			rootCausesTwo.add(new SelectItem("15.08 - Inadequate salvage and reclamation"));
			rootCausesTwo.add(new SelectItem("15.09 - Inadequate removal and replacement of unsuitable items"));
			rootCausesTwo.add(new SelectItem("16.01 - Inadequate assessment of needs and risks"));
			rootCausesTwo.add(new SelectItem("16.02 - Inadequate product standard/specification/waiver system"));
			rootCausesTwo.add(new SelectItem("16.03 - Inadequate product design/development"));
			rootCausesTwo.add(new SelectItem("16.04 - Inadequate product standard/specification/waiver system"));
			rootCausesTwo.add(new SelectItem("16.05 - Inadequate product design validation"));
			rootCausesTwo.add(new SelectItem("16.06 - Inadequate product design verification"));
			rootCausesTwo.add(new SelectItem("16.07 - Inadequate product planning"));
			rootCausesTwo.add(new SelectItem("16.08 - Inadequate product quality verification prior to shipment"));
			rootCausesTwo.add(new SelectItem(
					"17.01 - Inadequate identification of requirements (regulatory/industry code/permit-to-operate)"));
			rootCausesTwo.add(
					new SelectItem("17.02 - Inadequate risk identification/eveluation in development of standard"));
			rootCausesTwo.add(new SelectItem("17.03 - Inadequate standard from supplier /contractor"));
			rootCausesTwo.add(
					new SelectItem("17.04 - Inadequate coordination with process design when developing standard"));
			rootCausesTwo.add(new SelectItem("17.05 - Inadequate employee involvement in developing standard"));
			rootCausesTwo.add(new SelectItem("17.06 - Conflicting standards,/improper priorization of standards"));
			rootCausesTwo.add(new SelectItem("17.07 - Inadequate publication of standard"));
			rootCausesTwo.add(new SelectItem("17.08 - Inadequate distribution of standard"));
			rootCausesTwo.add(new SelectItem("17.09 - Inadequate translation of appropriate language"));
			rootCausesTwo.add(new SelectItem("17.10 - Improper use of language"));
			rootCausesTwo.add(new SelectItem("17.11 - Inadequate training of standard"));
			rootCausesTwo.add(
					new SelectItem("17.12 - Inadequate reinforcing of standard with signs, color codes and job aids"));
			rootCausesTwo.add(new SelectItem("17.13 - Inadequate monitoring of standard compliance"));
			rootCausesTwo.add(new SelectItem("18.01 - Inadequate information handling"));
			rootCausesTwo.add(new SelectItem("18.02 - Unclear information"));
			rootCausesTwo.add(new SelectItem(
					"18.03 - Inadequate transfer of information between processes/organizational units"));
			rootCausesTwo.add(new SelectItem("18.04 - Inadequate transfer of information with client/stakeholder"));
			rootCausesTwo.add(new SelectItem("18.05 - Inadequate transfer of information with authorities"));
			rootCausesTwo.add(new SelectItem(
					"18.06 - Inadequate transfer of information with suppliers/contractors/third parties"));
			rootCausesTwo.add(new SelectItem("18.07 - Inadequate communication structure"));
			rootCausesTwo.add(new SelectItem("18.08 - Inadequate databases/information system"));
			rootCausesTwo.add(new SelectItem("18.09 - Inadequate communication method/technique used"));

			potentialRisks = new ArrayList<SelectItem>();
			potentialRisks.add(new SelectItem(null, ""));
			potentialRisks.add(new SelectItem("Process failure"));
			potentialRisks.add(new SelectItem("Ship damage / Owner property"));
			potentialRisks.add(new SelectItem("Environment"));
			potentialRisks.add(new SelectItem("Personnel"));
			potentialRisks.add(new SelectItem("Customer related property"));
			potentialRisks.add(new SelectItem("Health / Safety"));
			potentialRisks.add(new SelectItem("Reputation"));
			potentialRisks.add(new SelectItem("Financial Loss / Claim"));

			contributingFactors = new ArrayList<SelectItem>();
			contributingFactors.add(new SelectItem(null, ""));
			contributingFactors.add(new SelectItem("Adverse Weather and/or Sea Conditions"));
			contributingFactors.add(new SelectItem("Congested or restricted sailing condition"));
			contributingFactors.add(new SelectItem("Machinery / Equipment Breakdown or Failure"));
			contributingFactors.add(new SelectItem("Failure to Follow Rules and Regulations"));
			contributingFactors.add(new SelectItem("Failure to Secure / Rigging"));
			contributingFactors.add(new SelectItem("Failure to use PPE / Failure to use proper PPE"));
			contributingFactors.add(new SelectItem("Inadequate or defective PPE"));
			contributingFactors.add(new SelectItem("Improper Position for Task"));
			contributingFactors.add(new SelectItem("Improper Stepping, Handling or Lifting"));
			contributingFactors.add(new SelectItem("Inadequate Air Quality"));
			contributingFactors.add(new SelectItem("Inadequate Guards, Barriers or Warnings"));
			contributingFactors.add(new SelectItem("Inadequate or Excess Illumination (Insufficient lighting)"));
			contributingFactors.add(new SelectItem("Inadequate Preparation/Planning"));
			contributingFactors.add(new SelectItem("Inadequate Ship Security Measures"));
			contributingFactors.add(new SelectItem("Inappropriate Behavior (Unsuitable conduct)"));
			contributingFactors.add(new SelectItem("Incorrect Navigation or Ship Handling"));
			contributingFactors.add(new SelectItem("Incorrect Use of Equipment/Machinery or use without  competency"));
			contributingFactors.add(new SelectItem("Making Safety Devices Inoperative"));
			contributingFactors.add(new SelectItem("Outdated or Lack of Charts/Publications and/or Documents"));
			contributingFactors.add(new SelectItem("Poor Housekeeping"));
			contributingFactors.add(new SelectItem("External factors"));
			contributingFactors.add(new SelectItem("Under the Influence of Alcohol/Drugs/Medication"));
			contributingFactors.add(new SelectItem("Using Defective Tool(s)"));

			operationCheck1Items = new ArrayList<SelectItem>();
			operationCheck1Items.add(new SelectItem("Abbandon Ship", "Abbandon Ship"));
			operationCheck1Items.add(new SelectItem("Fire Drill", "Fire Drill"));
			operationCheck1Items.add(new SelectItem("Em'cy Fire Pump", "Em'cy Fire Pump"));
			operationCheck1Items.add(new SelectItem("Em'cy Steering", "Em'cy Steering"));
			operationCheck1Items.add(new SelectItem("Lifeboat Engine", "Lifeboat Engine"));
			operationCheck1Items.add(new SelectItem("Inert Gas System", "Inert Gas System"));
			operationCheck1Items.add(new SelectItem("Emergency Generator", "Emergency Generator"));
			operationCheck1Items.add(new SelectItem("Oily Water Separator", "Oily Water Separator"));
			operationCheck1Items.add(new SelectItem("Engine Room  Vent Shut Down", "Engine Room  Vent Shut Down"));
			operationCheck1Items.add(new SelectItem("Communication eq.", "Communication eq."));
			operationCheck1Items.add(new SelectItem("Damage control", "Damage control"));
			operationCheck1Items.add(new SelectItem("Other", "Other"));

			operationCheck2Items = new ArrayList<SelectItem>();
			operationCheck2Items.add(new SelectItem("Fireman Outfit", "Fireman Outfit"));
			operationCheck2Items
					.add(new SelectItem("International ship/Shore Connection", "International ship/Shore Connection"));
			operationCheck2Items.add(new SelectItem("Paint loker smothering system", "Paint loker smothering system"));
			operationCheck2Items.add(new SelectItem("Navigation equipment", "Navigation equipment"));
			operationCheck2Items.add(new SelectItem("EPIRB, Pyrothecnic and hydrostatic realeases",
					"EPIRB, Pyrothecnic and hydrostatic realeases"));
			operationCheck2Items.add(new SelectItem("Marine sanitation device", "Marine sanitation device"));
			operationCheck2Items
					.add(new SelectItem("Chart Publications and Corrections", "Chart Publications and Corrections"));
			operationCheck2Items.add(new SelectItem("Flame screens on Bunker and water Ballast Tanks",
					"Flame screens on Bunker and water Ballast Tanks"));
			operationCheck2Items.add(new SelectItem("Other", "Other"));

			actionCodes = new HashMap<String, String>();
			actionCodes.put("00000", "00000 None");
			actionCodes.put("01101", "01101 Cargo ship safety equipment (including exemption)");
			actionCodes.put("01102", "01102 Cargo ship safety construction (including exempt.)");
			actionCodes.put("01103", "01103 Passenger ship safety (including exemption)");
			actionCodes.put("01104", "01104 Cargo ship safety radio (including exemption)");
			actionCodes.put("01105", "01105 Cargo ship safety (including exemption)");
			actionCodes.put("01106", "01106 Document of compliance (DoC/ ISM)");
			actionCodes.put("01107", "01107 Safety management certificate (SMC/ ISM)");
			actionCodes.put("01108", "01108 Load lines (including Exemption)");
			actionCodes.put("01109", "01109 Decision-support system for masters on pass. ships");
			actionCodes.put("01110", "01110 Authorization for grain carriage");
			actionCodes.put("01111", "01111 Liquefied gases in bulk (CoF/GC Code)");
			actionCodes.put("01112", "01112 Liquefied gases in bulk (ICoF/IGC Code)");
			actionCodes.put("01113", "01113 Minimum safe manning document");
			actionCodes.put("01114", "01114 Dangerous chemicals in bulk (CoF/BCH Code)");
			actionCodes.put("01115", "01115 Dangerous chemicals in bulk (ICoF/IBC Code)");
			actionCodes.put("01116", "01116 Operational limitations for passenger ships");
			actionCodes.put("01117", "01117 International Oil Pollution Prevention (IOPP)");
			actionCodes.put("01118", "01118 Pollution prevention by noxious liquid sub in bulk");
			actionCodes.put("01119", "01119 International Sewage Pollution Prevention Cert");
			actionCodes.put("01120", "01120 Statement of Compliance CAS");
			actionCodes.put("01121", "01121 Interim Statement of Compliance CAS");
			actionCodes.put("01122", "01122 International ship security certificate");
			actionCodes.put("01123", "01123 Continuous synopsis record");
			actionCodes.put("01124", "01124 International Air Pollution Prevention Cert");
			actionCodes.put("01125", "01125 Engine International Air Pollution Prevention Cert");
			actionCodes.put("01126", "01126 Document of compliance dangerous goods");
			actionCodes.put("01127", "01127 Special purpose ship safety");
			actionCodes.put("01128", "01128 High speed craft safety and permit to operate");
			actionCodes.put("01129", "01129 Mobile offshore drilling unit safety");
			actionCodes.put("01130", "01130 INF certificate of fitness");
			actionCodes.put("01131", "01131 International AFS certificate)");
			actionCodes.put("01132", "01132 Tonnage certificate");
			actionCodes.put("01133", "01133 Civil liability for oil pollution damage cert");
			actionCodes.put("01134", "01134 Polar ship certificate");
			actionCodes.put("01135", "01135 Document for carriage of dangerous goods");
			actionCodes.put("01136", "01136 Ballast Water Management Certificate");
			actionCodes.put("01137", "01137 Civil liability for Bunker oil pollution damage cert");
			actionCodes.put("01138", "01138 International Energy Efficiency Cert");
			actionCodes.put("01139", "01139 Maritime Labour Certificate");
			actionCodes.put("01140", "01140 Declaration of Maritime Labour Compliance (Part I and II)");
			actionCodes.put("01199", "01199 Other (certificates)");
			actionCodes.put("01201", "01201 Certificates for master and officers");
			actionCodes.put("01202", "01202 Certificate for rating for watchkeeping");
			actionCodes.put("01203", "01203 Certificates for radio personnel");
			actionCodes.put("01204", "01204 Certificate for personnel on tankers");
			actionCodes.put("01205", "01205 Certificate for personnel on fast rescue boats");
			actionCodes.put("01206", "01206 Certificate for advanced fire-fighting");
			actionCodes.put("01209", "01209 Manning specified by the minimum safe manning doc");
			actionCodes.put("01210", "01210 Certificate for medical first aid");
			actionCodes.put("01211", "01211 Cert for personnel on survival craft & rescue boat");
			actionCodes.put("01212", "01212 Certificate for medical care");
			actionCodes.put("01213", "01213 Evidence of basic training");
			actionCodes.put("01214", "01214 Endorsement by flagstate");
			actionCodes.put("01215", "01215 Application for Endorsement by flagstate");
			actionCodes.put("01216", "01216 Certificate for personnel on ships subject to the IGF Code");
			actionCodes.put("01217", "01217 Ship Security Officer certificate");
			actionCodes.put("01218", "01218 Medical certificate");
			actionCodes.put("01219", "01219 Training and qualification MLC - Personnel safety training");
			actionCodes.put("01220", "01220 Seafarer employment agreement SEA");
			actionCodes.put("01221", "01221 Record of employment");
			actionCodes.put("01222", "01222 Doc evidence for personnel on passenger ships");
			actionCodes.put("01223", "01223 Security awareness training");
			actionCodes.put("01224", "01224 Certificate for rating able seafarer deck/engine and electro-technical");
			actionCodes.put("01302", "01302 SAR co-operation plan for pass.ships on fixed trade");
			actionCodes.put("01303", "01303 Unattended machinery spaces (UMS) evidence");
			actionCodes.put("01304", "01304 Declaration of AFS compliance");
			actionCodes.put("01305", "01305 Log-books/compulsory entries");
			actionCodes.put("01306", "01306 Shipboard working arrangements");
			actionCodes.put("01307", "01307 Maximum hours of work or the minimum hours of rest");
			actionCodes.put("01308", "01308 Records of seafarers' daily hours of work or rest");
			actionCodes.put("01309", "01309 Fire control plan - all");
			actionCodes.put("01310", "01310 Signs, indications");
			actionCodes.put("01311", "01311 Survey report file");
			actionCodes.put("01312", "01312 Thickness measurement report");
			actionCodes.put("01313", "01313 Booklet for bulk cargo loading/unloading/stowage");
			actionCodes.put("01314", "01314 Shipboard oil pollution emergency plan (SOPEP)");
			actionCodes.put("01315", "01315 Oil record book");
			actionCodes.put("01316", "01316 Cargo information");
			actionCodes.put("01317", "01317 Cargo record book");
			actionCodes.put("01318", "01318 P & A manual");
			actionCodes.put("01319", "01319 Shipboard mar. poll. Emergency plan (MPEP) for NLS");
			actionCodes.put("01320", "01320 Garbage record book");
			actionCodes.put("01322", "01322 Conformance Test Report");
			actionCodes.put("01323", "01323 Fire safety operational booklet");
			actionCodes.put("01324", "01324 Material safety data sheets");
			actionCodes.put("01325", "01325 ACM statement of compliance (including exemption)");
			actionCodes.put("01326", "01326 Stability Information Booklet");
			actionCodes.put("01327", "01327 Energy Efficiency Design Index File");
			actionCodes.put("01328", "01328 Ship Energy Efficiency Management plan");
			actionCodes.put("01329", "01329 Report of inspection on MLC, 2006");
			actionCodes.put("01330", "01330 Procedure for complaint under MLC, 2006");
			actionCodes.put("01331", "01331 Collective bargaining agreement");
			actionCodes.put("01332", "01332 AIS test report");
			actionCodes.put("01333", "01333 Ship specific plans for the recovery of persons from the water");
			actionCodes.put("01334", "01334 STS Operation Plan and Records of STS Operations");
			actionCodes.put("01335", "01335 Polar Water Operational Manual");
			actionCodes.put("01336",
					"01336 Certificate or documentary evidence of financial security for repatriation");
			actionCodes.put("01337",
					"01337 Certificate or documentary evidence of financial security relating to shipowners liability");
			actionCodes.put("01338", "01338 LNG Bunker Delivery Note");
			actionCodes.put("01339", "01339 Copy of IGF Code or national legislation");
			actionCodes.put("02101", "02101 Closing devices/watertight doors");
			actionCodes.put("02102", "02102 Damage control plan");
			actionCodes.put("02103", "02103 Stability/strenght/loading information and instruments");
			actionCodes.put("02104", "02104 Information on the A/A-max ratio (Roro/pass.only)");
			actionCodes.put("02105", "02105 Steering gear");
			actionCodes.put("02106", "02106 Hull damage impairing seaworthiness");
			actionCodes.put("02107", "02107 Ballast, fuel and other tanks");
			actionCodes.put("02108", "02108 Electric equipment in general");
			actionCodes.put("02109", "02109 Permanent means of access");
			actionCodes.put("02110", "02110 Beams, frames, floors-op.damage");
			actionCodes.put("02111", "02111 Beams, frames, floors-corrosion");
			actionCodes.put("02112", "02112 Hull - corrosion");
			actionCodes.put("02113", "02113 Hull - cracking");
			actionCodes.put("02114", "02114 Bulkhead �corrosion");
			actionCodes.put("02115", "02115 Bulkheads - operational damage");
			actionCodes.put("02116", "02116 Bulkheads � cracking");
			actionCodes.put("02117", "02117 Decks � corrosion");
			actionCodes.put("02118", "02118 Decks � cracking");
			actionCodes.put("02119", "02119 Enhanced survey programme (ESP)");
			actionCodes.put("02120", "02120 Marking of IMO number");
			actionCodes.put("02121", "02121 Cargo area segregation");
			actionCodes.put("02122", "02122 Openings to cargo area, doors, �, scuttles");
			actionCodes.put("02123", "02123 Wheelhouse door,window");
			actionCodes.put("02124", "02124 Cargo pump room");
			actionCodes.put("02125", "02125 Spaces in cargo areas");
			actionCodes.put("02126", "02126 Cargo tank vent system");
			actionCodes.put("02127", "02127 Safe access to tanker bows");
			actionCodes.put("02128", "02128 Bulk carriers additional safety measures");
			actionCodes.put("02129", "02129 Bulkhead strength");
			actionCodes.put("02130", "02130 Triangle mark");
			actionCodes.put("02132", "02132 Water level detectors on single hold cargo ships");
			actionCodes.put("02133", "02133 Asbestos containing materials");
			actionCodes.put("02134", "02134 Loading/Ballast condition (Tanker)");
			actionCodes.put("02199", "02199 Other (Structural condition)");
			actionCodes.put("03101", "03101 Overloading");
			actionCodes.put("03102", "03102 Freeboard marks");
			actionCodes.put("03103", "03103 Railing, gangway, walkway and means for safe passage");
			actionCodes.put("03104", "03104 Cargo and other hatchways");
			actionCodes.put("03105", "03105 Covers (hatchway-, portable-, tarpaulins, etc.)");
			actionCodes.put("03106", "03106 Windows, side scuttles and deadlights");
			actionCodes.put("03107", "03107 Doors");
			actionCodes.put("03108", "03108 Ventilators, air pipes, casings");
			actionCodes.put("03109", "03109 Machinery space openings");
			actionCodes.put("03110", "03110 Manholes / flush scuttles");
			actionCodes.put("03111", "03111 Cargo ports and other similar openings");
			actionCodes.put("03112", "03112 Scuppers, inlets and discharges");
			actionCodes.put("03113", "03113 Bulwarks and freeing ports");
			actionCodes.put("03114", "03114 Stowage incl. uprights, lashing, etc (timber)");
			actionCodes.put("03199", "03199 Other (load lines)");
			actionCodes.put("04101", "04101 Public address system");
			actionCodes.put("04102", "04102 Emergency fire pump and its pipes");
			actionCodes.put("04103", "04103 Emergency lighting, batteries and switches");
			actionCodes.put("04104", "04104 Low level lighting in corridors");
			actionCodes.put("04105", "04105 Location of emergency installations");
			actionCodes.put("04106", "04106 Emergency steering position communications/ compass reading");
			actionCodes.put("04107", "04107 Emergency towing arrangements and procedures");
			actionCodes.put("04108", "04108 Muster list");
			actionCodes.put("04109", "04109 Fire drills");
			actionCodes.put("04110", "04110 Abandon ship drills");
			actionCodes.put("04111", "04111 Damage control plan");
			actionCodes.put("04112", "04112 Shipboard Marine Pollution emergency operations");
			actionCodes.put("04113", "04113 Water level indicator");
			actionCodes.put("04114", "04114 Emergency source of power - Emergency generator");
			actionCodes.put("04115", "04115 Safe areas");
			actionCodes.put("04116", "04116 Means of communication between safety centre and other control stations");
			actionCodes.put("04117", "04117 Functionality of Safety Systems");
			actionCodes.put("04118", "04118 Enclosed space entry and rescue drills");
			actionCodes.put("04119", "04119 IGF Code Drills and Emergency Exercises");
			actionCodes.put("05101", "05101 Distress messages: obligations and procedures");
			actionCodes.put("05102", "05102 Functional requirements");
			actionCodes.put("05103", "05103 Main installation");
			actionCodes.put("05104", "05104 MF radio installation");
			actionCodes.put("05105", "05105 MF/HF radio installation");
			actionCodes.put("05106", "05106 INMARSAT ship earth station");
			actionCodes.put("05107", "05107 Maintenance / duplication of equipment");
			actionCodes.put("05108", "05108 Performance standards for radio equipment");
			actionCodes.put("05109", "05109 VHF radio installation");
			actionCodes.put("05110", "05110 Facilities for reception of marine safety information");
			actionCodes.put("05111", "05111 Satellite EPIRB 406MHz / 1.6 GHz");
			actionCodes.put("05112", "05112 VHF EPIRB");
			actionCodes.put("05113", "05113 SART/AIS-SART");
			actionCodes.put("05114", "05114 Reserve source of energy");
			actionCodes.put("05115", "05115 Radio log (diary)");
			actionCodes.put("05116", "05116 Operation/maintenance");
			actionCodes.put("05118", "05118 Operation of GMDSS equipment");
			actionCodes.put("05199", "05199 Other (radio communication)");
			actionCodes.put("06101", "06101 Cargo securing manual");
			actionCodes.put("06102", "06102 Grain");
			actionCodes.put("06103", "06103 Other cargo - timber -deck/construction");
			actionCodes.put("06104", "06104 Lashing material");
			actionCodes.put("06105", "06105 Atmosphere testing instruments");
			actionCodes.put("06106", "06106 Cargo transfer - Tankers");
			actionCodes.put("06107", "06107 Cargo operation");
			actionCodes.put("06108", "06108 Cargo density declaration");
			actionCodes.put("06199", "06199 Other (cargo)");
			actionCodes.put("07101", "07101 Fire prevention structural integrity");
			actionCodes.put("07102", "07102 Inert gas system");
			actionCodes.put("07103", "07103 Division � decks, bulkheads and penetrations");
			actionCodes.put("07104", "07104 Main vertical zone");
			actionCodes.put("07105", "07105 Fire doors/openings in fire-resisting divisions");
			actionCodes.put("07106", "07106 Fire detection");
			actionCodes.put("07108", "07108 Ready availability of fire fighting equipment");
			actionCodes.put("07109", "07109 Fixed fire extinguishing installation");
			actionCodes.put("07110", "07110 Fire fighting equipment and appliances");
			actionCodes.put("07111", "07111 Personal equipment");
			actionCodes.put("07112", "07112 Emergency escape breathing Device and disposition");
			actionCodes.put("07113", "07113 Fire pumps and its pipes");
			actionCodes.put("07114", "07114 Means of control (opening, pumps) Machinery spaces");
			actionCodes.put("07115", "07115 Fire-dampers");
			actionCodes.put("07116", "07116 Ventilation");
			actionCodes.put("07117", "07117 Jacketed high pressure lines and oil leakage alarm");
			actionCodes.put("07118", "07118 International shore-connection");
			actionCodes.put("07120", "07120 Means of escape");
			actionCodes.put("07121", "07121 Crew alarm");
			actionCodes.put("07122", "07122 Fire control plan");
			actionCodes.put("07123", "07123 Operation of Fire protection systems");
			actionCodes.put("07124", "07124 Maintenance of Fire protection systems");
			actionCodes.put("07125", "07125 Evaluation of crew performance (fire drills)");
			actionCodes.put("07199", "07199 Other (fire safety)");
			actionCodes.put("08101", "08101 General alarm");
			actionCodes.put("08102", "08102 Emergency signal");
			actionCodes.put("08103", "08103 Fire alarm");
			actionCodes.put("08104", "08104 Steering-gear alarm");
			actionCodes.put("08105", "08105 Engineer s alarm");
			actionCodes.put("08106", "08106 Inert gas alarm");
			actionCodes.put("08107", "08107 Machinery controls alarm");
			actionCodes.put("08108", "08108 UMS-alarms");
			actionCodes.put("08109", "08109 Boiler-alarm");
			actionCodes.put("08110", "08110 Closing watertight doors alarm");
			actionCodes.put("08199", "08199 Other (alarms)");
			actionCodes.put("09101", "09101 Minimum age");
			actionCodes.put("09102", "09102 Dirty, parasites");
			actionCodes.put("09103", "09103 Ventilation (Accommodation)");
			actionCodes.put("09104", "09104 Heating");
			actionCodes.put("09105", "09105 Noise");
			actionCodes.put("09106", "09106 Sanitary facilities");
			actionCodes.put("09107", "09107 Drainage");
			actionCodes.put("09108", "09108 Lighting (Accommodation)");
			actionCodes.put("09109", "09109 Pipes, wires (insulation)");
			actionCodes.put("09110", "09110 Electrical devices");
			actionCodes.put("09111", "09111 Sickbay");
			actionCodes.put("09112", "09112 Medical equipment");
			actionCodes.put("09113", "09113 Access/structure");
			actionCodes.put("09114", "09114 Sleeping room");
			actionCodes.put("09115", "09115 No direct openings into sleeping rooms cargo/mach");
			actionCodes.put("09116", "09116 Furnishings");
			actionCodes.put("09117", "09117 Berth dimensions, etc");
			actionCodes.put("09118", "09118 Clear head");
			actionCodes.put("09119", "09119 Messroom (location)");
			actionCodes.put("09120", "09120 Oil skin locker");
			actionCodes.put("09121", "09121 Laundry");
			actionCodes.put("09122", "09122 Record of inspection (Accommodation)");
			actionCodes.put("09124", "09124 Galley, handlingroom (maintenance)");
			actionCodes.put("09127", "09127 Cleanliness");
			actionCodes.put("09128", "09128 Provisions quantity");
			actionCodes.put("09129", "09129 Provisions quality");
			actionCodes.put("09130", "09130 Water, pipes, tanks");
			actionCodes.put("09131", "09131 Cold room");
			actionCodes.put("09132", "09132 Cold room temperature");
			actionCodes.put("09133", "09133 Cold room cleanliness");
			actionCodes.put("09134", "09134 Food personal hygiene");
			actionCodes.put("09135", "09135 Food temperature");
			actionCodes.put("09136", "09136 Food segregation");
			actionCodes.put("09137", "09137 Record of inspection");
			actionCodes.put("09138", "09198 Other (crew and accommodation)");
			actionCodes.put("09199", "09199 Other (food)");
			actionCodes.put("09201", "09201 Ventilation (Working spaces)");
			actionCodes.put("09202", "09202 Heating");
			actionCodes.put("09203", "09203 Lighting (Working spaces)");
			actionCodes.put("09204", "09204 Safe means of access");
			actionCodes.put("09205", "09205 Safe means of access shore � ship");
			actionCodes.put("09206", "09206 Safe means of access deck - hold/tank, etc");
			actionCodes.put("09207", "09207 Obstruction/slipping, etc");
			actionCodes.put("09208", "09208 Protection machinery");
			actionCodes.put("09209", "09209 Electrical");
			actionCodes.put("09210", "09210 Machinery");
			actionCodes.put("09211", "09211 Steam pipes and pressure pipes");
			actionCodes.put("09212", "09212 Danger areas");
			actionCodes.put("09213", "09213 Gas instruments");
			actionCodes.put("09214", "09214 Emergency cleaning devices");
			actionCodes.put("09216", "09216 Personal equipment");
			actionCodes.put("09217", "09217 Warning notices");
			actionCodes.put("09218", "09218 Protection machines/parts");
			actionCodes.put("09219", "09219 Pipes, wires (insulation)");
			actionCodes.put("09220", "09220 Structural features (ship)");
			actionCodes.put("09221", "09221 Entry dangerous spaces");
			actionCodes.put("09223", "09223 Gangway, accommodation-ladder");
			actionCodes.put("09224", "09224 Stowage of cargo");
			actionCodes.put("09225", "09225 Loading and unloading equipment");
			actionCodes.put("09226", "09226 Holds and tanks safety");
			actionCodes.put("09227", "09227 Ropes and wires");
			actionCodes.put("09228", "09228 Anchoring devices");
			actionCodes.put("09229", "09229 Winches and capstans");
			actionCodes.put("09230", "09230 Adequate lighting - mooring arrangements");
			actionCodes.put("09232", "09232 Cleanliness of engine room");
			actionCodes.put("09233", "09233 Guards / fencing around dangerous machinery parts");
			actionCodes.put("09234", "09234 Night working for seafarer under the age of 18");
			actionCodes.put("09235", "09235 Fitness for duty � work and rest hours");
			actionCodes.put("09236", "09236 Legal documentation on work and rest hours");
			actionCodes.put("09237", "09237 Fitness for duty � intoxication");
			actionCodes.put("09297", "09297 Other (working space ILO)");
			actionCodes.put("09298", "09298 Other (accident prevention)");
			actionCodes.put("09299", "09299 Other (mooring)");
			actionCodes.put("10101", "10101 Pilot ladders and hoist/pilot transfer arrangements");
			actionCodes.put("10102", "10102 Type approval equipment");
			actionCodes.put("10103", "10103 Radar");
			actionCodes.put("10104", "10104 Gyro compass");
			actionCodes.put("10105", "10105 Magnetic compass");
			actionCodes.put("10106", "10106 Compass correction log");
			actionCodes.put("10107", "10107 Automatic radar plotting aid (ARPA)");
			actionCodes.put("10109", "10109 Lights, shapes, sound-signals");
			actionCodes.put("10110", "10110 Signalling lamp");
			actionCodes.put("10111", "10111 Charts");
			actionCodes.put("10112", "10112 Electronic charts (ECDIS)");
			actionCodes.put("10113", "10113 Automatic Identification System (AIS)");
			actionCodes.put("10114", "10114 Voyage Data Recorder (VDR) / Simplified Voyage Data Recorder (S-VDR)");
			actionCodes.put("10115", "10115 GNSS receiver/terrestrial radio navigation system");
			actionCodes.put("10116", "10116 Nautical publications");
			actionCodes.put("10117", "10117 Echo sounder");
			actionCodes.put("10118", "10118 Speed and distance indicator");
			actionCodes.put("10119", "10119 Rudder angle indicator");
			actionCodes.put("10120", "10120 Revolution counter");
			actionCodes.put("10121", "10121 Variable pitch indicator");
			actionCodes.put("10122", "10122 Rate-of-turn indicator");
			actionCodes.put("10123", "10123 International code of signals- SOLAS");
			actionCodes.put("10124", "10124 Life-saving signals");
			actionCodes.put("10125", "10125 Use of the automatic pilot");
			actionCodes.put("10126", "10126 Records of drills and steering gear tests");
			actionCodes.put("10127", "10127 Voyage or passage plan");
			actionCodes.put("10128", "10128 Navigation bridge visibility");
			actionCodes.put("10129", "10129 Navigation records");
			actionCodes.put("10132", "10132 Communication - SOLAS Chapter V");
			actionCodes.put("10133", "10133 Bridge operation");
			actionCodes.put("10134", "10134 HSC operation");
			actionCodes.put("10135", "10135 Monitoring of voyage or passage plan");
			actionCodes.put("10136", "10136 Establishment of working language on board");
			actionCodes.put("10137", "10137 Long-Range Identification and Tracking system (LRIT)");
			actionCodes.put("10138", "10138 Bridge Navigational Watch Alarm System (BNWAS)");
			actionCodes.put("10199", "10199 Other (navigation)");
			actionCodes.put("11101", "11101 Lifeboats");
			actionCodes.put("11102", "11102 Lifeboat inventory");
			actionCodes.put("11103", "11103 Stowage and provision of lifeboats");
			actionCodes.put("11104", "11104 Rescue boats");
			actionCodes.put("11105", "11105 Rescue boat inventory");
			actionCodes.put("11106", "11106 Fast rescue boats");
			actionCodes.put("11107", "11107 Stowage of rescue boats");
			actionCodes.put("11108", "11108 Inflatable liferafts");
			actionCodes.put("11109", "11109 Rigid liferafts");
			actionCodes.put("11110", "11110 Stowage of liferafts");
			actionCodes.put("11111", "11111 Marine evacuation system");
			actionCodes.put("11112", "11111 Marine evacuation system");
			actionCodes.put("11113", "11113 Launching arrangements for rescue boats");
			actionCodes.put("11114", "11114 Helicopter landing and pick-up area");
			actionCodes.put("11115", "11115 Means of rescue");
			actionCodes.put("11116", "11116 Distress flares");
			actionCodes.put("11117", "11117 Lifebuoys incl. provision and disposition");
			actionCodes.put("11118", "11118 Lifejackets incl. provision and disposition");
			actionCodes.put("11119", "11119 Immersion suits");
			actionCodes.put("11120", "11120 Anti-exposure suits");
			actionCodes.put("11121", "11121 Thermal Protective Aids");
			actionCodes.put("11122", "11122 Radio life-saving appliances");
			actionCodes.put("11123", "11123 Emergency equipment for 2-way comm");
			actionCodes.put("11124", "11124 Embarkation arrangement survival craft");
			actionCodes.put("11125", "11125 Embarkation arrangements rescue boats");
			actionCodes.put("11126", "11126 Means of recovery of life saving appliances");
			actionCodes.put("11127", "11127 Buoyant apparatus");
			actionCodes.put("11128", "11128 Line-throwing appliance");
			actionCodes.put("11129", "11129 Operational readiness of lifesaving appliances");
			actionCodes.put("11130", "11130 Evaluation, testing and approval");
			actionCodes.put("11131", "11131 On board training and instructions");
			actionCodes.put("11132", "11132 Maintenance and inspections");
			actionCodes.put("11133", "11133 Personal and group survival equipment");
			actionCodes.put("11134", "11134 Operation of Life Saving Appliances");
			actionCodes.put("11135", "11135 Maintenance of Life Saving Appliances");
			actionCodes.put("11199", "11199 Other (life saving)");
			actionCodes.put("12101", "12101 Stowage/segregation/packaging of dangerous goods");
			actionCodes.put("12102", "12102 Dangerous liquid chemicals in bulk");
			actionCodes.put("12103", "12103 Liquefied gases in bulk");
			actionCodes.put("12104", "12104 Dangerous goods code");
			actionCodes.put("12105", "12105 Temperature control");
			actionCodes.put("12106", "12106 Instrumentation");
			actionCodes.put("12107", "12107 Fire protection cargo deck area");
			actionCodes.put("12108", "12108 Personal protection");
			actionCodes.put("12109", "12109 Special requirements");
			actionCodes.put("12110", "12110 Tank entry");
			actionCodes.put("12112", "12112 Dangerous goods or harmful substances in pack. Form");
			actionCodes.put("12199", "12199 Other (tankers)");
			actionCodes.put("13101", "13101 Propulsion main engine");
			actionCodes.put("13102", "13102 Auxiliary engine");
			actionCodes.put("13103", "13103 Gauges, thermometers etc");
			actionCodes.put("13104", "13104 Bilge pumping arrangements");
			actionCodes.put("13105", "13105 UMS-ship");
			actionCodes.put("13106", "13106 Insulation wetted through (oil)");
			actionCodes.put("13107", "13107 Maintenance procedures for all gas related installations");
			actionCodes.put("13108", "13108 Operation of machinery");
			actionCodes.put("13199", "13199 Other (machinery)");
			actionCodes.put("14101", "14101 Control of discharge of oil");
			actionCodes.put("14102", "14102 Retention of oil on board");
			actionCodes.put("14103", "14103 Segregation of oil and water ballast");
			actionCodes.put("14104", "14104 Oil filtering equipment");
			actionCodes.put("14105", "14105 Pumping, piping and discharge arrangements");
			actionCodes.put("14106", "14106 Pump room bottom protection");
			actionCodes.put("14107", "14107 Oil discharge monitoring and control system");
			actionCodes.put("14108", "14108 15 PPM alarm arrangements");
			actionCodes.put("14109", "14109 Oil / water interface detector");
			actionCodes.put("14110", "14110 Standard discharge connection");
			actionCodes.put("14111", "14111 SBT, CBT, COW");
			actionCodes.put("14112", "14112 COW operations and equipment manual");
			actionCodes.put("14113", "14113 Double hull construction");
			actionCodes.put("14114", "14114 Hydrostatically balanced loading");
			actionCodes.put("14115", "14115 Condition Assessment Scheme");
			actionCodes.put("14116", "14116 Pollution report - MARPOL Annex I");
			actionCodes.put("14117", "14117 Ship type designation");
			actionCodes.put("14119", "14119 Oil and oily mixtures from machinery spaces");
			actionCodes.put("14120", "14120 Loading, unloading & cleaning procedures cargo spaces of tankers");
			actionCodes.put("14121", "14121 Suspected of discharge violation");
			actionCodes.put("14199", "14199 Other (MARPOL Annex I)");
			actionCodes.put("14201", "14201 Efficient stripping");
			actionCodes.put("14202", "14202 Residue discharge systems");
			actionCodes.put("14203", "14203 Tank washing equipment");
			actionCodes.put("14204", "14204 Prohibited discharge of NLS slops");
			actionCodes.put("14205", "14205 Cargo heating systems - cat. Y substances");
			actionCodes.put("14206", "14206 Ventilation procedures / equipment");
			actionCodes.put("14207", "14207 Pollution report - MARPOL Annex II");
			actionCodes.put("14208", "14208 Ship type designation");
			actionCodes.put("14299", "14299 Other (MARPOL Annex II)");
			actionCodes.put("14301", "14301 Packaging");
			actionCodes.put("14302", "14302 Marking and labelling");
			actionCodes.put("14303", "14303 Documentation (MARPOL Annex III)");
			actionCodes.put("14304", "14304 Stowage");
			actionCodes.put("14399", "14399 Other (MARPOL - Annex III)");
			actionCodes.put("14402", "14402 Sewage treatment plan");
			actionCodes.put("14403", "14403 Sewage comminuting and disinfecting system");
			actionCodes.put("14404", "14404 Sewage discharge connection");
			actionCodes.put("14499", "14499 Other (MARPOL Annex IV)");
			actionCodes.put("14501", "14501 Garbage");
			actionCodes.put("14502", "14502 Placards");
			actionCodes.put("14503", "14503 Garbage management plan");
			actionCodes.put("14599", "14599 Other (MARPOL Annex V)");
			actionCodes.put("14601", "14601 Technical Files and if applicable, monitoring manual");
			actionCodes.put("14602", "14602 Record book engine parameters");
			actionCodes.put("14603", "14603 Approved doc exhaust gas cleaning system");
			actionCodes.put("14604", "14604 Bunker delivery notes");
			actionCodes.put("14605", "14605 Type approval certificate of incinerator");
			actionCodes.put("14606", "14606 Diesel engine air pollution control");
			actionCodes.put("14607", "14607 Quality of fuel oil");
			actionCodes.put("14608", "14608 Incinerator incl. operations and operating manual");
			actionCodes.put("14609", "14609 Volatile Organic compounds in tankers");
			actionCodes.put("14610", "14610 Operational proc. for engines or equipment");
			actionCodes.put("14611", "14611 Ozone depleting substances");
			actionCodes.put("14612", "14612 SOx records");
			actionCodes.put("14613", "14613 Approved method");
			actionCodes.put("14614", "14614 Sulphur oxides");
			actionCodes.put("14615", "14615 Fuel change-over procedure");
			actionCodes.put("14616", "14616 Alternative arrangements");
			actionCodes.put("14617", "14617 Sulphur content of fuel used");
			actionCodes.put("14699", "14699 Other (MARPOL ANNEX VI)");
			actionCodes.put("14701", "14701 AFS supporting documentation");
			actionCodes.put("14702", "14702 Logbook entries referring AFS");
			actionCodes.put("14703", "14703 Paint condition");
			actionCodes.put("14799", "14799 Other (AFS)");
			actionCodes.put("14801", "14801 Ballast Water Management Plan");
			actionCodes.put("14802", "14802 Ballast Water Record Book");
			actionCodes.put("14803", "14803 Construction dates applicable for BWM");
			actionCodes.put("14804", "14804 Ballast Water Exchange");
			actionCodes.put("14805", "14805 Sediment removal and disposal");
			actionCodes.put("14806", "14806 Crew Training and familiarization");
			actionCodes.put("14809", "14809 Conditions for exemptions");
			actionCodes.put("14810", "14810 Ballast Water Discharge violation in port");
			actionCodes.put("14811", "14811 Ballast Water Management System");
			actionCodes.put("14899", "14899 Other (BWM)");
			actionCodes.put("15150", "15150 ISM");
			actionCodes.put("16101", "16101 Security related defects");
			actionCodes.put("16102", "16102 Ship security alert system");
			actionCodes.put("16103", "16103 Ship security plan");
			actionCodes.put("16104", "16104 Ship security officer");
			actionCodes.put("16105", "16105 Access control to ship");
			actionCodes.put("16106", "16106 Security drills");
			actionCodes.put("16199", "16199 Other (maritime security)");
			actionCodes.put("18101", "18101 Minimum age");
			actionCodes.put("18102", "18102 Night working");
			actionCodes.put("18103", "18103 Medical fitness");
			actionCodes.put("18104", "18104 Recruitment and placement service");
			actionCodes.put("18199", "18199 Other (Minimum requirements)");
			actionCodes.put("18201", "18201 Fitness for duty - work and rest hours");
			actionCodes.put("18202", "18202 Legal documentation on work and rest hours");
			actionCodes.put("18203", "18203 Wages");
			actionCodes.put("18204", "18204 Calculation and payment");
			actionCodes.put("18205", "18205 Measures to ensure transmission to seafarer s family");
			actionCodes.put("18299", "18299 Other (Conditions of employment)");
			actionCodes.put("18301", "18301 Noise, vibration and other ambient factors");
			actionCodes.put("18302", "18302 Sanitary Facilities");
			actionCodes.put("18303", "18303 Drainage");
			actionCodes.put("18304", "18304 Lighting (Accommodation)");
			actionCodes.put("18305", "18305 Hospital accommodation (Sickbay)");
			actionCodes.put("18306", "18306 Sleeping room, additional spaces");
			actionCodes.put("18307", "18307 Direct openings into sleeping rooms cargo/mach");
			actionCodes.put("18308", "18308 Furnishings");
			actionCodes.put("18309", "18309 Berth dimensions, etc");
			actionCodes.put("18310", "18310 Minimum headroom");
			actionCodes.put("18311", "18311 Mess room and recreational facilities");
			actionCodes.put("18312", "18312 Galley, handlingroom (maintenance)");
			actionCodes.put("18313", "18313 Cleanliness");
			actionCodes.put("18314", "18314 Provisions quantity");
			actionCodes.put("18315", "18315 Provisions quality and nutritional value");
			actionCodes.put("18316", "18316 Water, pipes, tanks");
			actionCodes.put("18317", "18317 Food personal hygiene");
			actionCodes.put("18318", "18318 Food temperature");
			actionCodes.put("18319", "18319 Food segregation");
			actionCodes.put("18320", "18320 Record of inspection (food and catering)");
			actionCodes.put("18321", "18321 Heating, air conditioning and ventilation");
			actionCodes.put("18322", "18322 Insulation");
			actionCodes.put("18323", "18323 Office");
			actionCodes.put("18324", "18324 Cold room, cold room cleanliness, cold room temperature");
			actionCodes.put("18325", "18325 Training and qualification of ship s cook");
			actionCodes.put("18326", "18326 Laundry, Adequate Locker");
			actionCodes.put("18327", "18327 Ventilation (Working spaces)");
			actionCodes.put("18328", "18328 Record of inspection");
			actionCodes.put("18399", "18399 Other (Accommodation, recreational facilities�)");
			actionCodes.put("18401", "18401 Medical Equipment, medical chest, medical guide");
			actionCodes.put("18402", "18402 Access to on shore medical doctor or dentist");
			actionCodes.put("18403", "18403 Standard medical report form");
			actionCodes.put("18404", "18404 Medical doctor or person in charge of medical care");
			actionCodes.put("18405", "18405 Medical advice by radio or satellite");
			actionCodes.put("18406", "18406 Medical care onboard or ashore free of charge");
			actionCodes.put("18407", "18407 Lighting (Working spaces)");
			actionCodes.put("18408", "18408 Electrical");
			actionCodes.put("18409", "18409 Dangerous areas");
			actionCodes.put("18410", "18410 Gas instruments");
			actionCodes.put("18411", "18411 Emergency cleaning devices");
			actionCodes.put("18412", "18412 Personal equipment");
			actionCodes.put("18413", "18413 Warning notices");
			actionCodes.put("18414", "18414 Protection machines/parts");
			actionCodes.put("18415", "18415 Entry dangerous spaces");
			actionCodes.put("18416", "18416 Ropes and wires");
			actionCodes.put("18417", "18417 Anchoring devices");
			actionCodes.put("18418", "18418 Winches & capstans");
			actionCodes.put("18419", "18419 Adequate lighting - mooring arrangements");
			actionCodes.put("18420", "18420 Cleanliness of engine room");
			actionCodes.put("18421", "18421 Guards - fencing around dangerous machinery parts");
			actionCodes.put("18422", "18422 Asbestos fibres");
			actionCodes.put("18423", "18423 Preventative information");
			actionCodes.put("18424", "18424 Steam pipes, pressure pipes, wires (insulation)");
			actionCodes.put("18425", "18425 Access / structural features (ship)");
			actionCodes.put("18426", "18426 Exposure to harmful levels of ambient factors");
			actionCodes.put("18427", "18427 Ship s occupational safety and health policies and programmes");
			actionCodes.put("18428",
					"18428 On board programme for the prevention of occupational injuries and diseases");
			actionCodes.put("18429",
					"18429 Procedure for inspection, reporting and correcting unsafe conditions and for investigating and reporting on-board occupational accidents");
			actionCodes.put("18430", "18430 Ship s safety committee");
			actionCodes.put("18431", "18431 Investigation after accident");
			actionCodes.put("18432", "18432 Risk evaluation, training and instruction to seafarers");
			actionCodes.put("18499", "18499 Other (Health protection, medical care�)");
			actionCodes.put("99101", "99101 Other safety in general");
			actionCodes.put("99102", "99102 Other (SOLAS operational)");
			actionCodes.put("99103", "99103 Other (MARPOL operational)");
			/* ADD */
			/*
			 * actionCodes.put("0117", "0117 safety management certificate(SMC/ISM Code)");
			 * actionCodes.put("0120", "0120 load lines (including exemption)");
			 * actionCodes.put("0130", "0130 liquefied gases in bulk (CoF/GC Code)");
			 * actionCodes.put("0131", "0131 liquefied gases in bulk (CoF/GC Code)");
			 * actionCodes.put("0135", "0135 safe manning document");
			 * actionCodes.put("0140", "0140 dangerous chemical in bulk (CoF/BC Code)");
			 * actionCodes.put("0141", "0141 dangerous chemical in bulk (CoF/IBC Code)");
			 * actionCodes.put("0150", "0150 prevention of pollution By oil (IOPP)");
			 * actionCodes.put("0155",
			 * "0155 pollution prevention noxious liquid substances in bulk");
			 * actionCodes.put("0170", "0170 document of compliance dangerous goods");
			 * actionCodes.put("0171", "0171 document of compliance dangerous goods");
			 * actionCodes.put("0172", "0172 high speed craft"); actionCodes.put("0173",
			 * "0173 mobile offshore drilling unit safety"); actionCodes.put("0180",
			 * "0180 tonnage certificate"); actionCodes.put("0190",
			 * "0190 logbooks/compulsory entries"); actionCodes.put("0197",
			 * "0197 ISM certification in general"); actionCodes.put("0199",
			 * "0199 other (certificates)"); actionCodes.put("0000", "0000 none");
			 * actionCodes.put("0100",
			 * "0100 deficiencies which are clearly hazardous to safety, he");
			 * actionCodes.put("9800", "9800 9800 environment"); actionCodes.put("0100",
			 * "0100 0100 ship's certificates / logbooks"); actionCodes.put("0110",
			 * "0110 cargo ship safety equipment"); actionCodes.put("0111",
			 * "0111 cargo ship safety construction"); actionCodes.put("0112",
			 * "0112 passenger ship safety (including exemption)"); actionCodes.put("0013",
			 * "0013 cargo ship safety radio"); actionCodes.put("0114",
			 * "0114 cargo ship safety"); actionCodes.put("0200",
			 * "0200 training, certification and watchkeeping for seafarers");
			 * actionCodes.put("0221", "0221 certificates for masters and officers");
			 * actionCodes.put("0222", "0222 certificates for rating for watchkeeping");
			 * actionCodes.put("0223", "0223 certificates for radio personnel");
			 * actionCodes.put("0224", "0224 certificate for personnel on tankers");
			 * actionCodes.put("0226",
			 * "0226 certificate for personnel on fast rescue boats");
			 * actionCodes.put("0227", "0227 certificate for advance fire-fighting");
			 * actionCodes.put("0229",
			 * "0229 documentary evidence for personnel on ro-ro passenger ships");
			 * actionCodes.put("0230",
			 * "0230 manning specified by the minimum sage manning document");
			 * actionCodes.put("0241", "0241 certificate for medical first aid");
			 * actionCodes.put("0250",
			 * "0250 certificate for personnel on survival craft and rescue boats");
			 * actionCodes.put("0260", "0260 rest period"); actionCodes.put("0299",
			 * "0299 other (STCW)"); actionCodes.put("0300",
			 * "0300 Crew and accommodation (ILO 147)"); actionCodes.put("0301",
			 * "0301 minimum age"); actionCodes.put("0310", "0310 dirty, parasites");
			 * actionCodes.put("0320", "0320 ventilation, heating"); actionCodes.put("0330",
			 * "0330 sanitary facilities"); actionCodes.put("0340", "0340 drainage");
			 * actionCodes.put("0350", "0350 lighting"); actionCodes.put("0360",
			 * "0360 pipes, wires (insulation)"); actionCodes.put("0370", "0370 sick bay");
			 * actionCodes.put("0371", "0371 medical equipment"); actionCodes.put("0399",
			 * "0399 other (crew and accommodation)"); actionCodes.put("0400",
			 * "0400 food and catering (ILO 147)"); actionCodes.put("0410",
			 * "0410 galley, handlingroom (maintenance)"); actionCodes.put("0420",
			 * "0420 provisions"); actionCodes.put("0430", "0430 water, pipes and tanks");
			 * actionCodes.put("0499", "0499 other (food)"); actionCodes.put("0500",
			 * "0500 working spaces (ILO 147)"); actionCodes.put("0510",
			 * "0510 ventilation, heating"); actionCodes.put("0520", "0520 lighting");
			 * actionCodes.put("0599", "0599 other (working spaces)");
			 * actionCodes.put("0600", "0600 life saving appliances");
			 * actionCodes.put("0610", "0610 lifeboats"); actionCodes.put("0611",
			 * "0611 lifeboats inventory"); actionCodes.put("0613",
			 * "0613 stowage of lifeboats"); actionCodes.put("0615", "0615 rescue boats");
			 * actionCodes.put("0616", "0616 rescue boat inventory");
			 * actionCodes.put("0618", "0618 stowage of rescue boats");
			 * actionCodes.put("0620", "0620 inflatable liferafts"); actionCodes.put("0625",
			 * "0625 rigid liferafts"); actionCodes.put("0628",
			 * "0628 stowage of liferafts"); actionCodes.put("0629",
			 * "0629 marine evacuation systems"); actionCodes.put("0630",
			 * "0630 launching arrangements for survival crafts"); actionCodes.put("0635",
			 * "0635 launching arrangements for rescue boats"); actionCodes.put("0636",
			 * "0636 helicopter landing and pick-up area"); actionCodes.put("0637",
			 * "0637 means of rescue"); actionCodes.put("0640", "0640 distress flares");
			 * actionCodes.put("0650", "0650 lifebuoys"); actionCodes.put("0660",
			 * "0660 lifejackets"); actionCodes.put("0663", "0663 immersion suits");
			 * actionCodes.put("0664", "0664 anti-exposures suits"); actionCodes.put("0666",
			 * "0666 thermal protective aids"); actionCodes.put("0669",
			 * "0669 radio lifesaving appliances"); actionCodes.put("0674",
			 * "0674 emergency equipment for 2-way communication"); actionCodes.put("0675",
			 * "0675 general emergency alarm"); actionCodes.put("0676",
			 * "0676 public address system"); actionCodes.put("0680",
			 * "0680 embarkation arrangements survival crafts"); actionCodes.put("0683",
			 * "0683 embarkation arrangements rescue boats"); actionCodes.put("0684",
			 * "0684 means of recovery of lifesaving appliances"); actionCodes.put("0686",
			 * "0686 buoyant apparatus"); actionCodes.put("0690",
			 * "0690 line throwing appliance"); actionCodes.put("0692",
			 * "0692 operational readiness, maintenance and inspections");
			 * actionCodes.put("0694", "0694 evaluation, testing and approval");
			 * actionCodes.put("0695", "0695 on board training and instructions");
			 * actionCodes.put("0696", "0696 maintenance and inspection");
			 * actionCodes.put("0699", "0699 other (life-saving)"); actionCodes.put("0700",
			 * "0700 fire safety measures"); actionCodes.put("0710",
			 * "0710 fire prevention"); actionCodes.put("0711", "0711 inert gas system");
			 * actionCodes.put("0715", "0715 fire detection"); actionCodes.put("0720",
			 * "0720 fire fighting equipment"); actionCodes.put("0725",
			 * "0725 fixed fighting equipment"); actionCodes.put("0730",
			 * "0730 fire fighting equipment and appliance"); actionCodes.put("0735",
			 * "0735 personal equipment"); actionCodes.put("0740", "0740 fire pumps");
			 * actionCodes.put("0745",
			 * "0745 ventilation, fire-dampers. Valves, quick closing devices, means of control"
			 * ); actionCodes.put("0750", "0750 international shore connection");
			 * actionCodes.put("0799", "0799 other (fire safety)"); actionCodes.put("0800",
			 * "0800 accident prevention (ILO 147)"); actionCodes.put("0810",
			 * "0810 personal equipment"); actionCodes.put("0820",
			 * "0820 protection machines / parts"); actionCodes.put("0830",
			 * "0830 pipes, wires (insulation)"); actionCodes.put("0899",
			 * "0899 other (accident prevention)"); actionCodes.put("0900",
			 * "0900 safety in general"); actionCodes.put("0910",
			 * "0910 hydraulic and other dosing devices / watertight doors");
			 * actionCodes.put("0915",
			 * "0915 signs, indication (WT doors, fire detectors, fire dampers, ventilation)"
			 * ); actionCodes.put("0920", "0920 safety plans"); actionCodes.put("0925",
			 * "0925 musters and drills"); actionCodes.put("0930",
			 * "0930 stability/ strength/ loading information and instrument");
			 * actionCodes.put("0936", "0936 steering gear"); actionCodes.put("0938",
			 * "0938 hull damage impairing seaworthiness"); actionCodes.put("0940",
			 * "0940 ballast, fuel and other tanks"); actionCodes.put("0945",
			 * "0945 emergency lighting, batteries and switches"); actionCodes.put("0950",
			 * "0950 electric equipment general"); actionCodes.put("0955",
			 * "0955 pilot ladders"); actionCodes.put("0956",
			 * "0956 gangway, accommodation ladder"); actionCodes.put("0960",
			 * "0960 means of escape"); actionCodes.put("0970",
			 * "0970 location of emergency installations"); actionCodes.put("0981",
			 * "0981 beams, frames, floors - operational damage"); actionCodes.put("0982",
			 * "0982 beams, frames, floors - corrosion"); actionCodes.put("0983",
			 * "0983 hull - corrosion"); actionCodes.put("0984", "0984 hull - cracking");
			 * actionCodes.put("0985", "0985 bulkheads - corrosion");
			 * actionCodes.put("0986", "0986 bulkheads - operational damage");
			 * actionCodes.put("0987", "0987 bulkheads - cracking"); actionCodes.put("0988",
			 * "0988 decks - corrosion"); actionCodes.put("0989", "0989 decks - cracking");
			 * actionCodes.put("0990", "0990 enhanced programme of inspection");
			 * actionCodes.put("0991", "0991 survey report file"); actionCodes.put("0999",
			 * "0999 other (safety in general)"); actionCodes.put("1000",
			 * "1000 alarm signals"); actionCodes.put("1010", "1010 general alarm");
			 * actionCodes.put("1020", "1020 fire alarm"); actionCodes.put("1030",
			 * "1030 steering - gear alarm"); actionCodes.put("1040",
			 * "1040 engineer's alarm"); actionCodes.put("1050", "1050 inert gas alarm");
			 * actionCodes.put("1060", "1060 machinery alarm"); actionCodes.put("1070",
			 * "1070 UMS - alarm"); actionCodes.put("1080", "1080 boiler - alarm");
			 * actionCodes.put("1099", "1099 other (alarms)"); actionCodes.put("1100",
			 * "1100 Carriage of cargo and dangerous goods"); actionCodes.put("1110",
			 * "1110 stowage of cargo"); actionCodes.put("1115",
			 * "1115 cargo securing manual"); actionCodes.put("1120", "1120 grain");
			 * actionCodes.put("1130", "1130 stowage /packaging of dangerous goods");
			 * actionCodes.put("1135", "1135 dangerous liquid chemicals in bulk");
			 * actionCodes.put("1138", "1138 liquefied gases in bulk");
			 * actionCodes.put("1140", "1140 other cargo"); actionCodes.put("1150",
			 * "1150 loading and unloading equipment"); actionCodes.put("1160",
			 * "1160 holds and tanks"); actionCodes.put("1170",
			 * "1170 dangerous goods codes"); actionCodes.put("1199", "1199 other (cargo)");
			 * actionCodes.put("1200", "1200 load lines"); actionCodes.put("1210",
			 * "1210 overloading"); actionCodes.put("1220", "1220 freeboard marks");
			 * actionCodes.put("1230", "1230 railing, cat walks"); actionCodes.put("1240",
			 * "1240 cargo and other hatchways"); actionCodes.put("1250",
			 * "1250 covers (hatchway-,portable-,tarpaulins, etc.)");
			 * actionCodes.put("1260", "1260 windows, side scuttle");
			 * actionCodes.put("1270", "1270 doors"); actionCodes.put("1275",
			 * "1275 ventilators, air pipes, casings"); actionCodes.put("1280",
			 * "1280 machinery space openings"); actionCodes.put("1282",
			 * "1282 manholes /flush scuttles"); actionCodes.put("1284",
			 * "1284 cargo ports / etc."); actionCodes.put("1286",
			 * "1286 scuppers, inlets, etc."); actionCodes.put("1288",
			 * "1288 freeing ports"); actionCodes.put("1290", "1290 lashings (timber)");
			 * actionCodes.put("1299", "1299 other (load lines)"); actionCodes.put("1300",
			 * "1300 mooring arrangement (ILO 147)"); actionCodes.put("1310",
			 * "1310 ropes and wires"); actionCodes.put("1320", "1320 anchoring devices");
			 * actionCodes.put("1330", "1330 winches and capstans"); actionCodes.put("1340",
			 * "1340 adequate lighting"); actionCodes.put("1399", "1399 other (mooring)");
			 * actionCodes.put("1400", "1400 propulsion and auxiliary machinery");
			 * actionCodes.put("1410", "1410 propulsion main engine");
			 * actionCodes.put("1420", "1420 cleanliness of engine room");
			 * actionCodes.put("1430", "1430 auxiliary engine"); actionCodes.put("1440",
			 * "1440 bilge pumping arrangements"); actionCodes.put("1450",
			 * "1450 UMS - ship"); actionCodes.put("1460",
			 * "1460 guards / fencing around dangerous machinery parts");
			 * actionCodes.put("1470", "1470 insulation wetted through (oil)");
			 * actionCodes.put("1499", "1499 other (machinery)"); actionCodes.put("1500",
			 * "1500 safety of navigation"); actionCodes.put("1510", "1510 equipment");
			 * actionCodes.put("1530", "1530 radar"); actionCodes.put("1540",
			 * "1540 gyro compass"); actionCodes.put("1541", "1541 magnetic compass");
			 * actionCodes.put("1542",
			 * "1542 emergency steering position communications / compass reading");
			 * actionCodes.put("1546", "1546 direction finder"); actionCodes.put("1550",
			 * "1550 lights, shapes, sound-signals"); actionCodes.put("1551",
			 * "1551 signalling lamp"); actionCodes.put("1560", "1560 charts");
			 * actionCodes.put("1570", "1570 nautical publications");
			 * actionCodes.put("1575", "1575 echosounder"); actionCodes.put("1580",
			 * "1580 speed and distance indicator"); actionCodes.put("1581",
			 * "1581 rudder angle indicator"); actionCodes.put("1582",
			 * "1582 revolution counter"); actionCodes.put("1583",
			 * "1583 variable pitch indicator"); actionCodes.put("1585",
			 * "1585 rate-of-turn indicator"); actionCodes.put("1590",
			 * "1590 international code of signals"); actionCodes.put("1595",
			 * "1595 navigation bridge visibility"); actionCodes.put("1599",
			 * "1599 other (navigation)"); actionCodes.put("1600", "1600 radio");
			 * actionCodes.put("1611", "1611 functional requirements");
			 * actionCodes.put("1620", "1620 main installation"); actionCodes.put("1621",
			 * "1621 MF radio installation"); actionCodes.put("1623",
			 * "1623 MF/HF radio installation"); actionCodes.put("1625",
			 * "1625 INMARSAT ship earth station"); actionCodes.put("1635",
			 * "1635 maintenance / duplication of equipment"); actionCodes.put("1645",
			 * "1645 performance standards for radio equipment"); actionCodes.put("1651",
			 * "1651 VHF radio installation"); actionCodes.put("1655",
			 * "1655 facilities for reception of marine safety information");
			 * actionCodes.put("1671", "1671 satellite EPIRB 406Mhz/1.6GHz");
			 * actionCodes.put("1673", "1673 VHF EPIRB"); actionCodes.put("1677",
			 * "1677 reserve source of energy"); actionCodes.put("1680", "1680 radio log");
			 * actionCodes.put("1685", "1685 operation/maintenance");
			 * actionCodes.put("1699", "1699 other (radio)"); actionCodes.put("1700",
			 * "1700 MARPOL - annex I"); actionCodes.put("1705",
			 * "1705 shipboard oil pollution emergency plan (SOPEP)");
			 * actionCodes.put("1710", "1710 oil record book");
			 */

			// serve per ottenere la map ordinata
			Map<String, String> actionCodesTreeMap = new TreeMap<String, String>(actionCodes);
			deficiecyCodes = new ArrayList<SelectItem>();
			for (Map.Entry entry : actionCodesTreeMap.entrySet()) {
				deficiecyCodes.add(new SelectItem(entry.getKey().toString(), entry.getValue().toString()));
			}

//			//ottiene la mappa non ordinata
//			deficiecyCodes = new ArrayList<SelectItem>();			
//			for (String key : actionCodes.keySet()) {
//				deficiecyCodes.add(new SelectItem(key, actionCodes.get(key)));			
//			}

			countryId = null;
			portId = null;

			currentAttachementFile = new ArrayList<FileInfo>();
			currentAttachementFile.add(null);
			currentAttachementFilePath = new ArrayList<String>();
			currentAttachementFilePath.add(null);

			currentAttachementFileDeficiencies = new ArrayList<FileInfo>();
			currentAttachementFileDeficiencies.add(null);
			currentAttachementFileDeficienciesPath = new ArrayList<String>();
			currentAttachementFileDeficienciesPath.add(null);

			inizializzato = true;
		}
	}

	public boolean getRequisitionEnebled() {

		boolean req = false;

//		log.info("Requisition Enabled: " + PropertiesUtils.getInstance().readProperty("requisition.enabled"));
//		log.info("Requisition Enabled diverso da null: " +  PropertiesUtils.getInstance().readProperty("requisition.enabled")!=null);

		if (PropertiesUtils.getInstance().readProperty("requisition.enabled") != null
				&& PropertiesUtils.getInstance().readProperty("requisition.enabled").toString().equals("true"))
			req = true;

		return req;
	}

	public void addDeficiency(ActionEvent e) {
		log.info("Aggiungo una nuova deficiency con codice: " + selectedDeficiencyCode);

		Deficiency def = new Deficiency();
		def.setCode(selectedDeficiencyCode);
		def.setCodeDescription(actionCodes.get(selectedDeficiencyCode));

//		def.setType(selectedDeficiencyType);
		def.setReferencedEntity(inspection);
		def.setUuid(UUID.randomUUID().toString());
		def.setStatus("Open");

		FollowupAndCorrectiveAction ca = new FollowupAndCorrectiveAction();
		ca.setType("CorrectiveAction");
		ca.setUuid(UUID.randomUUID().toString());
		def.setCorrectiveAction(ca);

		// setto i flag status a open
		ca.setOpenFlag(true);
		ca.setFollowUpFlag(false);
		ca.setProposedForClosingFlag(false);
		ca.setClosedFlag(false);

		// TODO Aggiungere campo num in deficency
		// Fare la ricerca dei num relativi a quella deficenza...prendere il piu grande
		// piu uno. Se non esiste assegnargli 1.
		if (inspection.getDeficiencies() == null)
			log.info("Aggiungo la deficenza NRO 1!!");
		else
			log.info("Aggiungo la deficenza NRO  " + (inspection.getDeficiencies().size() + 1));
		if (inspection.getDeficiencies() == null)
			def.setNro((long) 1);
		else
			def.setNro((long) inspection.getDeficiencies().size() + 1);

		deficienciesToModify = def;

		currentAttachementFileDeficiencies.clear();
		currentAttachementFileDeficienciesPath.clear();
		currentAttachementFileDeficiencies.add(null);
		currentAttachementFileDeficienciesPath.add(null);

		if (inspection.getDeficiencies() == null)
			inspection.setDeficiencies(new ArrayList<Deficiency>());
		inspection.getDeficiencies().add(def);

//		addInfoMessage("Deficiency n. " + def.getNro() +" inserted!");

	}

	public List<SelectItem> getDeficiencyItems() {
		if (deficiencyItems != null) {
			return deficiencyItems;
		}
		deficiencyItems = new ArrayList<SelectItem>();
		for (int i = 0; i < DeficiencyType.values().length; i++) {
			deficiencyItems
					.add(new SelectItem(DeficiencyType.values()[i].name(), DeficiencyType.values()[i].getName()));
		}
		// serve per ottenere la map ordinata
		Map<String, String> actionCodesTreeMap = new TreeMap<String, String>(actionCodes);
		deficiecyCodes = new ArrayList<SelectItem>();
		for (Map.Entry entry : actionCodesTreeMap.entrySet()) {
			deficiecyCodes.add(new SelectItem(entry.getKey().toString(), entry.getValue().toString()));
		}

//		//ottiene la mappa non ordinata
//		deficiecyCodes = new ArrayList<SelectItem>();			
//		for (String key : actionCodes.keySet()) {
//			deficiecyCodes.add(new SelectItem(key, actionCodes.get(key)));			
//		}
		return deficiencyItems;
	}

	public void modifyDeficiency(ActionEvent e) {
		String deficencyUuid = FacesUtils.getRequestParameter("deficencyUuid");

		if (inspection.getDeficiencies() != null && deficencyUuid != null) {
			for (Deficiency d : inspection.getDeficiencies()) {
				if (d.getUuid().equals(deficencyUuid)) {
					deficienciesToModify = d;

					currentAttachementFileDeficiencies.clear();
					currentAttachementFileDeficienciesPath.clear();
					currentAttachementFileDeficiencies.add(null);
					currentAttachementFileDeficienciesPath.add(null);
					if (deficienciesToModify.getAttachments() != null) {
						for (String at : deficienciesToModify.getAttachments()) {
							try {
								currentAttachementFileDeficiencies.add(0, null);
								currentAttachementFileDeficienciesPath.add(0, at);

							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
					}
					break;
				}
			}
		}
	}

	public void deleteDeficiency(ActionEvent e) {
		String deficencyUuid = FacesUtils.getRequestParameter("deficencyUuid");

		if (inspection.getDeficiencies() != null && deficencyUuid != null) {
			for (Deficiency d : inspection.getDeficiencies()) {
				if (d.getUuid().equals(deficencyUuid)) {
					inspection.getDeficiencies().remove(d);
					break;
				}
			}
		}
		deficienciesToModify = null;
	}

//	public void closeDeficiency(ActionEvent e) {
//		deficienciesToModify = null;
//	}

	public boolean isDeficiencyModifyVisible() {
		return (deficienciesToModify != null);
	}

	public void saveDeficiencies() {
		try {
			if (deficienciesToModify.getId() != null) {
				inspectionService.update(deficienciesToModify);
			}
			setDeficiencyModifyVisible(false);
		} catch (Exception e) {
		}
	}

	public void setDeficiencyModifyVisible(boolean aa) {
		if (!aa) {
			try {
				if (currentAttachementFileDeficiencies != null) {
					int iii = 0;
					if (deficienciesToModify != null) {

						List<String> tempList = deficienciesToModify.getAttachments();
						if (tempList == null)
							tempList = new ArrayList<String>();
						deficienciesToModify.setAttachments(new ArrayList<String>());
						for (String filePath : currentAttachementFileDeficienciesPath) {
							if (filePath != null && !filePath.equals("")) {
								if (!tempList.contains(filePath)) {
									InputStream data = new FileInputStream(
											currentAttachementFileDeficiencies.get(iii).getFile().getAbsolutePath());
									String realname = inspectionService.storeInspectionAttachementFile(data, filePath);
									deficienciesToModify.getAttachments().add(realname);
									// Aggiorno con il path reale
									currentAttachementFileDeficienciesPath.set(iii, realname);
								} else
									deficienciesToModify.getAttachments().add(filePath);
							}
							iii++;
						}
					}
				}
				currentAttachementFileDeficiencies.clear();
				currentAttachementFileDeficienciesPath.clear();
				currentAttachementFileDeficiencies.add(null);
				currentAttachementFileDeficienciesPath.add(null);
				inspectionService.update(deficienciesToModify);
			} catch (Exception e) {
				currentAttachementFileDeficiencies.clear();
				currentAttachementFileDeficienciesPath.clear();
				currentAttachementFileDeficiencies.add(null);
				currentAttachementFileDeficienciesPath.add(null);
			}
			deficienciesToModify = null;
		}
	}

	public List<SelectItem> getCountries() {
		if (countriesItems == null) {
			countriesItems = new ArrayList<SelectItem>();
			List<Country> cs = genericLookupService.getAll();
			countriesItems.add(new SelectItem(new Long(0), ""));
			for (Country c : cs) {
				SelectItem item = new SelectItem(c.getId(), c.getName());
				countriesItems.add(item);
			}
		}
		return countriesItems;
	}

	public void countrySelection(ValueChangeEvent e) {
		// log.info("Nuova Country selezionata :" + e.getNewValue());

		if (e.getNewValue() != null && (Long) e.getNewValue() > 0) {
			ports.clear();
			List<Port> cs = genericLookupService.getCountryPort((Long) e.getNewValue());
			ports.add(new SelectItem(new Long(0), ""));
			for (Port c : cs) {
				SelectItem item = new SelectItem(c.getId(), c.getName());
				ports.add(item);
			}

			Country co = null;
			try {
				co = genericLookupService.get((Long) e.getNewValue());
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}
			inspection.setCountry(co);
		}
	}

	public void portSelection(ValueChangeEvent e) {
		// log.info("Nuovo Port selezionato :" + e.getNewValue());

		if (e.getNewValue() != null && (Long) e.getNewValue() > 0) {
			Port port = null;
			try {
				port = genericLookupService.getPort((Long) e.getNewValue());
			} catch (DocumentException e1) {
				e1.printStackTrace();
			}
			inspection.setPort(port);
		}
	}

	public void mouSelection(ValueChangeEvent e) {
		// log.info("Nuova mou selezionata :" + e.getNewValue());

		// Mou mou = genericLookupService.getMou((Long)e.getNewValue());
		// inspection.setMou(mou);

		if (e.getNewValue() != null)
			inspection.setMou((String) e.getNewValue());
		else
			inspection.setMou(null);
	}

	public void areaSelection(ValueChangeEvent e) {
		// log.info("Nuova area selezionata :" + e.getNewValue());

		if (e.getNewValue() != null) {
			String ar = (String) e.getNewValue();

			// Subarea
			subareas.clear();
			String[] areasArray = null;
			if (ar.equalsIgnoreCase("structural"))
				areasArray = subareasStructural;
			if (ar.equalsIgnoreCase("human"))
				areasArray = subareasHuman;
			if (ar.equalsIgnoreCase("maintenance"))
				areasArray = subareasMaintenance;
			if (ar.equalsIgnoreCase("management"))
				areasArray = subareasManagement;
			if (ar.equalsIgnoreCase("security"))
				areasArray = subareasSecurity;

			subareas.add(new SelectItem(new Long(0), ""));
			if (areasArray != null) {
				for (int i = 0; i < areasArray.length; i++) {
					SelectItem item = new SelectItem(areasArray[i], areasArray[i]);
					subareas.add(item);
				}
			}

			// Root cause
			rootCauses.clear();
			String[] rootArray = null;
			if (ar.equalsIgnoreCase("structural") || ar.equalsIgnoreCase("deck") || ar.equalsIgnoreCase("engine"))
				rootArray = rootCausesStructural;
			if (ar.equalsIgnoreCase("human"))
				rootArray = rootCausesHuman;
			if (ar.equalsIgnoreCase("maintenance"))
				rootArray = rootCausesMaintenance;
			if (ar.equalsIgnoreCase("management") || ar.equalsIgnoreCase("security"))
				rootArray = rootCausesManagement;
			if (ar.equalsIgnoreCase("galley"))
				rootArray = rootCausesGalley;
			if (ar.equalsIgnoreCase("bridge"))
				rootArray = rootCausesBridge;

			for (int i = 0; i < rootArray.length; i++) {
				SelectItem item = new SelectItem(rootArray[i], rootArray[i]);
				rootCauses.add(item);
			}

		} else {
			subareas.clear();
			rootCauses.clear();
		}
	}

//	 public void uploadAttachementActionListener(ActionEvent actionEvent) {
//		 String idComponente = ((InputFile)actionEvent.getSource()).getId();
//		 log.info(idComponente+"  ...id completo!!!!!!!!!!!!");
//		 idComponente = idComponente.substring(idComponente.lastIndexOf("_")+1);
//		 InputFile inputFile = (InputFile) actionEvent.getSource();
//		 currentAttachementFile.set(Integer.parseInt(idComponente), inputFile.getFileInfo());
//		 currentAttachementFilePath.set(Integer.parseInt(idComponente), currentAttachementFile.get(Integer.parseInt(idComponente)).getPhysicalPath());
//	}
	public void uploadAttachementActionListener(FileEntryEvent e) {

		String idComponente = ((FileEntry) e.getSource()).getId();
		log.debug(idComponente + "  ...id completo!!!!!!!!!!!!");
		idComponente = idComponente.substring(idComponente.lastIndexOf("_") + 1);

		FileEntry fe = (FileEntry) e.getComponent();
		FileEntryResults results = fe.getResults();

		for (FileInfo i : results.getFiles()) {
			if (i.isSaved()) {
				log.info("Salvato: " + i.getFileName());
				currentAttachementFile.set(Integer.parseInt(idComponente), i);
				currentAttachementFilePath.set(Integer.parseInt(idComponente),
						currentAttachementFile.get(Integer.parseInt(idComponente)).getFileName());
			} else {
				addWarningMessage("File was not saved because: "
						+ i.getStatus().getFacesMessage(FacesContext.getCurrentInstance(), fe, i).getSummary());
			}
		}

	}

	public void addNewAttachement(ActionEvent e) {
		currentAttachementFile.add(null);
		currentAttachementFilePath.add(null);
	}

	public void removeAttachement(ActionEvent e) {
		Integer rowIndex = (Integer) e.getComponent().getAttributes().get("rowIndex");
		if (rowIndex != null) {
			Path path = Paths.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
					+ File.separator + currentAttachementFilePath.get(rowIndex)));
			try {
				Files.deleteIfExists(path);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			currentAttachementFile.remove(rowIndex.intValue());
			currentAttachementFilePath.remove(rowIndex.intValue());
		}
		if (currentAttachementFile == null || currentAttachementFile.size() == 0) {
			currentAttachementFile = new ArrayList<FileInfo>();
			currentAttachementFile.add(null);
			currentAttachementFilePath.add(null);
		}
	}

	public void uploadAttachementDeficienciesActionListener(FileEntryEvent e) {

		log.info("uploadAttachementDeficienciesActionListener  ac01");
		String idComponente = ((FileEntry) e.getSource()).getId();
		log.info(idComponente + "  ...id completo!!!!!!!!!!!!");
		idComponente = idComponente.substring(idComponente.lastIndexOf("_") + 1);

		log.info("uploadAttachementDeficienciesActionListener  ac02");

		FileEntry fe = (FileEntry) e.getComponent();
		FileEntryResults results = fe.getResults();

		for (FileInfo i : results.getFiles()) {
			if (i.isSaved()) {
				log.info("Salvato: " + i.getFileName());
				currentAttachementFileDeficiencies.set(Integer.parseInt(idComponente), i);
				currentAttachementFileDeficienciesPath.set(Integer.parseInt(idComponente),
						currentAttachementFileDeficiencies.get(Integer.parseInt(idComponente)).getFileName());
			} else {
				addWarningMessage("File was not saved because: "
						+ i.getStatus().getFacesMessage(FacesContext.getCurrentInstance(), fe, i).getSummary());
			}
		}

	}

	public void addNewDeficienciesAttachement(ActionEvent e) {
		currentAttachementFileDeficiencies.add(null);
		currentAttachementFileDeficienciesPath.add(null);
	}

	public void removeDeficienciesAttachement(ActionEvent e) {
		Integer rowIndex = (Integer) e.getComponent().getAttributes().get("rowIndexd");
		if (rowIndex != null) {
			Path path = Paths.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
					+ File.separator + currentAttachementFileDeficienciesPath.get(rowIndex)));
			try {
				Files.deleteIfExists(path);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			currentAttachementFileDeficiencies.remove(rowIndex.intValue());
			currentAttachementFileDeficienciesPath.remove(rowIndex.intValue());
		}
		if (currentAttachementFileDeficiencies == null || currentAttachementFileDeficiencies.size() == 0) {
			currentAttachementFileDeficiencies = new ArrayList<FileInfo>();
			currentAttachementFileDeficiencies.add(null);
			currentAttachementFileDeficienciesPath.add(null);
		}
	}

	public void saveAndSynchronizeWithOffice(ActionEvent e) {

		try {
			save(e);

			// INVIO a ufficio
			DataExchangeMessage message = new DataExchangeMessage(
					PropertiesUtils.getInstance().readProperty("ship.uuid"), true,
					CommunicationMessageType.TMSA_PSC_INSPECTION_SYNC);
			log.info("INVIO all'ufficio....");
			if (inspection != null) {
				try {
					for (String attI : inspection.getAttachments()) {
						log.info(attI);
					}
					for (Deficiency def : inspection.getDeficiencies()) {
						for (String at : def.getAttachments()) {
							log.info(at);
						}
					}
				} catch (Exception e2) {
					// TODO: handle exception
				}
				// Allego l'istanza serializzata
				XStream xs = new XStream();
//				xs.autodetectAnnotations(true);
				ByteArrayOutputStream baos = null;
				try {
					baos = new ByteArrayOutputStream();
					Writer writer = new OutputStreamWriter(baos, "UTF-8");
					xs.toXML(inspection, writer);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				message.getEntities().add(baos.toByteArray());

				// Allego gli eventuali allegati
				for (String attPath : inspection.getAttachments()) {
					final String filname = attPath;
					message.getFiles().put(filname,
							FileUtils.getBytesFromFile(
									PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
											+ File.separator + attPath));
				}
				if (inspection.getDeficiencies() != null) {
					for (Deficiency def : inspection.getDeficiencies()) {
						if (def.getAttachments() != null) {
							for (String attPath : def.getAttachments()) {
								final String filname = attPath;
								message.getFiles()
										.put(filname,
												FileUtils.getBytesFromFile(PropertiesUtils.getInstance()
														.readProperty("repository.location.audit.attachments")
														+ File.separator + attPath));
							}
						}
					}
				}
				// Allego gli eventuali allegati in deficiency
//				for (String attPathDef : inspection.getAttachments()) {
//					final String filnameDeficiency = attPathDef;
//					message.getFiles().put(filnameDeficiency, FileUtils.getBytesFromFile(PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")+File.separator+attPath));
//				}

				message.getProperties().put("DATE", (EasyDateUtils.getGMT0CurrentDate()).toString());
				message.getProperties().put("UUID", inspection.getUuid());

				try {
					communicatorSenderNave.sendMessage(message);

					Inspection is = inspectionService.getInspection(inspection.getId());
					is.setSynchronizedWithRemote(true);
					inspection = inspectionService.update(is);

					log.info("Istanza inviata!!!");
				} catch (Throwable e2) {
					e2.printStackTrace();
					log.error("Errore nell'invio Istanza: " + e2.getMessage());
				}
			}

			addInfoMessage("Inspection sent to office!");
		} catch (Exception e2) {
			e2.printStackTrace();
			addErrorMessage("Error sending Inspection!");
		}

	}

	public void save(ActionEvent e) {

		try {

			if (inspection.getDeficiencies() != null && inspection.getDeficiencies().size() > 0) {
				inspection.setStatus("Open");
			} else {
				inspection.setStatus("Closed");
			}

			inspection.setType(0); // PSC

			// AC 02/02
			// mi scorro gli action code e i combination code di ogni deficenza e mi polpolo
			// l'array con degli action code dell'ispezione
			List<String> actCInsp = new ArrayList<String>();
			if (inspection.getDeficiencies() != null) {
				for (Deficiency def : inspection.getDeficiencies()) {

					log.info("getActionCode:   " + def.getActionCode());
					log.info("getCombinationOfActionCode:   " + def.getCombinationOfActionCode());

					if (actCInsp == null && (def.getActionCode() != null)
							|| !actCInsp.contains(def.getActionCode()) && (def.getActionCode() != null))
						actCInsp.add(def.getActionCode());
					if (actCInsp == null && (def.getCombinationOfActionCode() != null)
							|| !actCInsp.contains(def.getCombinationOfActionCode())
									&& (def.getCombinationOfActionCode() != null))
						actCInsp.add(def.getCombinationOfActionCode());
				}
			}
			inspection.setArrayActionCodes(actCInsp);

			// Setto inspection nro: numero incrementale da 1 a n per
			// anno(dateOfFirstBoarding)
			// Dal service faccio un (count whare dateOfFirstBoarding.year = utc.year and
			// inspection.getType = 0 ) + 1
			log.info("inspectionService.getNroInspectionByTypeAndYear +1 _Type PSC: "
					+ inspectionService.getNroInspectionByTypeAndYear(0));

			if (inspection.getDateOfInspection() == null)
				inspection.setDateOfInspection(EasyDateUtils.getGMT0CurrentDate());
			if (inspection.getNro() == null || inspection.getNro().equals(""))
				inspection.setNro(inspectionService.getNroInspectionByTypeAndYear(0));

			// Salvo gli allgati
			if (currentAttachementFile != null) {
				int iii = 0;
				List<String> tempList = inspection.getAttachments();
				if (tempList == null)
					tempList = new ArrayList<String>();
				inspection.setAttachments(new ArrayList<String>());
				for (String filePath : currentAttachementFilePath) {
					if (filePath != null && !filePath.equals("")) {
						if (!tempList.contains(filePath)) {
							InputStream data = new FileInputStream(
									currentAttachementFile.get(iii).getFile().getAbsolutePath());
							String realname = inspectionService.storeInspectionAttachementFile(data, filePath);
							inspection.getAttachments().add(realname);
							// Aggiorno con il path reale
							currentAttachementFilePath.set(iii, realname);
						} else
							inspection.getAttachments().add(filePath);
					}
					iii++;
				}
			}

//			 // Salvo gli allgati in deficency
//			 if (currentAttachementFileDeficiencies !=null) {
//				 int iii = 0;
//				 List<String> tempList = inspection.getAttachments();
//				 if (tempList==null) tempList = new ArrayList<String>();
//				 inspection.setAttachments(new ArrayList<String>());
//				 for (String filePath : currentAttachementFilePath) {
//					 if (filePath!=null && !filePath.equals("")) {
//						 if (!tempList.contains(filePath)) {
//							 InputStream data = new FileInputStream(filePath); 
//							 String realname = inspectionService.storeInspectionAttachementFile(data, filePath);
//							 inspection.getAttachments().add(realname);
//							 // Aggiorno con il path reale
//							 currentAttachementFilePath.set(iii, realname);
//						 }
//						 else inspection.getAttachments().add(filePath);
//					 }
//					 iii++;
//				 }
//			 }

			inspection.setSynchronizedWithRemote(false);

			// ac test fix 24-11
			// inspection = inspectionService.add(inspection);
			log.info("Save-psc   - id:" + inspection.getId());
			if (inspection.getId() == null) {
				log.info("Save-psc  - add - id:" + inspection.getId());
				inspection = inspectionService.add(inspection);
			} else {
				log.info("Save-psc  - update - id:" + inspection.getId());
				inspection = inspectionService.update(inspection);
			}

			// se esiste eseguo il workflow e aggiungo all'agenda un elemento se impostata
			// la data dell'azione correttiva.
			if (inspection.getDeficiencies() != null) {
				for (Deficiency def : inspection.getDeficiencies()) {

					// Workflow
					DeficiencyModel dm = inspectionService.getDeficiencyModelByDeficiencyType(def.getType());
					if (dm != null && dm.getWorkflow() != null && !dm.getWorkflow().equals("")) {
						// Eseguo il workflow
						if (!scriptService.evaluateWorkflow(dm.getWorkflow(), null, agendaService, documentService,
								messageService)) {
							addErrorMessage("Associated deficiency workflow not executed correctly...skipped");
						}
					}

					// Elemento agenda se impostata la data dell'azione correttiva.
					if (def.getCorrectiveAction() != null
							&& def.getCorrectiveAction().getTimeLimitForCorrectiveAction() != null) {

						// Aggiungo un elemento all'agenda con data TimeLimitForCorrectiveAction (lo
						// faccio scattare a mezzanotte e 1 minuto)
						Calendar cal = Calendar.getInstance();
						cal.setTime(def.getCorrectiveAction().getTimeLimitForCorrectiveAction());
						String triggerString = "0 1 0 " + cal.get(Calendar.DAY_OF_MONTH) + " "
								+ (cal.get(Calendar.MONTH) + 1) + " ? " + cal.get(Calendar.YEAR);
						String script = "messageService.addMessage(\"PSC Inspection " + inspection.getId()
								+ ": Corrective action for deficiecy with code " + def.getCode()
								+ " will expire today!!!\", \"INFO\");";
						agendaService.addTodo("PSC Inspection " + inspection.getId()
								+ ": Corrective action for deficiecy with code " + def.getCode() + " expiring.", null,
								null, triggerString, script);
						log.info("elemento agenda inserito!!!!!");
					}
				}
			}

//			 synchronizeWithOffice();

			// Azzero ricerca
			PscOpenedInspectionBean bb = (PscOpenedInspectionBean) FacesUtils.getManagedBean("pscOpenedInspectionBean");
			if (bb != null)
				bb.search(null);

			addInfoMessage("Inspection inserted!");

		} catch (Exception e2) {
			e2.printStackTrace();
			addInfoMessage("Error inserting Inspection!");
		}
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public Long getPortId() {
		return portId;
	}

	public void setPortId(Long portId) {
		this.portId = portId;
	}

	public List<SelectItem> getPorts() {
		return ports;
	}

	public List<SelectItem> getMous() {
		return mous;
	}

	public void setMous(List<SelectItem> mous) {
		this.mous = mous;
	}

	public Inspection getInspection() {
		return inspection;
	}

	public void setInspection(Inspection inspection) {
		this.inspection = inspection;
	}

	public List<SelectItem> getAreas() {
		return areas;
	}

	public List<SelectItem> getSubareas() {
		return subareas;
	}

	public List<SelectItem> getRootCauses() {
		return rootCauses;
	}

	public List<SelectItem> getOperationCheck1Items() {
		return operationCheck1Items;
	}

	public List<SelectItem> getOperationCheck2Items() {
		return operationCheck2Items;
	}

	public List<SelectItem> getDeficiecyCodes() {
		return deficiecyCodes;
	}

	public DeficiencyType getSelectedDeficiencyType() {
		return selectedDeficiencyType;
	}

	public void setSelectedDeficiencyType(DeficiencyType selectedDeficiencyType) {
		this.selectedDeficiencyType = selectedDeficiencyType;
	}

	public Deficiency getDeficienciesToModify() {
		return deficienciesToModify;
	}

	public void setDeficienciesToModify(Deficiency deficienciesToModify) {
		this.deficienciesToModify = deficienciesToModify;
	}

	public String getSelectedDeficiencyCode() {
		return selectedDeficiencyCode;
	}

	public void setSelectedDeficiencyCode(String selectedDeficiencyCode) {
		this.selectedDeficiencyCode = selectedDeficiencyCode;
	}

	private boolean requisitionEdit = false;

//	public void closeRequisition(ActionEvent e) {
//		// Assegno la requisition se compilata
//		RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
//		if (requisitionBean!=null){
//			if (requisitionBean.getIdRequisitionForSendToOffice()!=null){
//				deficienciesToModify.getCorrectiveAction().setRequisition(requisitionService.getRequisition(requisitionBean.getIdRequisitionForSendToOffice()));
//				requisitionBean.setIdRequisitionForSendToOffice(null);
//			}
//		}
//		requisitionEdit = false;
//	}
	public void openRequisition(ActionEvent e) {
		// Nuova requisition
		RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
		if (requisitionBean != null) {
			requisitionBean.newRequisition(null);
		}

		requisitionEdit = true;
	}

	private boolean showPopupPdfForm = false;
	private Long documentPdfFormIdToCompile = null;

	public void dryDockDocumentChanged(ValueChangeEvent e) {

		if (e != null && e.getNewValue() != null && (e.getNewValue()).equals(true)) {

			Long dryDockDocumentId = null;
			try {
				List<TmsaForm> forms = auditService.getAuditFormFinder().and("enabled").eq(Boolean.TRUE).and("type")
						.eq("DD").list();
				if (forms != null && !forms.isEmpty()) {
					log.info("getCurrentM23DocumentId nell'if...");
					dryDockDocumentId = forms.get(0).getId();
				}
			} catch (Throwable e1) {
				e1.printStackTrace();
			}

			showPopupPdfForm = true;
			documentPdfFormIdToCompile = dryDockDocumentId;

			// String call="changeIframe('" + docId + "', '0', false,
			// 'iframe_pdf_audit_edit');";
			String call = "changeIframeGen('" + dryDockDocumentId
					+ "', 'fdfAudit.pdf', 'false', 'iframe_pdf_audit_edit', 'PscEdit');";
			log.info("documentSelected...call:" + call);
			JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(), call);
		}
	}

//	public void hidePopupPdfForm(ActionEvent e) {
//		showPopupPdfForm=false;
//	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.oceanpro.web.tmsa.servlet.FormCompiler#setRisultato(byte[])
	 */
	@Override
	public void setRisultato(byte[] risultato) {
		log.info("SetRisultato psc edit dry doc...");

		FormDataManipulationReader fdmr = new FormDataManipulationReader(risultato);
		// DEBUG
		log.info("CAMPI:");
		for (String key : fdmr.getFieldsName()) {
			log.info("Campo: " + key + " Valore: " + fdmr.getFieldValue(key));
		}

		deficienciesToModify.setDryDockFormData(risultato);
		deficienciesToModify
				.setDryDockForm(auditService.getAuditFormFinder().and("id").eq(documentPdfFormIdToCompile).result());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.oceanpro.web.tmsa.servlet.FormCompiler#getDocumentStream(java.lang.
	 * String)
	 */
	@Override
	public InputStream getDocumentStream(String docId) {
		log.info("Psc Bean getDocumentStream - docId:" + docId);
		try {
			FileInputStream fis = null;
			TmsaForm forms = auditService.getAuditFormFinder().and("id").eq(Long.parseLong(docId)).result();
			if (forms != null) {
				File a = new File(PropertiesUtils.getInstance().readProperty("repository.location.tmsa.forms")
						+ File.separatorChar + forms.getPath());
//    			File a = new File(forms.getPath());
				fis = new FileInputStream(a);
			}

			return fis;
		} catch (Throwable e) {
			e.printStackTrace();
			return null;
		}
	}

	public void dryDockReport(ActionEvent ev) {
		if (deficienciesToModify != null && deficienciesToModify.getDryDockForm() != null) {

			try {
				// log.info("getFormInspectionn... form path:" +
				// inspectionSelected.getForm().getPath());
				// Create a reader that interprets the input stream
				FdfReader fdf = new FdfReader(deficienciesToModify.getDryDockFormData()); // Valido solo se il pulsante
																							// di submit � di tipo fdf
																							// submit

				// Get document input stream
				InputStream pdfInputStream = new FileInputStream(
						PropertiesUtils.getInstance().readProperty("repository.location.tmsa.forms")
								+ File.separatorChar + deficienciesToModify.getDryDockForm().getPath());
//	            InputStream  pdfInputStream = new FileInputStream(deficienciesToModify.getDryDockForm().getPath());
				// We create a reader with the InputStream
				PdfReader reader = new PdfReader(pdfInputStream, null);
				// We create an OutputStream for the new PDF
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				// Now we create the new PDF
				PdfStamper stamper = new PdfStamper(reader, baos);

				// We alter the fields of the existing PDF
				AcroFields fields = stamper.getAcroFields();
				fields.setFields(fdf);
				stamper.setFormFlattening(true); // Diventa un pdf non form
				// stamper.setFormFlattening(false); // rimane un pdf form scrivibile

				// close the stamper
				stamper.close();

				String uniqueId = UUID.randomUUID().toString();
				downloadListBean.addDownloadObject(uniqueId, baos.toByteArray(), "DryDock.pdf");

				JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
						"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
								+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
								+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");

//	            return new ByteArrayResource(baos.toByteArray());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (com.itextpdf.text.DocumentException e) {
				e.printStackTrace();
			}
		}

	}

	public boolean isShowPopupPdfForm() {
		return showPopupPdfForm;
	}

	public void setShowPopupPdfForm(boolean showPopupPdfForm) {
		this.showPopupPdfForm = showPopupPdfForm;
	}

	public Long getDocumentPdfFormIdToCompile() {
		return documentPdfFormIdToCompile;
	}

	public void setDocumentPdfFormIdToCompile(Long documentPdfFormIdToCompile) {
		this.documentPdfFormIdToCompile = documentPdfFormIdToCompile;
	}

	public boolean isRequisitionEdit() {
		return requisitionEdit;
	}

	public void setRequisitionEdit(boolean requisitionEdit) {
		this.requisitionEdit = requisitionEdit;

		if (!requisitionEdit) { // chiudo
			RequisitionBean requisitionBean = (RequisitionBean) FacesUtils.getManagedBean("requisitionBean");
			if (requisitionBean != null) {
				if (requisitionBean.getIdRequisitionForSendToOffice() != null) {
					deficienciesToModify.getCorrectiveAction().setRequisition(
							requisitionService.getRequisition(requisitionBean.getIdRequisitionForSendToOffice()));
					requisitionBean.setIdRequisitionForSendToOffice(null);
				}
			}
		}
	}

	public List<FileInfo> getCurrentAttachementFile() {
		return currentAttachementFile;
	}

	public void setCurrentAttachementFile(List<FileInfo> currentAttachementFile) {
		this.currentAttachementFile = currentAttachementFile;
	}

	public List<String> getCurrentAttachementFilePath() {
		return currentAttachementFilePath;
	}

	public void setCurrentAttachementFilePath(List<String> currentAttachementFilePath) {
		this.currentAttachementFilePath = currentAttachementFilePath;
	}

	public Map<String, String> getActionCodes() {
		return actionCodes;
	}

	public List<SelectItem> getPotentialRisks() {
		return potentialRisks;
	}

	public void setPotentialRisks(List<SelectItem> potentialRisks) {
		this.potentialRisks = potentialRisks;
	}

	public List<SelectItem> getContributingFactors() {
		return contributingFactors;
	}

	public void setContributingFactors(List<SelectItem> contributingFactors) {
		this.contributingFactors = contributingFactors;
	}

	public List<FileInfo> getCurrentAttachementFileDeficiencies() {
		return currentAttachementFileDeficiencies;
	}

	public void setCurrentAttachementFileDeficiencies(List<FileInfo> currentAttachementFileDeficiencies) {
		this.currentAttachementFileDeficiencies = currentAttachementFileDeficiencies;
	}

	public List<String> getCurrentAttachementFileDeficienciesPath() {
		return currentAttachementFileDeficienciesPath;
	}

	public void setCurrentAttachementFileDeficienciesPath(List<String> currentAttachementFileDeficienciesPath) {
		this.currentAttachementFileDeficienciesPath = currentAttachementFileDeficienciesPath;
	}

	public List<FileInfo> getTestCA() {
		return testCA;
	}

	public void setTestCA(List<FileInfo> testCA) {
		this.testCA = testCA;
	}

	public List<String> getTestCAF() {
		return testCAF;
	}

	public void setTestCAF(List<String> testCAF) {
		this.testCAF = testCAF;
	}

	private String uploadDir = PropertiesUtils.getInstance().readProperty("repository.location.audit");

	public String getUploadFolder() {
		return uploadDir;
	}

	private FileInfo currentFile;

	public FileInfo getCurrentFile() {
		return currentFile;
	}

	public void setCurrentFile(FileInfo currentFile) {
		this.currentFile = currentFile;
	}

	public void uploadDatasheetActionListener(FileEntryEvent e) {
		FileEntry fe = (FileEntry) e.getComponent();
		FileEntryResults results = fe.getResults();

		for (FileInfo i : results.getFiles()) {
			if (i.isSaved()) {
				log.info("Salvato: " + i.getFileName());
				currentFile = i;
				deficienciesToModify.setDatasheet(currentFile.getFileName());
			} else {
				addWarningMessage("File was not saved because: "
						+ i.getStatus().getFacesMessage(FacesContext.getCurrentInstance(), fe, i).getSummary());
			}
		}
	}

	public void downloadAttachement(ActionEvent evt) {
		long deficiencyId = FacesUtils.getRequestParameter("deficienciesToModifyId", Long.class, 0L);
		if (deficiencyId != 0L) {
			try {
				Deficiency deficiency = auditService.getDeficiency(deficiencyId);
				String uniqueId = deficiency.getUuid();
				String fileName = deficiency.getDatasheet();
				byte[] res = FileUtils.getBytesFromFile(uploadDir + File.separator + fileName);
				downloadListBean.addDownloadObject(uniqueId, res, fileName);
				JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
						"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
								+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
								+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void downloadAttachements(ActionEvent evt) {
		Integer fileIndex = (Integer) evt.getComponent().getAttributes().get("rowIndex");
		log.info("downloadAttachement - fileIndex:" + fileIndex);
		if (fileIndex != null) {
			String pathF = currentAttachementFilePath.get(fileIndex);
			if (pathF != null) {

				try {
					log.info("Downlaod " + pathF);
					String uniqueId = UUID.randomUUID().toString();
					String fileName = "";
					Path path = Paths
							.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
									+ File.separator + pathF));
					byte[] res = null;
					if (Files.exists(path)) {
						res = FileUtils.getBytesFromFile(
								PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
										+ File.separator + pathF);
						fileName = pathF;
					} else {
						res = FileUtils
								.getBytesFromFile(currentAttachementFile.get(fileIndex).getFile().getAbsolutePath());
						fileName = pathF;
					}
					downloadListBean.addDownloadObject(uniqueId, res, fileName);

					JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
							"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
									+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
									+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void downloadDeficienciesAttachements(ActionEvent evt) {
		Integer fileIndex = (Integer) evt.getComponent().getAttributes().get("rowIndexd");
		log.info("downloadAttachement - fileIndex:" + fileIndex);
		if (fileIndex != null) {
			String pathF = currentAttachementFileDeficienciesPath.get(fileIndex);
			if (pathF != null) {

				try {
					log.info("Downlaod " + pathF);
					String uniqueId = UUID.randomUUID().toString();
					String fileName = "";
					Path path = Paths
							.get((PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
									+ File.separator + pathF));
					byte[] res = null;
					if (Files.exists(path)) {
						res = FileUtils.getBytesFromFile(
								PropertiesUtils.getInstance().readProperty("repository.location.audit.attachments")
										+ File.separator + pathF);
						fileName = pathF;
					} else {
						res = FileUtils.getBytesFromFile(
								currentAttachementFileDeficiencies.get(fileIndex).getFile().getAbsolutePath());
						fileName = pathF;
					}
					downloadListBean.addDownloadObject(uniqueId, res, fileName);

					JavascriptContext.addJavascriptCall(FacesContext.getCurrentInstance(),
							"window.open('" + downloadListBean.getDownloadUrl(uniqueId) + "', " + "'myWindow', "
									+ "'width=600," + "height=300," + "directories=0," + "location=0, " + "menubar=0, "
									+ "resizable=0, " + "scrollbars=1, " + "status=0, " + "toolbar=0');");

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void removeDatasheet(ActionEvent actionEvent) {

		String fileName = deficienciesToModify.getDatasheet();
		String filePath = uploadDir + File.separator + fileName;

		deficienciesToModify.setDatasheet("");

	}

	public List<SelectItem> getImmediateCauses() {
		return immediateCauses;
	}

	public void setImmediateCauses(List<SelectItem> immediateCauses) {
		this.immediateCauses = immediateCauses;
	}

	public List<SelectItem> getRootCausesTwo() {
		return rootCausesTwo;
	}

	public void setRootCausesTwo(List<SelectItem> rootCausesTwo) {
		this.rootCausesTwo = rootCausesTwo;
	}

}