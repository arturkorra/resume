package com.easymarine.automated.navigation.warnings.service;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.easymarine.automated.navigation.warnings.persistence.entity.NavArea;
import com.easymarine.automated.navigation.warnings.persistence.entity.Navigation;
import com.easymarine.automated.navigation.warnings.persistence.entity.User;
import com.easymarine.automated.navigation.warnings.persistence.repository.NavAreaRepository;
import com.easymarine.automated.navigation.warnings.persistence.repository.NavigationRepository;
import com.easymarine.automated.navigation.warnings.persistence.repository.UserRepository;

@Service
@Transactional
public class NavAreaService implements INavAreaService {

	@Autowired
	NavAreaRepository navAreaRepository;
	@Autowired
	NavigationRepository navigationRepository;
	@Autowired
	UserRepository userRepository;

	@Override
	public List<NavArea> findAllNavArea() {
		return navAreaRepository.findAll();
	}

	@Override
	public void saveNavArea(NavArea navArea, Set<Navigation> oldNaviagtion) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user = userRepository.findByUsername(userDetails.getUsername()).get();
		user.setUpdateDate(new Date());

		userRepository.saveAndFlush(user);
		navAreaRepository.saveAndFlush(navArea);

	}

	@Override
	public void delOldNav(NavArea navArea, Set<Navigation> oldNaviagtion) {
		NavArea navAreaDB = navAreaRepository.getOne(navArea.getId());
		Set<Navigation> copyOldNav = new HashSet<Navigation>();

		for (Navigation oneNav : oldNaviagtion) {
			if (navAreaDB.getNavigation().contains(oneNav)) {
				copyOldNav.add(oneNav);
			}
		}

		navAreaDB.getNavigation().removeAll(copyOldNav);
		navAreaRepository.saveAndFlush(navAreaDB);
	}

	@Override
	public void checkDubl(NavArea navArea) {
		NavArea navAreaDB = navAreaRepository.getOne(navArea.getId());
		Set<Navigation> allNewNav = navAreaDB.getNavigation();
		Set<Navigation> navToDel = new HashSet<Navigation>();
		for (Navigation navigation : allNewNav) {
			List<Navigation> checkDubl = navigationRepository.findByNavareaText(navigation.getNavareaText());
			if (checkDubl.size() == 2) {
				Navigation navToChange = new Navigation();
				Navigation navToCopy = new Navigation();
				for (Navigation duble : checkDubl) {
					if (duble.getStatus().equals("IN FORCE")) {
						navToCopy = duble;
					}
				}
				if (navToCopy.getNavareaText().isEmpty()) {
					navToCopy = checkDubl.get(0);
				}
				navToChange.setNavArea(navToCopy.getNavArea());
				navToChange.setNavareaText(navToCopy.getNavareaText());
				navToChange.setStatus(navToCopy.getStatus());
				navToChange.setType(navToCopy.getType());
				navToChange.setSymbol(navToCopy.getSymbol());
				navToChange.setCoordinates(navToCopy.getCoordinates());
				navigationRepository.saveAndFlush(navToChange);
				navigationRepository.flush();
				navToDel.addAll(checkDubl);
			}
		}

		for (Navigation oneNav : navToDel) {
			if (navAreaDB.getNavigation().contains(oneNav)) {

				navAreaDB.getNavigation().remove(oneNav);
			}

		}
		navAreaRepository.saveAndFlush(navAreaDB);

	}

	@Override
	public NavArea getNavArea(Long NavAreaId) {
		return navAreaRepository.getOne(NavAreaId);
	}

	@Override
	public List<Navigation> getNavigation(NavArea navArea) {
		return navigationRepository.findByNavArea(navArea);
	}

	@Override
	public List<Navigation> getAllNavigation() {
		return navigationRepository.findAll();
	}

	@Override
	public List<Navigation> getByNavareaText(String navareaText) {
		return navigationRepository.findByNavareaText(navareaText);

	}

	@Override
	public Navigation getNavigationById(Long id) {

		return navigationRepository.findById(id).get();
	}

	@Override
	public void saveNavigation(Navigation navigation) {
		navigation.setNavareaText(navigationRepository.getOne(navigation.getId()).getNavareaText());
		navigationRepository.saveAndFlush(navigation);
	}

	@Override
	public Navigation createNavigation(Navigation navigation) {
		
		return navigationRepository.saveAndFlush(navigation);
		
	}

}