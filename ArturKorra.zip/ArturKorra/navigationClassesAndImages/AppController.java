package com.easymarine.automated.navigation.warnings.controller;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.easymarine.automated.navigation.warnings.persistence.entity.NavArea;
import com.easymarine.automated.navigation.warnings.persistence.entity.Navigation;
import com.easymarine.automated.navigation.warnings.persistence.repository.NavigationRepository;
import com.easymarine.automated.navigation.warnings.persistence.repository.UserRepository;
import com.easymarine.automated.navigation.warnings.service.INavAreaService;
import com.easymarine.automated.navigation.warnings.until.GenericResponse;

@Controller
public class AppController {

	@Autowired
	public INavAreaService iNavAreaService;

	@Autowired
	UserRepository userRepository;
	@Autowired
	NavigationRepository navigationRepository;
	private String OS = System.getProperty("os.name").toLowerCase();

	@GetMapping({ "/", "/login" })
	public String index() {
		return "index";
	}

	private String scrollID;

	@GetMapping("/menu")
	public String menu(final Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		model.addAttribute("updateDate",
				userRepository.findByUsername(userDetails.getUsername()).get().getUpdateDate().toLocaleString());
		return "menu";
	}

	// GET: Show navigation.
	@RequestMapping(value = { "/navigationEdit" }, method = RequestMethod.GET)
	public String navigationEdit(Model model, @RequestParam(value = "id", defaultValue = "") String id) {
		Navigation navigation = new Navigation();

		if (id != null && id.length() > 0) {
			navigation = iNavAreaService.getNavigationById(Long.parseLong(id));
			if (navigation != null) {
				model.addAttribute("navigation", navigation);
			}
		}
		return "navigationEdit";
	}
	@RequestMapping(value = { "/addNavigation" }, method = RequestMethod.GET)
	public String addNavigation(Model model, @RequestParam(value = "navArea", defaultValue = "") String navAreaID) {
		Navigation navigation = new Navigation();
		navigation.setNavArea(iNavAreaService.getNavArea(Long.valueOf(navAreaID)));
		model.addAttribute("navigation", navigation);
		return "addNavigation";
	}
	@RequestMapping(value = { "/deleteNavigation" }, method = RequestMethod.GET)
	public String deleteNavigation(Model model, @RequestParam(value = "id", defaultValue = "") String id) {
		Navigation navigation = new Navigation();
		Long navareaId = 0L;
		if (id != null && id.length() > 0) {
			navigation = iNavAreaService.getNavigationById(Long.parseLong(id));
			if (navigation != null) {
				navareaId = navigation.getNavArea().getId();
				navigationRepository.delete(navigation);
				navigationRepository.flush();
				return "redirect:/navigationInfo?id=" + navareaId;
			}
		}

		return "navigationEdit?id=" + navigation.getId();

	}

	// POST: Save navigation
	@RequestMapping(value = { "/navigationSave" }, method = RequestMethod.POST)
	public String productSave(Model model, @ModelAttribute("navigation") @Validated Navigation navigation,
			BindingResult result, final RedirectAttributes redirectAttributes) {

		if (result.hasErrors()) {
			return "navigationEdit?id=" + navigation.getId();
		}
		try {
			iNavAreaService.saveNavigation(navigation);
		} catch (Exception e) {
			Throwable rootCause = ExceptionUtils.getRootCause(e);
			String message = rootCause.getMessage();
			model.addAttribute("errorMessage", message);

			return "navigationEdit?id=" + navigation.getId();
		}
		scrollID = String.valueOf(navigation.getId());
		return "redirect:/navigationInfo?id=" + navigation.getNavArea().getId();
	}
	
	// POST: Save navigation
		@RequestMapping(value = { "/navigationCreateNew" }, method = RequestMethod.POST)
		public String navigationCreateNew(Model model, @ModelAttribute("navigation") @Validated Navigation navigation,
				BindingResult result, final RedirectAttributes redirectAttributes) {
			try {
				navigation.setId(iNavAreaService.createNavigation(navigation).getId());
			} catch (Exception e) {
				Throwable rootCause = ExceptionUtils.getRootCause(e);
				String message = rootCause.getMessage();
				model.addAttribute("errorMessage", message);

				return "navigationEdit?id=" + navigation.getId();
			}
			scrollID = String.valueOf(navigation.getId());
			return "redirect:/navigationInfo?id=" + navigation.getNavArea().getId();
		}

	@RequestMapping(value = "/readKML", method = RequestMethod.GET)
	@ResponseBody
	public GenericResponse downloadExcel(HttpServletResponse response, Model model,
			@RequestParam(value = "id", defaultValue = "") String id) throws Exception, InterruptedException {
		try {
			String kmlFolderPath = "";
			if (isWindows()) {
				System.out.println("This is Windows");
				kmlFolderPath = "C:\\Navigation_Warnings_Automated\\";

			} else if (isUnix()) {
				System.out.println("This is Unix or Linux");
				kmlFolderPath = "/opt/Navigation_Warnings_Automated/";
			} else {
				System.out.println("Your OS is not support!!");
			}
			File folder = new File(kmlFolderPath);
			File[] listOfFiles = folder.listFiles();
			for (File file : listOfFiles) {
				if (file.isFile()) {
					String kmlText = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
					if (file.getName().contains("NW01_") && id.equals("1")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW02_") && id.equals("2")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW03_") && id.equals("3")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW04_") && id.equals("4")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW05_") && id.equals("5")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW06_") && id.equals("6")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW07_") && id.equals("7")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW08_") && id.equals("8")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW09_") && id.equals("9")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW10_") && id.equals("10")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW11_") && id.equals("11")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW12_") && id.equals("12")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW13_") && id.equals("13")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW14_") && id.equals("14")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW15_") && id.equals("15")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW16_") && id.equals("16")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW17_") && id.equals("17")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW18_") && id.equals("18")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW19_") && id.equals("19")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW20_") && id.equals("20")) {
						return new GenericResponse(kmlText.toString());
					} else if (file.getName().contains("NW21_") && id.equals("21")) {
						return new GenericResponse(kmlText.toString());
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return new GenericResponse("ERROR");
	}

	@RequestMapping(value = "/navigationMap", method = RequestMethod.GET)
	public String viewOnMap(Locale locale, final Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		model.addAttribute("updateDate",
				userRepository.findByUsername(userDetails.getUsername()).get().getUpdateDate().toLocaleString());
		try {
			String kmlFolderPath = "";
			if (isWindows()) {
				System.out.println("This is Windows");
				kmlFolderPath = "C:\\Navigation_Warnings_Automated\\";
				System.out.println(kmlFolderPath + " to delete");
			} else if (isUnix()) {
				System.out.println("This is Unix or Linux");
				kmlFolderPath = "/opt/Navigation_Warnings_Automated/";
				System.out.println(kmlFolderPath + " to delete");
			} else {
				System.out.println("Your OS is not support!!");
			}
			File folder = new File(kmlFolderPath);
			File[] listOfFiles = folder.listFiles();
			for (File file : listOfFiles) {
				if (file.isFile()) {
					String kmlText = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
					if (file.getName().contains("NW01_")) {
						byte[] array = Files.readAllBytes(Paths.get(file.getAbsolutePath()));
						model.addAttribute("navarea1", kmlText);
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Error to delete old kml file");
			System.out.println(e);
		}
		return "navigationMap";
	}

	@RequestMapping(value = "/navarea", method = RequestMethod.GET)
	public String showNavarea(final Locale locale, final Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		model.addAttribute("updateDate",
				userRepository.findByUsername(userDetails.getUsername()).get().getUpdateDate().toLocaleString());
		model.addAttribute("navarea", iNavAreaService.findAllNavArea());
		return "navarea";
	}

	@RequestMapping(value = "/navigationInfo", method = RequestMethod.GET)
	public String showUserDetailsPage(final Locale locale, final Model model, @RequestParam("id") final Long id) {
		List<Navigation> navigation = new ArrayList<Navigation>();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		model.addAttribute("updateDate",
				userRepository.findByUsername(userDetails.getUsername()).get().getUpdateDate().toLocaleString());
		try {
			Set<Navigation> allNav = iNavAreaService.getNavArea(id).getNavigation();
			Iterator<Navigation> iterator = allNav.iterator();
			while (iterator.hasNext()) {
				Navigation nav = (Navigation) iterator.next();
				// System.out.println("rimuovo naviagtion:" + nav.getNavareaText());
				if (nav.getId() != null) {
					navigation.add(nav);
				}
			}
			Collections.sort(navigation, Comparator.comparing(Navigation::getNavareaText));
			model.addAttribute("scrollID", scrollID);
			model.addAttribute("navigationList", navigation);
			return "navigationInfo";
		} catch (Exception e) {
			model.addAttribute("scrollID", scrollID);
			model.addAttribute("navigationList", navigation);
			return "navigationInfo";
		}
	}

	public ArrayList<Navigation> getPresent(List<Navigation> nav) {
		Optional<List<Navigation>> opt = Optional.of(nav);
		ArrayList<Navigation> res = new ArrayList<Navigation>();
		if (opt.isPresent())
			res.addAll(opt.get());
		return res;
	}

	@GetMapping("/user")
	public String user() {
		return "user";
	}

	@GetMapping("/admin")
	public String admin() {
		return "admin";
	}

	public boolean isWindows() {
		return OS.contains("win");
	}

	public boolean isMac() {
		return OS.contains("mac");
	}

	public boolean isUnix() {
		return (OS.contains("nix") || OS.contains("nux") || OS.contains("aix"));
	}

	public boolean isSolaris() {
		return OS.contains("sunos");
	}

	public String getOS() {
		if (isWindows()) {
			return "win";
		} else if (isMac()) {
			return "osx";
		} else if (isUnix()) {
			return "uni";
		} else if (isSolaris()) {
			return "sol";
		} else {
			return "err";
		}
	}
}
