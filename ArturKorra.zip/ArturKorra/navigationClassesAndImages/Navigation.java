package com.easymarine.automated.navigation.warnings.persistence.entity;

import java.text.Normalizer;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.dom4j.Branch;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "navigation")
public class Navigation {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(columnDefinition = "TEXT")
	private String navareaText;

	@Basic
	private String type;

	@Basic
	private String symbol;

	@Basic
	private String status;

	@Basic
	private String note;
	@Column(columnDefinition = "TEXT")
	private String coordinates;

	@ManyToOne(targetEntity = NavArea.class, fetch = FetchType.LAZY)
	private NavArea navArea;

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Navigation))
			return false;
		return id != null && id.equals(((Navigation) o).getId());
	}

	@Override
	public int hashCode() {
		return 31;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNavareaText() {

		return navareaText;
	}

	public void setNavareaText(String navareaText) {
		this.navareaText = navareaText;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public NavArea getNavArea() {
		return navArea;
	}

	public void setNavArea(NavArea navArea) {
		this.navArea = navArea;
	}

	public String getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
	}
}