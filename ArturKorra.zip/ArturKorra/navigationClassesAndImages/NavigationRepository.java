package com.easymarine.automated.navigation.warnings.persistence.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.easymarine.automated.navigation.warnings.persistence.entity.NavArea;
import com.easymarine.automated.navigation.warnings.persistence.entity.Navigation;

@Repository
@Transactional
public interface NavigationRepository extends JpaRepository<Navigation, Long> {

	public List<Navigation> findByNavArea(NavArea navArea);

	public List<Navigation> findByNavareaText(String navareaText);
	// public List<Navigation> findAllnavArea(@Param("navID") Long navID);
}