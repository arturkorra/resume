package com.easymarine.automated.navigation.warnings.service;

import java.util.List;
import java.util.Set;

import com.easymarine.automated.navigation.warnings.persistence.entity.NavArea;
import com.easymarine.automated.navigation.warnings.persistence.entity.Navigation;

public interface INavAreaService {
	public List<NavArea> findAllNavArea();

	public void saveNavArea(NavArea navArea, Set<Navigation> oldNaviagtion);

	public NavArea getNavArea(Long NavAreaId);

	public List<Navigation> getNavigation(NavArea navArea);

	public List<Navigation> getAllNavigation();

	public List<Navigation> getByNavareaText(String navareaText);

	public void checkDubl(NavArea navArea);

	public void delOldNav(NavArea navArea, Set<Navigation> oldNaviagtion);

	public Navigation getNavigationById(Long id);

	public void saveNavigation(Navigation navigation);
	
	public Navigation createNavigation(Navigation navigation);
}
